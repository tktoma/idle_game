package idle.ui;

import idle.core.Absence;
import idle.core.Game;
import idle.core.elements.PeriodicTable;
import idle.core.math.BigNum;
import idle.core.probes.ProbeTrip;
import idle.ui.common.Detail;
import idle.ui.common.ElementText;
import idle.ui.common.Format;
import idle.ui.common.Labels;
import java.util.ArrayList;
import java.util.List;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.VBox;

/**
 * L'aide « Comment jouer », par-dessus la fenêtre : un paragraphe par étape du jeu, puis la liste
 * des raccourcis avec leurs touches du moment.
 *
 * <p>Seules les étapes que le joueur a atteintes sont expliquées : la suite se découvre en
 * jouant, et l'aide grandit avec la partie. Les nombres cités viennent des règles ({@link Game}) quand elles
 * les exposent ; les autres (en lettres : « dix minutes », « trois secondes », « cinquième Big Bang »…) sont
 * recopiés et à relire si la règle change.
 *
 * <p>Elle s'ouvre et se ferme par son raccourci ({@link Shortcuts.Action#HELP}), par le bouton
 * « Aide » sous les onglets, et se ferme aussi par Échap ou son bouton.
 */
final class HelpPane extends Overlay {

    private static final String TITLE_STYLE = "-fx-font-size: 15px; -fx-font-weight: bold; -fx-padding: 10 0 0 0; -fx-text-fill: #d6dde6;";
    private static final String TEXT_STYLE = "-fx-font-size: 13px; -fx-text-fill: #b7c4d2;";
    private static final String BUTTON_STYLE = buttonStyle("8 18", "#d6dde6");

    /**
     * Un paragraphe de l'aide.
     *
     * @param title son titre
     * @param text  ce qu'il explique
     */
    record Section(String title, String text) {
    }

    private final Game game;
    private final Settings settings;
    private final VBox content = new VBox(6);
    private final Button close = new Button("Fermer");
    private boolean open = false;

    HelpPane(Game game, Settings settings) {
        super(VEIL);
        this.game = game;
        this.settings = settings;
        Label title = new Label("Comment jouer");
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #e8f4ff;");
        close.setStyle(BUTTON_STYLE);
        close.setFocusTraversable(false);
        close.setOnAction(event -> close());
        content.setAlignment(Pos.TOP_LEFT);
        ScrollPane scroll = new ScrollPane(content);
        Labels.transparent(scroll);
        VBox card = new VBox(10, title, scroll, close);
        card.setAlignment(Pos.TOP_CENTER);
        card.setStyle(cardStyle("#3a4a5e", false, "20 26"));
        card.setMaxWidth(640);
        mount(card);
    }

    /** Vrai tant que l'aide est affichée. */
    boolean isOpen() {
        return open;
    }

    /** Ouvre l'aide si elle est fermée, la ferme sinon. */
    void toggle() {
        if (open) close();
        else open();
    }

    /** Ouvre l'aide, écrite pour la partie telle qu'elle est en ce moment. */
    void open() {
        open = true;
        content.getChildren().clear();
        for (Section section : sections(game, settings)) {
            Label title = new Label(section.title());
            title.setStyle(TITLE_STYLE);
            Label text = new Label(section.text());
            text.setStyle(TEXT_STYLE);
            text.setWrapText(true);
            content.getChildren().add(title);
            content.getChildren().add(text);
        }
        setVisible(true);
    }

    void close() {
        open = false;
        setVisible(false);
    }

    /** Les paragraphes de l'aide pour cette partie : ceux des étapes atteintes, puis ce qui vaut toujours. */
    static List<Section> sections(Game game, Settings settings) {
        List<Section> sections = new ArrayList<>();
        int generators = game.generatorsPerAtom();
        sections.add(new Section("Particules", "Un générateur crée des particules. Elles paient trois améliorations : la "
                + "vitesse de création, le couplage (chaque générateur renforce les autres) et un générateur de plus. "
                + "Réunis, les " + generators + " générateurs fusionnent en atomes : il n'en reste qu'un, et les "
                + "particules repartent de zéro."));
        boolean atoms = game.state().totalAtoms().sign() > 0 || game.isDarkMatterUnlocked() || game.isBigBangUnlocked();
        if (atoms) {
            sections.add(new Section("Atomes", "Les atomes paient des améliorations que la fusion ne reprend pas (onglet "
                    + "Atomes)." + (game.isAtomCapLifted() ? "" : " On ne peut en garder que " + Format.count(game.atomCap())
                    + " à la fois : il faut les dépenser pour fusionner de nouveau.") + " À " + Format.count(Game.UNLOCK_TOTAL_ATOMS) + " atomes créés s'ouvrent "
                    + "l'automatisation et le tableau périodique."));
        }
        if (game.isPeriodicTableUnlocked() || game.isDarkMatterUnlocked() || game.isBigBangUnlocked()) {
            sections.add(new Section("Automatisation", "Un automatisme s'achète une fois, en atomes, puis achète ou "
                    + "fusionne à votre place. Il se coupe et se relance d'un clic, et sa cadence s'accélère en atomes."
                    + (game.isDarkMatterUnlocked() || game.isBigBangUnlocked()
                            ? " Ceux de matière noire ne coûtent rien ; les deux qui achètent suivent le moins cher "
                                    + "d'abord, ou l'ordre que vous leur donnez sous leurs cartes." : "")
                    + (game.isBigBangUnlocked()
                            ? " L'espace et les Big Bangs en apportent d'autres : l'appui, la création, le rassemblement "
                                    + "et la formation automatiques." : "")
                    // Version 0.126 : où les réglages tiennent, sans rien dire de ce qui vient après le Big Bang.
                    + " Vos réglages (la coupure générale, les ordres d'achat, le seuil de fusion, le verrou de l'appui, la "
                    + "part d'espace laissée libre, les molécules favorites, les automatismes de matière noire allumés, les "
                    + "pauses du collisionneur) tiennent d'une remise à zéro à l'autre (explosion, "
                    + "Big Bang et au-delà) : seul « Recommencer de zéro », dans les réglages, les remet comme au début."));
            sections.add(new Section("Tableau périodique", "Une synthèse coûte des atomes et donne un élément. Chaque "
                    + "élément apporte un bonus, ses exemplaires le renforcent, et une famille réunie forme un ensemble. "
                    + "Quand les " + PeriodicTable.ELEMENTS.size() + " éléments sont découverts, le tableau peut exploser."));
        }
        if (game.isDarkMatterUnlocked() || game.isBigBangUnlocked()) {
            sections.add(new Section("Matière noire", "L'explosion remet toute la matière à zéro et laisse de la matière "
                    + "noire. Tenez le clic sur son point pour la faire grossir. Son arbre a trois branches : l'une se "
                    + "paie en particules, l'autre en atomes, la troisième s'ouvre avec la taille. Sept bifurcations proposent deux voies côte à côte : en "
                    + "prendre une ferme l'autre jusqu'au prochain Big Bang, où le choix se refait ; la Superposition du "
                    + "collisionneur, à partir du cinquième Big Bang, ouvre les deux. À gauche, la voie de présence, la plus "
                    + "forte : elle renforce les paliers de vitesse ou rapporte de la matière noire. À droite, la voie d'absence, "
                    + "plus lente mais moins fatigante : elle rend plus du temps passé jeu fermé, et c'est elle que l'arbre prend "
                    + "seul pendant votre absence si vous n'avez pas choisi. Entre "
                    + "les branches, six liaisons, payées en matière noire, s'ouvrent par l'une ou l'autre des voies voisines ; "
                    + "quatre accords demandent trois voies du même style à la fois. Aucune case n'attend un nombre de "
                    + "matières noires : seuls les prix rythment l'arbre. Les défis sont des "
                    + "parties sous contrainte, avec une récompense qui reste. Au bout de l'arbre, les "
                    + game.bigBangConditions().size() + " conditions du prochain Big Bang, une fois réunies, le "
                    + "déclenchent. Exploser nettement plus vite que la fois d'avant (en moins de "
                    + ElementText.percent(Game.SPEED_PRIME_MARGIN) + " du temps) rapporte une prime de vitesse : une matière noire de plus."));
        }
        if (game.isBigBangUnlocked()) {
            // Version 0.126 : ce que le Big Bang garde, comme le dit l'arbre, et les paliers payants de la 0.124.
            sections.add(new Section("Big Bang", "Le Big Bang remet la partie à zéro comme une explosion, et efface en plus "
                    + "la matière noire en réserve et sa taille ; l'arbre de matière noire et les défis réussis ne restent "
                    + "qu'avec les paliers qui les gardent (les bifurcations se rouvrent quand même). Restent les succès, les "
                    + "records, le collisionneur et ce que l'onglet Big Bang a construit : molécules, astres, espace. Il ouvre l'expansion : l'espace grandit seul. Une molécule se crée avec des "
                    + "exemplaires du tableau périodique et de l'espace libre, et reste d'un Big Bang à l'autre. À partir de "
                    + Game.SUBSTANCE_MOLECULES + " molécules, une sorte se rassemble ; les sortes rassemblées forment des "
                    + "assemblages, puis des astres, jusqu'à la galaxie, l'amas de galaxies et l'univers. Les Big Bangs ouvrent des "
                    + "paliers, " + game.bigBangMilestones().size() + " en tout : une fois ouvert, un palier se paie en "
                    + "particules ou en atomes, d'un clic sur sa carte, et agit dès lors."));
        } else {
            sections.add(new Section("La suite", "Elle se découvre en jouant : cette aide grandit avec la partie."));
        }
        if (game.isBigBangUnlocked()) {
            sections.add(new Section("S'y retrouver au troisième acte", "Au-dessus des assemblages, des astres et de "
                    + "l'univers, la liste de courses dit ce qu'il manque pour le prochain pas, avec un bouton sur chaque "
                    + "ligne. Sur la page des molécules, la ligne « Meilleur achat » nomme la création qui rapporte le plus "
                    + "pour l'espace qu'elle prend, et un bouton range les cartes par rendement."));
            sections.add(new Section("Collections, comètes et défis", "Créer au moins une molécule de la moitié des sortes "
                    + "d'un rayon, puis de toutes, multiplie une grandeur pour de bon. De temps en temps une comète traverse "
                    + "l'expansion de la matière : la saisir double l'espace créé pendant "
                    + (int) (Game.COMET_BOOST_SECONDS / 60) + " minutes ; la manquer ne coûte rien. D'autres petites "
                    + "anomalies passent aussi, facultatives : un vent de particules (particules ×" + (int) Game.WIND_FACTOR
                    + " pendant " + (int) (Game.WIND_SECONDS / 60) + " minutes) ou une fenêtre d'exploration (les sondes en vol "
                    + "avancent de " + (int) (Game.EXPLORATION_SECONDS / 60) + " minutes) ; elles se masquent dans les réglages. L'amas de galaxies et "
                    + "l'univers demandent de la quantité et de la variété : un nombre de sortes rassemblées dans chaque état. "
                    + "La galaxie multiplie tout par " + (int) Game.GALAXY_FACTOR + ", l'amas puis l'univers par 2 chacun ; chaque état "
                    + "réuni pour l'amas ou l'univers est un jalon, +" + Math.round(Game.COSMOS_MILESTONE_GAIN * 100) + " % à tout. "
                    + "L'univers formé, un écran fait le bilan de la partie ; le jeu continue derrière."
                    + (game.isBangChallengesUnlocked() ? " Au cinquième Big Bang, les défis de Big Bang s'ouvrent sous "
                            + "les paliers : un Big Bang sous contrainte, pour une récompense qui reste." : "")));
        }
        sections.add(new Section("Lire une carte", "Une carte dit l'essentiel : son niveau en haut, ce qu'elle fait, son "
                + "prix en bas. Tenez la touche " + Detail.keyName(settings.detailKey()) + " pour lire les explications "
                + "complètes, partout dans le jeu."
                + (settings.stateSigns() ? " Devant son nom, un signe dit son état sans la couleur : ● à portée, ○ en "
                        + "attente, ◐ entamée, ▶ en marche, □ coupée, ✓ acquise, × fermée." : "")));
        sections.add(new Section("Lire un nombre", "Laissez la souris sur la production, les atomes par fusion, la matière "
                + "noire ou l'espace par seconde : une bulle dit de quoi le nombre est fait, un facteur par ligne. Sous "
                + "les onglets, l'objectif rappelle le prochain pas"
                + (game.isDarkMatterUnlocked() ? ", puis ce qu'il manque au prochain Big Bang" : "")
                + ". Les annonces qui passent restent dans le journal, dernière sous-page des statistiques. Les réglages, "
                + "sous-onglet « Notifications et signes », coupent les annonces par catégorie, cachent les morceaux de "
                + "l'objectif un par un et les pastilles ● des onglets par sorte."));
        if (game.isColliderUnlocked()) sections.add(new Section("Collisionneur", "Un onglet à part, depuis la première "
                + "explosion, que ni l'explosion ni le Big Bang ne remettent à zéro. Les faisceaux croisés donnent de l'énergie, et "
                + "huit générateurs se produisent l'un l'autre, de l'aimant supraconducteur au collisionneur de Planck : comptez "
                + "trois heures environ pour les avoir tous. Un clic quand les faisceaux se croisent capte trois secondes de production. "
                + "Avec le huitième s'ouvrent les améliorations, payées en énergie : d'abord « Collisions », qui donne à chaque "
                + "croisement " + Math.round(Game.COLLISION_CHANCE * 100) + " % de chances de sortir un quark, puis les saveurs une à une (étrange, charmée, belle, top), les "
                + "automates des générateurs, la vitesse des faisceaux, la production d'énergie et des générateurs, et la chaîne qui "
                + "renforce le reste du jeu, dans son sous-onglet « Chaîne », payée en énergie et en quarks : particules, atomes, "
                + "matière noire, vitesse de l'espace, dédoublement des molécules. L'énergie produite depuis le début ouvre les deux "
                + "trous noirs : " + Format.count(BigNum.of(Game.BLACK_HOLE_ENERGY)) + " pour le trou noir, "
                + Format.count(BigNum.of(Game.SUPERMASSIVE_ENERGY)) + " pour le trou noir supermassif, donc pour la galaxie. Les "
                + "succès du collisionneur, dans l'onglet « Succès », se gagnent en achetant des générateurs : chacun double une "
                + "production ou divise des prix par deux."));
        // Les dimensions (version 0.128) : une par univers, et ce que font les quatre qui se jouent.
        if (game.isDimensionsUnlocked()) sections.add(new Section("Dimensions", "Dans l'onglet Univers, une dimension "
                + "s'ouvre à chaque univers. Chacune a ses éclats, propres à elle, et un seuil d'éclats gagnés, un quart d'heure "
                + "de jeu environ, qui marque la dimension d'un rond vert. Ces éclats ont leur nom : les segments de la ligne, les facettes du plan, "
                + "les sphères du volume, les instants de la durée ; ils paient aussi les améliorations de la graine (débit de "
                + "l'arrosoir, tuyau d'arrosage, terre fertile, étage du chrono et ses réglages). La graine s'arrose à l'arrosoir : "
                + "débloqué sur son étagère, on le glisse sur elle, il se penche et verse. Chaque palier de la graine ouvre un "
                + "univers. Le chrono, sur l'étage du haut, se remplit de temps et fait passer tout le jeu plus vite, avec des "
                + "pertes d'autant plus fortes qu'il va vite. Au palier qui ouvre l'univers 4, des bulles naissent dans l'arbre : "
                + "une à la base, sur la graine, puis d'autres à chaque palier, reliées entre elles, jusqu'à l'arbre-monde et ses "
                + "racines. Un clic achète une bulle avec l'énergie du vide accumulée, une fois achetée une bulle reliée à elle "
                + "(la base d'abord) ; elles n'ont pas encore d'effet. La ligne avance seule : chaque trait "
                + "que touche une boule donne des éclats. Le plan se joue au clavier, Z Q S D ou les flèches : on y ramasse les "
                + "éclats en passant dessus."
                + (game.isVolumeOpen() ? " Dans le volume, on clique le cube pour y plonger, puis on regarde autour de soi, "
                        + "clic gauche tenu, et l'on cueille les boules au clic droit ; avec la caméra libre, le regard suit la "
                        + "souris sans clic, qui reste retenue dans la vue (Échap la rend, un clic la reprend), et un clic "
                        + "cueille la boule sous la croix. Une plongée dure "
                        + idle.ui.common.ElementText.number(game.volumeDiveSeconds()) + " secondes ; à la fin, le cube rejette "
                        + "le joueur, et ses améliorations s'achètent dehors." : "")
                // La durée (version 0.134).
                + (game.isDurationOpen() ? " Dans la durée, on tient le bouton au milieu du rond (clic tenu, ou la barre "
                        + "d'espace) : les spirales avancent du bord vers le centre, qu'elles atteignent en "
                        + idle.ui.common.ElementText.number(game.durationMaxSeconds()) + " secondes. Au relâchement, chaque "
                        + "tour vaut un de plus que le précédent : tenir longtemps rapporte bien plus que plusieurs appuis "
                        + "courts, et tenir au-delà du centre ne rapporte plus rien, sans rien faire perdre. Ses améliorations "
                        + "(vitesse, nombre de spirales, valeur, temps au plus) s'achètent bouton relâché." : "")));
        // Le vide (version 0.129) : dès qu'il se propose, et tant qu'il est ouvert ou qu'un cumul est gardé.
        if (game.isVoidOffered() || game.isVoidUnlocked() || !game.state().voidHistory().isEmpty()) sections.add(new Section("Le vide",
                "Au premier Big Bang du troisième univers, puis de chaque univers suivant, le vide se propose dans l'onglet "
                + "Collisionneur : il s'ouvre contre dix minutes de production du collisionneur, comptées à son arrivée, et au moins "
                + Format.count(BigNum.of(Game.VOID_UNLOCK_COST)) + " énergie. Ouvert, le collisionneur y fait naître des paires de "
                + "particules, une par seconde au départ. Chacune coûte une demi-seconde de production du collisionneur, tient un "
                + "cinquième de seconde d'expansion d'espace libre pendant ses " + (int) Game.VOID_PAIR_LIFE + " secondes de vie, et donne 1 énergie du vide à sa "
                + "naissance. Un réglage dit quelle part du collisionneur et de l'espace libre le vide peut prendre (un quart au "
                + "départ). L'énergie du vide fond de " + String.format(java.util.Locale.FRANCE, "%.1f", Game.VOID_DECAY * 100) + " % par seconde : elle monte vers l'équilibre affiché, le gain par seconde "
                + "divisé par la fonte. Elle paie huit améliorations, dans le sous-onglet « Améliorations » : gain par paire, rythme, "
                + "coût en énergie, espace par paire, fonte plus lente, et trois qui raccourcissent le troisième acte : allègement "
                + "du ciel (−" + Math.round(Game.VOID_LIGHTEN_STEP * 100) + " % par niveau des molécules et de la matière que "
                + "demandent les astres, l'amas et l'univers), maturation plus courte (−" + Math.round(Game.VOID_MATURE_STEP * 100)
                + " % par niveau du temps de maturation des astres, aussi pour ceux qui mûrissent déjà) et rassemblement plus court "
                + "(−" + Math.round(Game.VOID_SETTLE_STEP * 100) + " % par niveau du délai de l'amas et de l'univers). Le premier trou noir formé ouvre le trou noir du vide : les particules qu'on lui sacrifie lui donnent "
                + "une masse qui raccourcit la vie des paires et ralentit la fonte. À la formation de l'univers, l'énergie du vide qui "
                + "reste rejoint le cumul, affiché dans le sous-onglet Graine de l'onglet Univers, où il paie les bulles de l'arbre ; "
                + "le vide, son trou noir et ses améliorations repartent de zéro dans l'univers suivant."));
        if (game.bodiesFormed() > 0) sections.add(new Section("Maturation des astres", "Un astre formé mûrit avant de compter "
                + "en entier : de 12 minutes pour un amas de roches à 6 heures pour le trou noir supermassif"
                + (game.maturationShare() < 1 ? ", " + Math.round((1 - game.maturationShare()) * 100) + " % de moins avec le vide" : "")
                + ". En attendant, il donne "
                + "le quart de son bonus, et ne compte ni pour les astres qui partent de lui ni pour la galaxie. "
                + game.maturationPlaces() + " astres mûrissent à la fois. Le bouton « Accélérer » dépense une charge d'impulsion pour gagner " + idle.ui.common.ElementText.number(idle.core.Game.MATURATION_HASTE_SECONDS) + " secondes."));
        if (game.isSolarSystemsUnlocked()) sections.add(new Section("Systèmes solaires", "Dans le Big Bang, depuis le sixième. "
                + "Autour d'une étoile mûre, on range des planètes, de la plus proche à la plus lointaine, et des lunes, une par "
                + "planète au plus. Un système est complet à " + Game.SYSTEM_MIN_PLANETS + " planètes ; la galaxie en demande "
                + Game.SYSTEMS_FOR_GALAXY + ". L'harmonie : un point par planète bien placée (telluriques près, glacées et gazeuses "
                + "au loin), par lune, pour une étoile géante, et deux pour une planète océan en deuxième ou troisième orbite d'un "
                + "Soleil ou d'une naine rouge. Chaque point d'un système complet ajoute " + ElementText.percent(Game.SYSTEM_GAIN)
                + " à toutes les grandeurs. Au septième Big Bang, deux places de maturation et une sonde de plus ; au huitième, "
                + "les matières exotiques : cinq astres sans assemblage, que la galaxie demande aussi."));
        if (game.isProbesUnlocked()) sections.add(new Section("Sondes", "Dans le Big Bang, depuis le troisième. On choisit une "
                + "destination, puis un voyage de " + (int) (ProbeTrip.SHORT.seconds() / 60) + " minutes à " + (int) (ProbeTrip.NIGHT.seconds() / 3600) + " heures ; plus il est long, plus le butin est riche par heure. À l'"
                + "arrivée, la sonde attend à destination : un clic sur elle" + claimKey(settings) + " ouvre son butin, une carte par clic, ou tout d'un coup : des éléments "
                + "du rayon visé, de l'espace d'un coup, un sursaut qui double l'espace par seconde un moment, des échantillons. "
                + "Les échantillons paient les améliorations : instruments, moteurs, réserves d'énergie, soute et hangar. "
                + "Rien ne se perd si l'on revient tard, ni au Big Bang."));
        sections.add(new Section("Sauvegarde et absence", "La partie s'écrit toute seule toutes les "
                + settings.saveDelay().label() + " (le rythme se choisit dans les réglages) et à la fermeture. Au retour, "
                + (settings.offline() ? "" : "si le temps hors ligne est rejoué (il est coupé en ce moment), ")
                + "une part du temps d'absence est rejouée : " + ElementText.percent(Game.OFFLINE_RATE_PARTICLES) + " au début, "
                + ElementText.percent(Game.OFFLINE_RATE_UNIVERSE) + " une fois l'univers formé, sur "
                + (int) (Absence.MAX_SECONDS / 3600) + " heures d'absence au plus. Les réglages permettent d'exporter la partie, de régler le volume des sons ou de les "
                + "couper, de limiter les images par seconde ou de couper les effets visuels un par un ; la fenêtre ralentit d'elle-même quand "
                + "elle n'est pas au premier plan. Des thèmes et des notations s'y ouvrent en faisant des choses très précises."));
        sections.add(new Section("Raccourcis clavier", shortcuts(settings)));
        return sections;
    }

    /** « (ou la touche R) » : la touche réglée pour réclamer un butin de sonde, rien si elle n'en a pas (version 0.126). */
    private static String claimKey(Settings settings) {
        KeyCode key = settings.shortcuts() ? settings.key(Shortcuts.Action.CLAIM) : null;
        return key == null ? "" : " (ou la touche " + Shortcuts.name(key) + ")";
    }

    /** La liste des raccourcis avec leurs touches du moment, un par ligne. */
    static String shortcuts(Settings settings) {
        if (!settings.shortcuts()) return "Les raccourcis sont coupés dans les réglages.";
        StringBuilder text = new StringBuilder();
        for (Shortcuts.Action action : Shortcuts.Action.values()) {
            KeyCode key = settings.key(action);
            if (text.length() > 0) text.append('\n');
            text.append(key == null ? "(aucune touche)" : Shortcuts.name(key)).append("  —  ").append(action.label());
        }
        text.append('\n').append(Detail.keyName(settings.detailKey())).append("  —  Afficher les détails")
                .append("\nLes touches se changent dans les réglages.");
        return text.toString();
    }
}
