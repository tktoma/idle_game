package idle.ui.universe;

import idle.core.Game;
import idle.core.universe.DimensionAutomation;
import idle.ui.common.CanvasPane;
import idle.ui.common.Format;
import idle.core.math.BigNum;
import idle.ui.common.Labels;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

/**
 * La fenêtre d'une dimension (version 0.081) : elle couvre tout le jeu, avec son visuel, son nom et
 * une phrase, et un bouton « Retour » pour revenir au jeu. Le jeu continue de tourner derrière.
 *
 * <p>La première, la ligne, a sa logique depuis la version 0.101 : ses éclats de dimension, son seuil et ses
 * cinq améliorations (version 0.102) sous le visuel. Le plan a la sienne depuis la version 0.104, et le volume depuis
 * la version 0.128 : on plonge dans le cube, et ses améliorations s'achètent ici, une fois ressorti. La durée a la
 * sienne depuis la version 0.134 : on tient le bouton du milieu, les spirales avancent, on relâche. La boucle a la
 * sienne depuis la version 0.153 : on clique chaque cercle (ou sa touche) quand son point passe dans une zone ; ses
 * six améliorations, son métronome et le rappel des touches sont sous la vue. La brane a la sienne depuis la version
 * 0.154 : on appuie la membrane, on glisse pour la tendre, on relâche, et l'onde qui part rebondit sur ses bords ; ses
 * cinq améliorations sont sous la vue. Le clicker a la sienne depuis la version 0.155 : on clique la surface, d'autant
 * plus vite que chaque clic rapporte davantage, et dans les zones ×2 qui s'y superposent ; ses huit améliorations sont
 * sous la vue. La grille a la sienne depuis la version 0.156 : on choisit une couche du cube (boutons, molette ou flèches
 * haut et bas) et l'on sonde ses cases ; ce que la grille montre du point le plus proche suit l'amélioration
 * « Affichage du point », jamais plus ; refaite en 0.157 : mille cases par côté au départ, on vise une case (un clic sur
 * la carte, ou ses coordonnées) et on l'essaie, un essai par point caché. Le miroir a la sienne depuis la version 0.157 :
 * un motif s'allume à gauche, on le refait de mémoire, en miroir, à droite ; ses cinq améliorations sont sous la vue.
 *
 * <p>Le mélange a la sienne depuis la version 0.158, refaite en 0.159 : l'arène en grand, où se mêlent étape par étape
 * les mécaniques des autres dimensions ; au-dessus, l'étape, sa barre de progression et « Mêler la dimension suivante » ;
 * dessous, les fragments, le malus, les multiplicateurs, la charge, la cadence, ce qu'on fait à l'étape en cours, et ses
 * onze améliorations, grisées tant que leur étape n'est pas atteinte. Au clavier, Z Q S D et les flèches mènent le point,
 * A et E le font remonter ou plonger, la barre d'espace tient la charge.
 *
 * <p>Depuis la version 0.150, le jeu peut jouer seul le plan, le volume et la durée (l'automatisation des dimensions) :
 * une mention « automatique », à droite du titre, le dit tant que l'automatisme de jeu de la dimension tourne (pour la
 * ligne, qui avance seule, tant qu'un de ses achats automatiques tourne), et les explications disent ce qu'il fait.
 * Fermer la fenêtre n'arrête alors ni la plongée ni l'appui : ils continuent derrière. Le rythme automatique de la
 * boucle (version 0.153), la tirée automatique de la brane (version 0.154), les clics automatiques du clicker (version
 * 0.155), les essais automatiques de la grille (version 0.156) et le miroir automatique (version 0.157) jouent de même,
 * fenêtre ouverte ou non.
 */
public final class DimensionWindow extends BorderPane {

    private static final String BUTTON_STYLE = "-fx-font-size: 13px; -fx-padding: 8 16; -fx-cursor: hand; -fx-background-radius: 6;"
            + " -fx-border-radius: 6; -fx-text-fill: " + UniversePage.COLOR + "; -fx-background-color: #141a2c; -fx-border-color: #3b4670;";

    /** La couleur de chaque dimension, celle de ses éclats : ses améliorations achetables la prennent (version 0.140). */
    private static final String PLANE_COLOR = "#ffd27f", VOLUME_COLOR = "#c9a6ff", DURATION_COLOR = "#9be7a8", LOOP_COLOR = "#ff9eb5",
            BRANE_COLOR = "#7fe0d4", CLICKER_COLOR = "#ffb36b", GRID_COLOR = "#a8b8ff",
            MIRROR_COLOR = "#ff7ad9", MIX_COLOR = "#fff1c9";
    private static final String UPGRADE_STYLE = "-fx-font-size: 13px; -fx-background-radius: 6; -fx-border-radius: 6; -fx-opacity: 1;";

    /** La couleur de la dimension {@code number} (1 à 10), celle de ses éclats ; celle de l'univers pour la ligne et au-delà. */
    public static String color(int number) {
        return switch (number) {
            case 2 -> PLANE_COLOR;
            case 3 -> VOLUME_COLOR;
            case 4 -> DURATION_COLOR;
            case 5 -> LOOP_COLOR;
            case 6 -> BRANE_COLOR;
            case 7 -> CLICKER_COLOR;
            case 8 -> GRID_COLOR;
            case 9 -> MIRROR_COLOR;
            case 10 -> MIX_COLOR;
            default -> UniversePage.COLOR;
        };
    }

    /**
     * Les couleurs d'un bouton d'amélioration (version 0.140 : plus visibles, même format). Achetable, il prend la couleur
     * de sa dimension : bordure épaisse, halo, texte blanc. Sinon il reste lisible (JavaFX éteint à 40 % ce qui est
     * désactivé, le bouton garde son opacité). Au plus haut, il passe au vert. La bordure plus épaisse prend sur le
     * retrait du texte : le bouton ne change pas de taille.
     */
    static void paintUpgrade(Button button, boolean buyable, boolean full, String accent) {
        String look = full
                ? " -fx-padding: 8 16; -fx-border-width: 1; -fx-text-fill: #9be7a8; -fx-background-color: #14261b; -fx-border-color: #4f9a5c;"
                : buyable
                ? " -fx-padding: 7 15; -fx-border-width: 2; -fx-cursor: hand; -fx-text-fill: #ffffff;"
                        + " -fx-background-color: linear-gradient(#27314f, #1a2240); -fx-border-color: " + accent + ";"
                        + " -fx-effect: dropshadow(gaussian, " + accent + "66, 10, 0.25, 0, 0);"
                : " -fx-padding: 8 16; -fx-border-width: 1; -fx-text-fill: #9aa3bd; -fx-background-color: #10141f; -fx-border-color: #2c3450;";
        button.setStyle(UPGRADE_STYLE + look);
    }

    /** Les touches des sept cercles de la boucle tant que le joueur n'en a pas choisi d'autres (version 0.153). */
    public static final java.util.List<javafx.scene.input.KeyCode> DEFAULT_LOOP_KEYS = java.util.List.of(
            javafx.scene.input.KeyCode.S, javafx.scene.input.KeyCode.D, javafx.scene.input.KeyCode.F,
            javafx.scene.input.KeyCode.SPACE, javafx.scene.input.KeyCode.J, javafx.scene.input.KeyCode.K,
            javafx.scene.input.KeyCode.L);

    /**
     * Ce que la boucle demande au jeu (version 0.153) : la touche de chaque cercle et le choix du métronome, rangés dans
     * les réglages, et le tic qu'il joue, au volume et selon le réglage des sons.
     */
    public interface LoopSettings {
        /** La touche du cercle {@code ring} (0 à 6), ou {@code null} s'il n'en a pas. */
        javafx.scene.input.KeyCode loopKey(int ring);

        boolean metronome();

        void setMetronome(boolean on);

        /** Un battement du métronome : le tic, si les sons sont actifs. */
        void beat();
    }

    /** Les réglages de la boucle d'une fenêtre seule (pour les vérifications) : les touches d'origine, un métronome muet. */
    private static final class LocalLoopSettings implements LoopSettings {
        private boolean metronome;

        @Override
        public javafx.scene.input.KeyCode loopKey(int ring) {
            return ring >= 0 && ring < DEFAULT_LOOP_KEYS.size() ? DEFAULT_LOOP_KEYS.get(ring) : null;
        }

        @Override
        public boolean metronome() {
            return metronome;
        }

        @Override
        public void setMetronome(boolean on) {
            metronome = on;
        }

        @Override
        public void beat() {
        }
    }

    private final Game game;
    private final DimensionView view;
    /** La ligne : ses éclats, et ses cinq améliorations. */
    private final Label shards = new Label();
    private final Label threshold = new Label();
    private final java.util.Map<Game.LineUpgrade, Button> buttons = new java.util.EnumMap<>(Game.LineUpgrade.class);
    private final VBox linePane;
    /** Le plan (version 0.104) : ses éclats, la manière de jouer, et ses cinq améliorations. */
    private final Label planeShards = new Label();
    private final Label planeThreshold = new Label();
    private final Label planeHint = new Label();
    private final java.util.Map<Game.PlaneUpgrade, Button> planeButtons = new java.util.EnumMap<>(Game.PlaneUpgrade.class);
    private final VBox planePane;
    /** Le volume (version 0.128) : ses éclats, son seuil, ce qu'on y fait, et ses cinq améliorations, dehors. */
    private final Label volumeShards = new Label();
    private final Label volumeThreshold = new Label();
    private final Label volumeHint = new Label();
    private final Label volumeDetail = new Label();
    private final java.util.Map<Game.VolumeUpgrade, Button> volumeButtons = new java.util.EnumMap<>(Game.VolumeUpgrade.class);
    private final javafx.scene.layout.FlowPane volumeRow = new javafx.scene.layout.FlowPane(12, 10);
    private final VBox volumePane;
    /** La durée (version 0.134) : ses éclats, son seuil, ce qu'on y fait, et ses quatre améliorations. */
    private final Label durationShards = new Label();
    private final Label durationThreshold = new Label();
    private final Label durationHint = new Label();
    private final Label durationDetail = new Label();
    private final java.util.Map<Game.DurationUpgrade, Button> durationButtons = new java.util.EnumMap<>(Game.DurationUpgrade.class);
    private final VBox durationPane;
    /** La boucle (version 0.153) : ses nœuds, son seuil, ce qu'on y fait, son métronome, et ses six améliorations. */
    private final Label loopShards = new Label();
    private final Label loopThreshold = new Label();
    private final Label loopHint = new Label();
    private final Label loopDetail = new Label();
    private final Button metronomeButton = new Button();
    private final java.util.Map<Game.LoopUpgrade, Button> loopButtons = new java.util.EnumMap<>(Game.LoopUpgrade.class);
    private final VBox loopPane;
    private LoopSettings loopSettings = new LocalLoopSettings();
    /** La brane (version 0.154) : ses ondes, son seuil, ce qu'on y fait, et ses cinq améliorations. */
    private final Label braneShards = new Label();
    private final Label braneThreshold = new Label();
    private final Label braneHint = new Label();
    private final Label braneDetail = new Label();
    private final java.util.Map<Game.BraneUpgrade, Button> braneButtons = new java.util.EnumMap<>(Game.BraneUpgrade.class);
    private final VBox branePane;
    /** Le clicker (version 0.155) : ses étincelles, son seuil, ce qu'on y fait, et ses huit améliorations. */
    private final Label clickerShards = new Label();
    private final Label clickerThreshold = new Label();
    private final Label clickerHint = new Label();
    private final Label clickerDetail = new Label();
    private final java.util.Map<Game.ClickerUpgrade, Button> clickerButtons = new java.util.EnumMap<>(Game.ClickerUpgrade.class);
    private final VBox clickerPane;
    /** La grille (version 0.156) : ses repères, son seuil, ce qu'on y fait, la couche montrée, et ses cinq améliorations. */
    private final Label gridShards = new Label();
    private final Label gridThreshold = new Label();
    private final Label gridHint = new Label();
    private final Label gridDetail = new Label();
    private final Label gridLayerLabel = new Label();
    private final Button gridDown = new Button("▼ Couche du dessous");
    private final Button gridUp = new Button("Couche du dessus ▲");
    private final java.util.Map<Game.GridUpgrade, Button> gridButtons = new java.util.EnumMap<>(Game.GridUpgrade.class);
    /** Version 0.157 : la taille de la grille, la case visée (x, y, z), le bouton qui l'essaie, et le zoom de la carte. */
    private final Label gridSize = new Label();
    private final TextField gridX = new TextField(), gridY = new TextField(), gridZ = new TextField();
    private final Button gridTry = new Button("Essayer");
    private final Button gridZoomIn = new Button("Zoom +"), gridZoomOut = new Button("Zoom −");
    private final VBox gridPane;
    /** Le miroir (version 0.157) : ses reflets, son seuil, ce qu'on y fait, ses compteurs, et ses cinq améliorations. */
    private final Label mirrorShards = new Label();
    private final Label mirrorThreshold = new Label();
    private final Label mirrorHint = new Label();
    private final Label mirrorCounts = new Label();
    /** Version 0.158 : la taille du plateau, et les réussites qu'il manque pour l'agrandir. */
    private final Label mirrorBoard = new Label();
    private final Label mirrorDetail = new Label();
    private final java.util.Map<Game.MirrorUpgrade, Button> mirrorButtons = new java.util.EnumMap<>(Game.MirrorUpgrade.class);
    private final VBox mirrorPane;
    /**
     * Le mélange (version 0.159) : au-dessus de l'arène, l'étape, sa barre de progression et le bouton qui mêle la
     * dimension suivante ; dessous, ses fragments, son seuil, ses compteurs (malus, multiplicateurs, charge, cadence),
     * ce qu'on y fait à l'étape en cours, le détail et ses onze améliorations.
     */
    private final Label mixStage = new Label();
    private final Label mixProgress = new Label();
    private final Region mixBarFill = new Region(), mixBarRest = new Region();
    private final Button mixAdvance = new Button("Mêler la dimension suivante");
    private final VBox mixStageBox;
    private final Label mixShards = new Label();
    private final Label mixThreshold = new Label();
    private final Label mixInfo = new Label();
    private final Label mixHint = new Label();
    private final Label mixDetail = new Label();
    private final java.util.Map<Game.MixUpgrade, Button> mixButtons = new java.util.EnumMap<>(Game.MixUpgrade.class);
    private final VBox mixPane;
    /** La clé de la rangée des améliorations du mélange, dans {@link #painted} : elle compte aussi l'étape. */
    private final Object mixRowKey = new Object();
    /** La largeur de la barre de progression de l'étape. */
    private static final double MIX_BAR_WIDTH = 420;
    /** Les touches de cercles tenues : une touche tenue se répète, mais ne rejoue pas son cercle. */
    private final java.util.Set<javafx.scene.input.KeyCode> loopKeysHeld = java.util.EnumSet.noneOf(javafx.scene.input.KeyCode.class);
    /** La barre d'espace tient le bouton de la durée, ou la charge du mélange, comme la souris. */
    private boolean spaceHeld;
    /** La caméra libre (version 0.128) : le bouton, et où se range le choix (les réglages du jeu, ou la fenêtre seule). */
    private final Button freeCameraButton = new Button();
    private final java.util.function.BooleanSupplier freeCamera;
    private final java.util.function.Consumer<Boolean> setFreeCamera;
    /** Les touches de direction tenues : Z, Q, S, D et les flèches. */
    private final java.util.Set<javafx.scene.input.KeyCode> held = java.util.EnumSet.noneOf(javafx.scene.input.KeyCode.class);
    private final Label title = new Label();
    /** La mention « automatique » (version 0.150), à droite du titre : l'automatisation joue la dimension. */
    private final Label autoBadge = new Label("automatique");
    private final Label line = new Label();
    private final Button back = new Button("← Retour");
    /**
     * Ce que chaque rangée de boutons et chaque explication a montré en dernier (niveaux, achetabilité, détails demandés) :
     * {@link #refresh()} tourne à chaque image, les longs textes ne se refont que si ça change.
     */
    private final java.util.Map<Object, String> painted = new java.util.HashMap<>();

    /** Une fenêtre qui garde seule le choix de la caméra libre : pour les vérifications. */
    public DimensionWindow(Game game) {
        this(game, new boolean[1]);
    }

    private DimensionWindow(Game game, boolean[] free) {
        this(game, () -> free[0], value -> free[0] = value);
    }

    /** La fenêtre des dimensions ; le choix de la caméra libre du volume se lit et s'écrit par ces deux fonctions. */
    public DimensionWindow(Game game, java.util.function.BooleanSupplier freeCamera, java.util.function.Consumer<Boolean> setFreeCamera) {
        this.game = game;
        this.freeCamera = freeCamera;
        this.setFreeCamera = setFreeCamera;
        this.view = new DimensionView(game);
        setStyle("-fx-background-color: #05060e;");
        setPadding(new Insets(12, 16, 16, 16));
        back.setStyle("-fx-font-size: 13px; -fx-padding: 6 16; -fx-cursor: hand; -fx-background-radius: 6; -fx-border-radius: 6;"
                + " -fx-text-fill: " + UniversePage.COLOR + "; -fx-background-color: #141a2c; -fx-border-color: #3b4670;");
        back.setFocusTraversable(false);
        back.setOnAction(event -> close());
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: " + UniversePage.COLOR + ";");
        line.setStyle("-fx-font-size: 13px; -fx-text-fill: #c8d4ea;");
        line.setWrapText(true);
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        // Une marge à droite aussi large que le bouton, pour que le titre reste au milieu ; la mention « automatique » s'y loge.
        autoBadge.setMinWidth(110);
        autoBadge.setAlignment(Pos.CENTER_RIGHT);
        autoBadge.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-text-fill: #9be7a8;");
        autoBadge.setVisible(false);
        Region after = new Region();
        HBox.setHgrow(after, Priority.ALWAYS);
        HBox top = new HBox(12, back, spacer, title, after, autoBadge);
        top.setAlignment(Pos.CENTER_LEFT);
        VBox head = new VBox(6, top, line);
        head.setAlignment(Pos.CENTER);
        line.setMaxWidth(Double.MAX_VALUE);
        line.setAlignment(Pos.CENTER);
        head.setPadding(new Insets(0, 0, 10, 0));
        setTop(head);
        // Au-dessus de la vue, l'étape du mélange (version 0.159), cachée dans les autres dimensions.
        Labels.centered(mixStage, "-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + MIX_COLOR + ";");
        mixProgress.setStyle("-fx-font-size: 12px; -fx-text-fill: #c8d4ea;");
        mixBarFill.setStyle("-fx-background-color: " + MIX_COLOR + "; -fx-background-radius: 4 0 0 4;");
        mixBarRest.setStyle("-fx-background-color: #1a2032; -fx-background-radius: 0 4 4 0;");
        for (Region part : new Region[] {mixBarFill, mixBarRest}) {
            part.setMinHeight(10);
            part.setMaxHeight(10);
        }
        HBox mixBar = new HBox(0, mixBarFill, mixBarRest);
        mixBar.setAlignment(Pos.CENTER_LEFT);
        mixBar.setMaxWidth(MIX_BAR_WIDTH);
        mixAdvance.setStyle(BUTTON_STYLE);
        mixAdvance.setFocusTraversable(false);
        mixAdvance.setOnAction(event -> {
            game.advanceMix();
            refresh();
        });
        HBox mixBarRow = new HBox(12, mixBar, mixProgress, mixAdvance);
        mixBarRow.setAlignment(Pos.CENTER);
        mixStageBox = new VBox(6, mixStage, mixBarRow);
        mixStageBox.setAlignment(Pos.CENTER);
        mixStageBox.setPadding(new Insets(0, 0, 8, 0));
        CanvasPane holder = CanvasPane.filling(view);
        VBox.setVgrow(holder, Priority.ALWAYS);
        VBox middle = new VBox(mixStageBox, holder);
        middle.setAlignment(Pos.CENTER);
        setCenter(middle);
        shards.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + UniversePage.COLOR + ";");
        threshold.setStyle("-fx-font-size: 13px; -fx-text-fill: #9be7a8;");
        javafx.scene.layout.FlowPane row = new javafx.scene.layout.FlowPane(12, 10);
        row.setAlignment(Pos.CENTER);
        for (Game.LineUpgrade upgrade : Game.LineUpgrade.values()) {
            Button button = upgradeButton(250, () -> game.buyLine(upgrade));
            buttons.put(upgrade, button);
            row.getChildren().add(button);
        }
        linePane = new VBox(10, shards, threshold, row);
        linePane.setAlignment(Pos.CENTER);
        linePane.setPadding(new Insets(10, 0, 0, 0));
        planeShards.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #ffd27f;");
        planeHint.setStyle("-fx-font-size: 13px; -fx-text-fill: #c8d4ea;");
        javafx.scene.layout.FlowPane planeRow = new javafx.scene.layout.FlowPane(12, 10);
        planeRow.setAlignment(Pos.CENTER);
        for (Game.PlaneUpgrade upgrade : Game.PlaneUpgrade.values()) {
            Button button = upgradeButton(250, () -> game.buyPlane(upgrade));
            planeButtons.put(upgrade, button);
            planeRow.getChildren().add(button);
        }
        planeThreshold.setStyle("-fx-font-size: 13px; -fx-text-fill: #9be7a8;");
        planePane = new VBox(10, planeShards, planeThreshold, planeHint, planeRow);
        planePane.setAlignment(Pos.CENTER);
        planePane.setPadding(new Insets(10, 0, 0, 0));
        volumeShards.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #c9a6ff;");
        volumeThreshold.setStyle("-fx-font-size: 13px; -fx-text-fill: #9be7a8;");
        volumeHint.setStyle("-fx-font-size: 13px; -fx-text-fill: #c8d4ea;");
        volumeHint.setWrapText(true);
        Labels.note(volumeDetail, 820);
        volumeRow.setAlignment(Pos.CENTER);
        for (Game.VolumeUpgrade upgrade : Game.VolumeUpgrade.values()) {
            Button button = upgradeButton(200, () -> game.buyVolume(upgrade));   // les cinq tiennent sur une ligne : la vue du cube garde sa hauteur
            volumeButtons.put(upgrade, button);
            volumeRow.getChildren().add(button);
        }
        freeCameraButton.setStyle(BUTTON_STYLE);
        freeCameraButton.setFocusTraversable(false);
        freeCameraButton.setOnAction(event -> {
            this.setFreeCamera.accept(!this.freeCamera.getAsBoolean());
            view.setFreeCamera(this.freeCamera.getAsBoolean());
            refresh();
        });
        volumePane = new VBox(10, volumeShards, volumeThreshold, volumeHint, freeCameraButton, volumeDetail, volumeRow);
        volumePane.setAlignment(Pos.CENTER);
        volumePane.setPadding(new Insets(10, 0, 0, 0));
        durationShards.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #9be7a8;");
        durationThreshold.setStyle("-fx-font-size: 13px; -fx-text-fill: #9be7a8;");
        Labels.centered(durationHint, "-fx-font-size: 13px; -fx-text-fill: #c8d4ea;");
        durationHint.setMaxWidth(820);
        durationHint.setAlignment(Pos.CENTER);
        // Deux lignes toujours : le rond ne bouge pas quand le texte change, bouton tenu ou relâché.
        durationHint.setMinHeight(38);
        durationHint.setPrefHeight(38);
        Labels.note(durationDetail, 820);
        javafx.scene.layout.FlowPane durationRow = new javafx.scene.layout.FlowPane(12, 10);
        durationRow.setAlignment(Pos.CENTER);
        for (Game.DurationUpgrade upgrade : Game.DurationUpgrade.values()) {
            Button button = upgradeButton(230, () -> game.buyDuration(upgrade));
            durationButtons.put(upgrade, button);
            durationRow.getChildren().add(button);
        }
        durationPane = new VBox(10, durationShards, durationThreshold, durationHint, durationDetail, durationRow);
        durationPane.setAlignment(Pos.CENTER);
        durationPane.setPadding(new Insets(10, 0, 0, 0));
        loopShards.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + LOOP_COLOR + ";");
        loopThreshold.setStyle("-fx-font-size: 13px; -fx-text-fill: #9be7a8;");
        Labels.centered(loopHint, "-fx-font-size: 13px; -fx-text-fill: #c8d4ea;");
        loopHint.setMaxWidth(820);
        loopHint.setAlignment(Pos.CENTER);
        // Deux lignes toujours, comme pour la durée : les cercles ne bougent pas quand le texte change.
        loopHint.setMinHeight(38);
        loopHint.setPrefHeight(38);
        Labels.note(loopDetail, 820);
        metronomeButton.setStyle(BUTTON_STYLE);
        metronomeButton.setFocusTraversable(false);
        metronomeButton.setOnAction(event -> {
            loopSettings.setMetronome(!loopSettings.metronome());
            refresh();
        });
        javafx.scene.layout.FlowPane loopRow = new javafx.scene.layout.FlowPane(12, 10);
        loopRow.setAlignment(Pos.CENTER);
        for (Game.LoopUpgrade upgrade : Game.LoopUpgrade.values()) {
            Button button = upgradeButton(250, () -> game.buyLoop(upgrade));
            loopButtons.put(upgrade, button);
            loopRow.getChildren().add(button);
        }
        loopPane = new VBox(10, loopShards, loopThreshold, loopHint, metronomeButton, loopDetail, loopRow);
        loopPane.setAlignment(Pos.CENTER);
        loopPane.setPadding(new Insets(10, 0, 0, 0));
        braneShards.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + BRANE_COLOR + ";");
        braneThreshold.setStyle("-fx-font-size: 13px; -fx-text-fill: #9be7a8;");
        Labels.centered(braneHint, "-fx-font-size: 13px; -fx-text-fill: #c8d4ea;");
        braneHint.setMaxWidth(820);
        braneHint.setAlignment(Pos.CENTER);
        // Deux lignes toujours : la membrane ne bouge pas quand le texte change, tenue ou relâchée.
        braneHint.setMinHeight(38);
        braneHint.setPrefHeight(38);
        Labels.note(braneDetail, 820);
        javafx.scene.layout.FlowPane braneRow = new javafx.scene.layout.FlowPane(12, 10);
        braneRow.setAlignment(Pos.CENTER);
        for (Game.BraneUpgrade upgrade : Game.BraneUpgrade.values()) {
            Button button = upgradeButton(250, () -> game.buyBrane(upgrade));
            braneButtons.put(upgrade, button);
            braneRow.getChildren().add(button);
        }
        branePane = new VBox(10, braneShards, braneThreshold, braneHint, braneDetail, braneRow);
        branePane.setAlignment(Pos.CENTER);
        branePane.setPadding(new Insets(10, 0, 0, 0));
        clickerShards.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + CLICKER_COLOR + ";");
        clickerThreshold.setStyle("-fx-font-size: 13px; -fx-text-fill: #9be7a8;");
        Labels.centered(clickerHint, "-fx-font-size: 13px; -fx-text-fill: #c8d4ea;");
        clickerHint.setMaxWidth(820);
        clickerHint.setAlignment(Pos.CENTER);
        // Deux lignes toujours : la surface ne bouge pas quand la cadence change.
        clickerHint.setMinHeight(38);
        clickerHint.setPrefHeight(38);
        Labels.note(clickerDetail, 820);
        javafx.scene.layout.FlowPane clickerRow = new javafx.scene.layout.FlowPane(10, 8);
        clickerRow.setAlignment(Pos.CENTER);
        for (Game.ClickerUpgrade upgrade : Game.ClickerUpgrade.values()) {
            // Huit sur deux lignes : la surface garde sa hauteur.
            Button button = upgradeButton(200, () -> game.buyClicker(upgrade));
            clickerButtons.put(upgrade, button);
            clickerRow.getChildren().add(button);
        }
        clickerPane = new VBox(10, clickerShards, clickerThreshold, clickerHint, clickerDetail, clickerRow);
        clickerPane.setAlignment(Pos.CENTER);
        clickerPane.setPadding(new Insets(10, 0, 0, 0));
        gridShards.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + GRID_COLOR + ";");
        gridThreshold.setStyle("-fx-font-size: 13px; -fx-text-fill: #9be7a8;");
        Labels.centered(gridHint, "-fx-font-size: 13px; -fx-text-fill: #c8d4ea;");
        gridHint.setMaxWidth(820);
        gridHint.setAlignment(Pos.CENTER);
        // Deux lignes toujours : la grille ne bouge pas quand le dernier essai change le texte.
        gridHint.setMinHeight(38);
        gridHint.setPrefHeight(38);
        Labels.note(gridDetail, 820);
        gridLayerLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: " + GRID_COLOR + ";");
        gridLayerLabel.setMinWidth(120);
        gridLayerLabel.setAlignment(Pos.CENTER);
        for (Button button : new Button[] {gridDown, gridUp}) {
            button.setStyle(BUTTON_STYLE);
            button.setFocusTraversable(false);
        }
        gridDown.setOnAction(event -> {
            view.shiftGridLayer(-1);
            refresh();
        });
        gridUp.setOnAction(event -> {
            view.shiftGridLayer(1);
            refresh();
        });
        gridLayerLabel.setMinWidth(200);
        HBox gridLayers = new HBox(10, gridDown, gridLayerLabel, gridUp);
        gridLayers.setAlignment(Pos.CENTER);
        gridSize.setStyle("-fx-font-size: 13px; -fx-text-fill: #c8d4ea;");
        HBox gridAim = new HBox(8);
        gridAim.setAlignment(Pos.CENTER);
        String[] axes = {"x", "y", "z"};
        TextField[] fields = {gridX, gridY, gridZ};
        for (int axis = 0; axis < 3; axis++) {
            TextField field = fields[axis];
            field.setPrefWidth(70);
            field.setOnAction(event -> {
                selectFromFields();
                view.tryGrid();
                refresh();
            });
            field.textProperty().addListener((obs, was, now) -> {
                if (field.isFocused()) selectFromFields();
            });
            Label name = new Label(axes[axis]);
            name.setStyle("-fx-font-size: 13px; -fx-text-fill: " + GRID_COLOR + ";");
            gridAim.getChildren().addAll(name, field);
        }
        for (Button button : new Button[] {gridTry, gridZoomIn, gridZoomOut}) {
            button.setStyle(BUTTON_STYLE);
            button.setFocusTraversable(false);
        }
        gridTry.setOnAction(event -> {
            selectFromFields();
            view.tryGrid();
            refresh();
        });
        gridZoomIn.setOnAction(event -> {
            view.zoomGrid(1);
            refresh();
        });
        gridZoomOut.setOnAction(event -> {
            view.zoomGrid(-1);
            refresh();
        });
        gridAim.getChildren().addAll(gridTry, gridZoomOut, gridZoomIn);
        javafx.scene.layout.FlowPane gridRow = new javafx.scene.layout.FlowPane(12, 10);
        gridRow.setAlignment(Pos.CENTER);
        for (Game.GridUpgrade upgrade : Game.GridUpgrade.values()) {
            Button button = upgradeButton(230, () -> game.buyGrid(upgrade));
            gridButtons.put(upgrade, button);
            gridRow.getChildren().add(button);
        }
        gridPane = new VBox(8, gridShards, gridThreshold, gridSize, gridHint, gridLayers, gridAim, gridDetail, gridRow);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setPadding(new Insets(10, 0, 0, 0));
        mirrorShards.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + MIRROR_COLOR + ";");
        mirrorThreshold.setStyle("-fx-font-size: 13px; -fx-text-fill: #9be7a8;");
        mirrorCounts.setStyle("-fx-font-size: 13px; -fx-text-fill: #c8d4ea;");
        mirrorBoard.setStyle("-fx-font-size: 13px; -fx-text-fill: " + MIRROR_COLOR + ";");
        Labels.centered(mirrorHint, "-fx-font-size: 13px; -fx-text-fill: #c8d4ea;");
        mirrorHint.setMaxWidth(820);
        mirrorHint.setAlignment(Pos.CENTER);
        // Deux lignes toujours : le plateau ne bouge pas quand la phase change le texte.
        mirrorHint.setMinHeight(38);
        mirrorHint.setPrefHeight(38);
        Labels.note(mirrorDetail, 820);
        javafx.scene.layout.FlowPane mirrorRow = new javafx.scene.layout.FlowPane(12, 10);
        mirrorRow.setAlignment(Pos.CENTER);
        for (Game.MirrorUpgrade upgrade : Game.MirrorUpgrade.values()) {
            Button button = upgradeButton(230, () -> game.buyMirror(upgrade));
            mirrorButtons.put(upgrade, button);
            mirrorRow.getChildren().add(button);
        }
        mirrorPane = new VBox(10, mirrorShards, mirrorThreshold, mirrorBoard, mirrorCounts, mirrorHint, mirrorDetail, mirrorRow);
        mirrorPane.setAlignment(Pos.CENTER);
        mirrorPane.setPadding(new Insets(10, 0, 0, 0));
        mixShards.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + MIX_COLOR + ";");
        mixThreshold.setStyle("-fx-font-size: 13px; -fx-text-fill: #9be7a8;");
        Labels.centered(mixInfo, "-fx-font-size: 13px; -fx-text-fill: " + MIX_COLOR + ";");
        mixInfo.setMaxWidth(860);
        Labels.centered(mixHint, "-fx-font-size: 13px; -fx-text-fill: #c8d4ea;");
        mixHint.setMaxWidth(860);
        mixHint.setAlignment(Pos.CENTER);
        Labels.note(mixDetail, 860);
        javafx.scene.layout.FlowPane mixRow = new javafx.scene.layout.FlowPane(10, 8);
        mixRow.setAlignment(Pos.CENTER);
        for (Game.MixUpgrade upgrade : Game.MixUpgrade.values()) {
            Button button = upgradeButton(210, () -> game.buyMix(upgrade));
            mixButtons.put(upgrade, button);
            mixRow.getChildren().add(button);
        }
        mixPane = new VBox(8, mixShards, mixThreshold, mixInfo, mixHint, mixDetail, mixRow);
        mixPane.setAlignment(Pos.CENTER);
        mixPane.setPadding(new Insets(10, 0, 0, 0));
        setBottom(new VBox(linePane, planePane, volumePane, durationPane, loopPane, branePane, clickerPane, gridPane, mirrorPane, mixPane));
        setVisible(false);
    }

    /** Les réglages de la boucle : où se lisent les touches des cercles et le métronome, et ce qui joue son tic. */
    public void setLoopSettings(LoopSettings settings) {
        loopSettings = settings == null ? new LocalLoopSettings() : settings;
    }

    /** Un bouton d'amélioration : large de {@code width}, haut de deux lignes, qui achète puis rafraîchit. */
    private Button upgradeButton(double width, Runnable buy) {
        Button button = new Button();
        button.setStyle(BUTTON_STYLE);
        button.setFocusTraversable(false);
        button.setWrapText(true);
        button.setPrefWidth(width);
        button.setMinHeight(64);
        button.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        button.setOnAction(event -> {
            buy.run();
            refresh();
        });
        return button;
    }

    /**
     * Vrai si l'automatisation joue la dimension montrée : son automatisme de jeu tourne (la visée, la plongée, l'appui) ;
     * pour la ligne, qui n'en a pas, un de ses achats automatiques.
     */
    private boolean automatic() {
        for (DimensionAutomation automation : DimensionAutomation.values()) {
            if (automation.dimension() != view.dimension().number() || !game.isDimensionAutomationRunning(automation)) continue;
            if (automation.kind() == DimensionAutomation.Kind.PLAY || automation.dimension() == 1) return true;
        }
        return false;
    }

    /** Recopie la dimension montrée (de la ligne au mélange) : ses éclats, et ce que coûtent ses améliorations. */
    private void refresh() {
        autoBadge.setVisible(automatic());
        boolean mix = view.dimension() == Dimension.MIX && game.isMixOpen();
        mixPane.setVisible(mix);
        mixPane.setManaged(mix);
        mixStageBox.setVisible(mix);
        mixStageBox.setManaged(mix);
        if (mix) refreshMix();
        boolean mirror = view.dimension() == Dimension.MIRROR && game.isMirrorOpen();
        mirrorPane.setVisible(mirror);
        mirrorPane.setManaged(mirror);
        if (mirror) refreshMirror();
        boolean grid = view.dimension() == Dimension.GRID && game.isGridOpen();
        gridPane.setVisible(grid);
        gridPane.setManaged(grid);
        if (grid) refreshGrid();
        boolean clicker = view.dimension() == Dimension.CLICKER && game.isClickerOpen();
        clickerPane.setVisible(clicker);
        clickerPane.setManaged(clicker);
        if (clicker) refreshClicker();
        boolean brane = view.dimension() == Dimension.BRANE && game.isBraneOpen();
        branePane.setVisible(brane);
        branePane.setManaged(brane);
        if (brane) refreshBrane();
        boolean loop = view.dimension() == Dimension.LOOP && game.isLoopOpen();
        loopPane.setVisible(loop);
        loopPane.setManaged(loop);
        view.setOnBeat(loop && loopSettings.metronome() ? loopSettings::beat : null);
        if (loop) refreshLoop();
        boolean duration = view.dimension() == Dimension.DURATION && game.isDurationOpen();
        durationPane.setVisible(duration);
        durationPane.setManaged(duration);
        if (duration) refreshDuration();
        boolean volume = view.dimension() == Dimension.VOLUME && game.isVolumeOpen();
        volumePane.setVisible(volume);
        volumePane.setManaged(volume);
        if (volume) refreshVolume();
        boolean plane = view.dimension() == Dimension.PLANE && game.isPlaneOpen();
        planePane.setVisible(plane);
        planePane.setManaged(plane);
        if (plane) refreshPlane();
        boolean line = view.dimension() == Dimension.LINE && game.isLineOpen();
        linePane.setVisible(line);
        linePane.setManaged(line);
        if (!line) return;
        shards.setText("Segments de la ligne : " + shardText(game.state().dimensionShards())
                + "   (+" + rate(game.lineShardsPerSecond()) + " par seconde)");
        threshold(threshold, game.isLineThresholdReached(), game.state().dimensionShardsEarned(), Game.LINE_THRESHOLD, "segments gagnés", 1);
        paintUpgrades(buttons, this::describe, game::lineLevel, game::lineMaxLevel, game::lineCost, game::canBuyLine,
                " segment", UniversePage.COLOR);
    }

    /** Vrai si {@code key} diffère de ce que {@code node} a montré en dernier ; la retient pour la prochaine image. */
    private boolean changed(Object node, String key) {
        return !key.equals(painted.put(node, key));
    }

    /** Le seuil d'une dimension : atteint, elle porte son rond vert ; sinon, ce qu'on a gagné sur ce qu'il faut. */
    private static void threshold(Label label, boolean reached, double earned, double limit, String gained, int number) {
        label.setText(reached
                ? "Seuil atteint : " + shardText(limit) + " " + gained + ", la dimension " + number + " porte son rond vert"
                : "Seuil : " + shardText(earned) + " / " + shardText(limit) + " " + gained);
    }

    /**
     * Les boutons d'une dimension : la description de chacun, son prix (au singulier sous 2) ou « Au maximum », et sa
     * couleur selon qu'il s'achète. {@code unit} est le singulier de l'éclat, précédé d'une espace ; le pluriel ajoute un s.
     * Tout ce qui s'affiche ne dépend que des niveaux et de ce qui est achetable : la rangée ne se refait que s'ils changent.
     */
    private <U extends Enum<U>> void paintUpgrades(java.util.Map<U, Button> buttons, java.util.function.Function<U, String> describe,
            java.util.function.ToIntFunction<U> level, java.util.function.ToIntFunction<U> max, java.util.function.ToDoubleFunction<U> cost,
            java.util.function.Predicate<U> canBuy, String unit, String accent) {
        StringBuilder key = new StringBuilder();
        for (U upgrade : buttons.keySet()) {
            key.append(level.applyAsInt(upgrade)).append(canBuy.test(upgrade) ? '+' : '-');
        }
        if (!changed(buttons, key.toString())) return;
        for (U upgrade : buttons.keySet()) {
            Button button = buttons.get(upgrade);
            boolean full = level.applyAsInt(upgrade) >= max.applyAsInt(upgrade);
            double price = cost.applyAsDouble(upgrade);
            button.setText(describe.apply(upgrade) + "\n" + (full ? "Au maximum" : "Prix : " + shardText(price) + unit + (price < 2 ? "" : "s")));
            button.setDisable(!canBuy.test(upgrade));
            paintUpgrade(button, canBuy.test(upgrade), full, accent);
        }
    }

    private void refreshPlane() {
        planeShards.setText("Facettes du plan : " + shardText(game.state().planeShards()));
        // Le seuil du plan (version 0.120), comme celui de la ligne : son rond vert (version 0.139 : il n'ouvre plus de palier de la graine).
        threshold(planeThreshold, game.isPlaneThresholdReached(), game.state().planeShardsEarned(), Game.PLANE_THRESHOLD, "facettes gagnées", 2);
        planeHint.setText("Z Q S D (ou les flèches) déplacent le point. Passez sur un éclat pour le ramasser."
                + (game.isDimensionAutomationRunning(DimensionAutomation.PLANE_AIM)
                        ? " Visée automatique : touches lâchées, le point file seul vers l'éclat le plus proche." : ""));
        paintUpgrades(planeButtons, this::describe, game::planeLevel, Game.PlaneUpgrade::max, game::planeCost, game::canBuyPlane, " facette", PLANE_COLOR);
    }

    /**
     * Le volume : ses éclats et son seuil, toujours ; ses améliorations seulement dehors, puisqu'elles ne
     * s'achètent pas pendant une plongée ; dedans, ce qu'on y fait et le temps qu'il reste.
     */
    private void refreshVolume() {
        volumeShards.setText("Sphères du volume : " + shardText(game.state().volumeShards()));
        threshold(volumeThreshold, game.isVolumeThresholdReached(), game.state().volumeShardsEarned(), Game.VOLUME_THRESHOLD, "sphères gagnées", 3);
        boolean outside = view.dive() == DimensionView.Dive.OUTSIDE;
        boolean diving = game.isDimensionAutomationRunning(DimensionAutomation.VOLUME_DIVE);
        volumeHint.setText((diving ? "Plongée automatique : elle replonge seule et cueille une boule toutes les "
                + seconds(Game.VOLUME_AUTO_SHOT_SECONDS) + " s ; vous pouvez cueillir avec elle. " : "") + switch (view.dive()) {
            case OUTSIDE -> diving ? "Les améliorations s'achètent ici, entre deux plongées."
                    : "Cliquez le cube pour y plonger, " + seconds(game.volumeDiveSeconds()) + " s par plongée. "
                    + "Les améliorations s'achètent ici, hors du cube.";
            case ENTERING -> "Vous plongez dans le cube…";
            case INSIDE -> (!view.freeCamera()
                    ? "Clic gauche tenu : regarder autour de soi. Clic droit : cueillir la boule visée. "
                    : view.mouseHeld()
                    ? "Caméra libre : bougez la souris pour regarder autour de vous. Un clic cueille la boule sous la croix. "
                            + "Échap rend la souris. "
                    : "Souris rendue : cliquez dans la vue pour reprendre la caméra libre. ")
                    + "Le cube vous rejette dans " + seconds(game.volumeTimeLeft()) + " s.";
            case LEAVING -> "Le cube vous rejette : les améliorations reviennent.";
        });
        if (changed(volumeDetail, idle.ui.common.Detail.shown() + "/" + game.volumeLevel(Game.VolumeUpgrade.SPAWN) + "/" + game.volumeLevel(Game.VolumeUpgrade.COUNT))) {
            volumeDetail.setText(idle.ui.common.Detail.only("Une plongée commence quand la vue arrive au centre du cube. Une "
                + "boule apparaît aussitôt, puis une toutes les " + seconds(game.volumeSpawnSeconds()) + " s, "
                + game.volumeMaxBalls() + " à la fois au plus, entre " + shardText(Game.VOLUME_SPAWN_NEAR) + " et "
                + shardText(Game.VOLUME_SPAWN_FAR) + " du centre. Le clic droit cueille la plus proche que traverse le "
                + "regard ; une boule plus grosse se vise mieux. À la fin du minuteur, ou si le jeu passe en absence, la "
                + "plongée s'arrête et les boules restantes s'en vont. Les sphères, le seuil et les améliorations du volume "
                + "traversent les univers ; le seuil marque la dimension d'un rond vert, et les sphères paient aussi des améliorations de la graine. En caméra libre, la souris disparaît "
                + "dans le cube et y reste retenue : chaque mouvement tourne le regard et elle revient seule au centre. "
                + "Échap la rend sans finir la plongée, un clic dans la vue la reprend ; quand le jeu n'a pas la main "
                + "(Alt+Tab), elle n'est jamais retenue. Si le système refuse de la déplacer, pousser un bord fait tourner "
                + "le regard sans fin."));
            volumeDetail.setVisible(!volumeDetail.getText().isEmpty());
            volumeDetail.setManaged(volumeDetail.isVisible());
        }
        freeCameraButton.setText(view.freeCamera() ? "Caméra libre : activée (le regard suit la souris)"
                : "Caméra libre : coupée (clic gauche tenu pour regarder)");
        // Dedans, la rangée se cache mais garde sa place : le cube ne se déplace pas pendant la plongée.
        volumeRow.setVisible(outside);
        paintUpgrades(volumeButtons, this::describe, game::volumeLevel, Game.VolumeUpgrade::max, game::volumeCost,
                u -> outside && game.canBuyVolume(u), " sphère", VOLUME_COLOR);
    }

    /** La durée : ses éclats, son seuil, ce qu'on y fait ; ses améliorations, bouton relâché. */
    private void refreshDuration() {
        durationShards.setText("Instants de la durée : " + shardText(game.state().durationShards()));
        threshold(durationThreshold, game.isDurationThresholdReached(), game.state().durationShardsEarned(), Game.DURATION_THRESHOLD, "instants gagnés", 4);
        boolean held = game.isDurationHeld();
        durationHint.setText(game.isDimensionAutomationRunning(DimensionAutomation.DURATION_HOLD)
                ? "Appui automatique : tenu " + seconds(game.durationHeldSeconds()) + " s sur " + seconds(game.durationMaxSeconds())
                        + " s, il relâche seul au centre (+" + shardText(game.durationRewardFor(game.durationMaxSeconds()))
                        + ") et recommence. Les améliorations s'achètent quand même, et valent dès le cycle en cours."
                : !held
                ? "Tenez le bouton du milieu (clic tenu, ou la barre d'espace) : les spirales avancent vers le centre, qu'elles "
                        + "atteignent en " + seconds(game.durationMaxSeconds()) + " s. Relâchez pour gagner leurs instants : plus on tient, plus chaque tour rapporte."
                        + (game.durationReleases() > 0 ? " Dernier relâchement : +" + shardText(game.durationLastReward()) + "." : "")
                : game.durationProgress() >= 1
                ? "Les spirales sont au centre : tenir plus ne rapporte plus rien. Relâchez pour gagner +" + shardText(game.durationPending()) + "."
                : "Tenu " + seconds(game.durationHeldSeconds()) + " s sur " + seconds(game.durationMaxSeconds())
                        + " : relâcher maintenant donnerait +" + shardText(game.durationPending()) + ".");
        StringBuilder levels = new StringBuilder().append(idle.ui.common.Detail.shown());
        for (Game.DurationUpgrade upgrade : Game.DurationUpgrade.values()) levels.append('/').append(game.durationLevel(upgrade));
        if (changed(durationDetail, levels.toString())) {
            durationDetail.setText(idle.ui.common.Detail.only("Chaque spirale fait " + shardText(game.durationTurnsPerSecond())
                + " tour par seconde tenue, jusqu'au centre, " + shardText(game.durationTurnsMax()) + " tours en "
                + seconds(game.durationMaxSeconds()) + " s. Au relâchement, chaque tour vaut un de plus que le précédent : n tours "
                + "donnent (n² + n) ÷ 2 fois la valeur (" + shardText(game.durationValue()) + "), pour chacune des "
                + game.durationSpirals() + " spirale" + (game.durationSpirals() > 1 ? "s" : "") + ". Tenir au-delà du centre ne "
                + "rapporte rien de plus et ne fait rien perdre. Les améliorations s'achètent bouton relâché. Une absence relâche "
                + "le bouton, qui donne ce qu'il avait. Les instants, le seuil et les améliorations de la durée traversent les "
                + "univers ; le seuil marque la dimension d'un rond vert, et les instants paient aussi des améliorations de la graine."));
            durationDetail.setVisible(!durationDetail.getText().isEmpty());
            durationDetail.setManaged(durationDetail.isVisible());
        }
        paintUpgrades(durationButtons, this::describe, game::durationLevel, Game.DurationUpgrade::max, game::durationCost,
                u -> !held && game.canBuyDuration(u), " instant", DURATION_COLOR);
    }

    /**
     * La boucle : ses nœuds, son seuil, comment on y joue (les touches des cercles en jeu) ou ce que fait le rythme
     * automatique, le métronome, le détail des parts d'une zone, et ses améliorations, qui s'achètent toujours.
     */
    private void refreshLoop() {
        loopShards.setText("Nœuds de la boucle : " + shardText(game.state().loopShards()));
        threshold(loopThreshold, game.isLoopThresholdReached(), game.state().loopShardsEarned(), Game.LOOP_THRESHOLD, "nœuds gagnés", 5);
        Game.LoopHit last = game.lastLoopHit();
        String lastText = game.loopHits() == 0 && last == Game.LoopHit.MISS ? "" : " Dernier clic : " + DimensionView.hitWord(last).toLowerCase(java.util.Locale.ROOT) + ".";
        loopHint.setText(game.isDimensionAutomationRunning(DimensionAutomation.LOOP_PLAY)
                ? "Rythme automatique : il clique « bien » à chaque passage d'un point dans une zone, sur chaque cercle. "
                        + "Vos clics comptent en plus ; les améliorations s'achètent quand même."
                : "Cliquez un cercle, ou sa touche (" + loopKeysText() + "), quand son point passe dans une zone : au centre "
                        + "« excellent », puis « bien », au bord « mauvais ». Après chaque clic, le cercle attend "
                        + seconds(Game.LOOP_COOLDOWN) + " s." + lastText);
        metronomeButton.setText(loopSettings.metronome() ? "Métronome : activé (un tic à chaque centre de zone du premier cercle)"
                : "Métronome : coupé");
        StringBuilder levels = new StringBuilder().append(idle.ui.common.Detail.shown());
        for (Game.LoopUpgrade upgrade : Game.LoopUpgrade.values()) levels.append('/').append(game.loopLevel(upgrade));
        if (changed(loopDetail, levels.toString())) {
            loopDetail.setText(idle.ui.common.Detail.only("Chaque point fait un tour en " + seconds(1 / game.loopTurnsPerSecond())
                + " s. Une zone couvre " + Math.round(game.loopZoneHalfWidth() * 200) + " % de son cercle : au centre, "
                + Math.round(Game.LOOP_EXCELLENT * 100) + " % de sa largeur, « excellent » donne "
                + shardText(game.loopReward(Game.LoopHit.EXCELLENT)) + " nœuds ; jusqu'à " + Math.round(Game.LOOP_GOOD * 100)
                + " %, « bien » en donne " + shardText(game.loopReward(Game.LoopHit.GOOD)) + " ; au bord, « mauvais », "
                + shardText(game.loopReward(Game.LoopHit.BAD)) + ". Un clic à côté ne donne rien. La zone touchée se pose "
                + "ailleurs sur son cercle. Après chaque clic, juste ou non, le cercle attend " + seconds(Game.LOOP_COOLDOWN)
                + " s : cliquer sans arrêt ne rapporte rien. Chaque cercle a sa touche, qui se change dans les réglages "
                + "(Clavier). Les nœuds, le seuil et les améliorations de la boucle traversent les univers ; le seuil marque "
                + "la dimension d'un rond vert, et les nœuds paient aussi le rond de croissance de la graine."));
            loopDetail.setVisible(!loopDetail.getText().isEmpty());
            loopDetail.setManaged(loopDetail.isVisible());
        }
        paintUpgrades(loopButtons, this::describe, game::loopLevel, Game.LoopUpgrade::max, game::loopCost, game::canBuyLoop,
                " nœud", LOOP_COLOR);
    }

    /**
     * La brane : ses ondes, son seuil, comment on la tire (la force et la portée pendant qu'on la tient) ou ce que fait la
     * tirée automatique, le gain du dernier passage, le détail des passages et des rebonds, et ses améliorations, qui
     * s'achètent toujours.
     */
    private void refreshBrane() {
        braneShards.setText("Ondes de la brane : " + shardText(game.state().braneShards()));
        threshold(braneThreshold, game.isDimensionThresholdReached(6), game.state().braneShardsEarned(), Game.BRANE_THRESHOLD, "ondes gagnées", 6);
        // Les rebonds du dernier passage : ceux de l'onde qui court, sinon on ne les sait plus.
        int bounces = game.braneWaves().isEmpty() ? 0 : game.braneWaves().get(0).lastBounces();
        String last = game.braneTouches() == 0 ? "" : " Dernier passage : " + DimensionView.passText(game.braneLastGain(), bounces) + ".";
        braneHint.setText(view.braneHeld()
                ? "Tirée à " + Math.round(view.branePull() * 100) + " % : l'onde portera à " + reach(game.braneReach(view.branePull()))
                        + " (" + reach(game.braneMaxReach()) + " à fond). Relâchez pour la lancer."
                : game.isDimensionAutomationRunning(DimensionAutomation.BRANE_PULL)
                ? "Tirée automatique : toutes les " + seconds(Game.BRANE_AUTO_SECONDS) + " s, elle tire la membrane à fond sur "
                        + "le point qui en touche le plus. Vos tirées comptent en plus ; les améliorations s'achètent quand même." + last
                : !game.canPullBrane()
                ? "Une onde court déjà : attendez qu'elle s'éteigne pour tirer de nouveau." + last
                : "Appuyez sur la membrane, glissez pour la tendre (plus loin, plus fort), relâchez : l'onde part du point "
                        + "appuyé et rebondit sur les bords. Chaque point qu'elle touche donne des ondes." + last);
        StringBuilder levels = new StringBuilder().append(idle.ui.common.Detail.shown());
        for (Game.BraneUpgrade upgrade : Game.BraneUpgrade.values()) levels.append('/').append(game.braneLevel(upgrade));
        if (changed(braneDetail, levels.toString())) {
            braneDetail.setText(idle.ui.common.Detail.only("La membrane fait 2 de côté. Une onde tirée à fond porte à "
                + reach(game.braneMaxReach()) + ", à peine tirée à " + Math.round(Game.BRANE_MIN_PULL * 100) + " % de cela ; un glissé de "
                + reach(DimensionView.BRANE_FULL_PULL) + " la tire à fond. Son front avance de " + reach(Game.BRANE_WAVE_SPEED)
                + " par seconde et rebondit sur les bords : chaque passage sur un point compte, en direct puis après chaque "
                + "rebond qui le retrouve, plusieurs fois si elle porte assez loin (le plus de rebonds en un passage depuis le "
                + "lancement : " + game.braneMostBounces() + "). Un passage donne " + shardText(game.braneValue()) + " onde"
                + (game.braneValue() >= 2 ? "s" : "") + ", " + Format.multiplier(game.braneBounceFactor())
                + " par rebond, et " + percent(game.braneComboStep()) + " de plus par passage de plus de la même onde. "
                + "Les points touchés restent tant que l'onde court, puis partent avec elle ; un point paraît toutes les "
                + seconds(Game.BRANE_SPAWN_SECONDS) + " s, " + Game.BRANE_MAX_POINTS + " au plus, et une seule onde court à "
                + "la fois. Les ondes, le seuil et les améliorations de la brane traversent les "
                + "univers ; le seuil marque la dimension d'un rond vert, et les ondes paient aussi la lumière astrale de la graine."));
            braneDetail.setVisible(!braneDetail.getText().isEmpty());
            braneDetail.setManaged(braneDetail.isVisible());
        }
        paintUpgrades(braneButtons, this::describe, game::braneLevel, Game.BraneUpgrade::max, game::braneCost, game::canBuyBrane,
                " onde", BRANE_COLOR);
    }

    /**
     * Le clicker : ses étincelles, son seuil, comment on y joue (la cadence, son multiplicateur, les zones) ou ce que font
     * les clics automatiques, le dernier gain, le détail, et ses améliorations, qui s'achètent toujours ; celles des
     * zones, une fois les zones débloquées.
     */
    private void refreshClicker() {
        clickerShards.setText("Étincelles du clicker : " + shardText(game.state().clickerShards()));
        threshold(clickerThreshold, game.isDimensionThresholdReached(7), game.state().clickerShardsEarned(), Game.CLICKER_THRESHOLD,
                "étincelles gagnées", 7);
        String last = game.clickerClicks() == 0 ? "" : " Dernier clic : +" + shardText(game.clickerLastGain()) + ".";
        String zones = game.areClickerZonesUnlocked()
                ? " Dans une zone, ×" + idle.ui.common.ElementText.number(game.clickerZoneFactor()) + ", et davantage là où elles se superposent."
                : "";
        clickerHint.setText(game.isDimensionAutomationRunning(DimensionAutomation.CLICKER_PLAY)
                ? "Clics automatiques : " + idle.ui.common.ElementText.number(Game.CLICKER_AUTO_RATE) + " clics par seconde au "
                        + "meilleur endroit (cadence " + view.cadenceText(game.clickerRate()) + "). Vos clics comptent en plus ; "
                        + "les améliorations s'achètent quand même." + last
                : "Cliquez la surface : chaque clic donne des étincelles, d'autant plus que vous cliquez vite (cadence "
                        + view.cadenceText(game.clickerRate()) + ")." + zones + last);
        StringBuilder levels = new StringBuilder().append(idle.ui.common.Detail.shown());
        for (Game.ClickerUpgrade upgrade : Game.ClickerUpgrade.values()) levels.append('/').append(game.clickerLevel(upgrade));
        if (changed(clickerDetail, levels.toString())) {
            clickerDetail.setText(idle.ui.common.Detail.only("Un clic donne " + shardText(game.clickerValue()) + " étincelle"
                + (game.clickerValue() >= 2 ? "s" : "") + ", multipliée par la cadence : +"
                + idle.ui.common.ElementText.number(game.clickerSpeedStep() * 100) + " % par clic par seconde, comptés sur les "
                + seconds(Game.CLICKER_WINDOW) + " dernières secondes, jusqu'à " + Math.round(Game.CLICKER_MAX_RATE)
                + " clics par seconde (" + Format.multiplier(game.clickerSpeedFactor(Game.CLICKER_MAX_RATE)) + ")."
                + (game.areClickerZonesUnlocked()
                        ? " Une zone apparaît toutes les " + seconds(Game.CLICKER_ZONE_EVERY) + " s, " + game.clickerMaxZones()
                                + " à la fois au plus, et dure " + seconds(game.clickerZoneSeconds()) + " s ; un clic dedans vaut "
                                + Format.multiplier(game.clickerZoneFactor()) + ", et chaque zone superposée de plus "
                                + Format.multiplier(game.clickerStackFactor()) + ". Le plus de zones sous un clic depuis le "
                                + "lancement : " + game.clickerBestStack() + "."
                        : " L'amélioration « Zones ×2 » fait apparaître des zones où un clic rapporte double.")
                + " Les étincelles, le seuil et les améliorations du clicker traversent les univers ; le seuil marque la "
                + "dimension d'un rond vert, et les étincelles paient aussi la météo de la graine."));
            clickerDetail.setVisible(!clickerDetail.getText().isEmpty());
            clickerDetail.setManaged(clickerDetail.isVisible());
        }
        paintUpgrades(clickerButtons, this::describe, game::clickerLevel, Game.ClickerUpgrade::max, game::clickerCost,
                game::canBuyClicker, " étincelle", CLICKER_COLOR);
    }

    /**
     * La grille : ses repères, son seuil, sa taille, comment on y joue ou ce que font les essais automatiques, le dernier
     * essai tel que l'affichage permet de le dire (le gain, puis la distance, la couche et la colonne du point visé) et
     * les essais qu'il reste sur ce point, la couche et la case visée, le zoom, le détail, et ses améliorations.
     */
    private void refreshGrid() {
        gridShards.setText("Repères de la grille : " + shardText(game.state().gridShards()));
        threshold(gridThreshold, game.isDimensionThresholdReached(8), game.state().gridShardsEarned(), Game.GRID_THRESHOLD, "repères gagnés", 8);
        int layer = view.gridLayer(), n = game.gridDivisions();
        gridLayerLabel.setText(DimensionView.layerText(layer, n));
        gridDown.setDisable(layer <= 0);
        gridUp.setDisable(layer >= n - 1);
        // La case visée : les champs suivent la vue (un clic sur la carte, une couche changée), sans écraser la saisie en cours.
        int[] at = view.gridSelected();
        TextField[] fields = {gridX, gridY, gridZ};
        for (int axis = 0; axis < 3; axis++) {
            if (!fields[axis].isFocused() && parsed(fields[axis]) != at[axis]) fields[axis].setText(String.valueOf(at[axis]));
        }
        gridTry.setDisable(!game.canProbeGrid());
        boolean big = !view.gridClickable();
        gridZoomIn.setDisable(!big || view.gridSpan() <= DimensionView.GRID_CLICK_CELLS);
        gridZoomOut.setDisable(!big || view.gridZoom() == 0);
        String size = Format.whole(n) + " × " + Format.whole(n) + " × " + Format.whole(n);
        gridSize.setText("Grille de " + size + " cases" + (big ? ", la carte en montre " + Format.whole(view.gridSpan()) + " × "
                + Format.whole(view.gridSpan()) : "") + " · " + game.gridAttempts() + (game.gridAttempts() > 1 ? " essais" : " essai")
                + " par point");
        String last = lastProbeText();
        String how = big ? "Visez une case (un clic sur la carte, ou ses coordonnées), puis « Essayer »"
                : "Cliquez une case pour l'essayer";
        gridHint.setText(game.isDimensionAutomationRunning(DimensionAutomation.GRID_PROBE)
                ? "Essais automatiques : toutes les " + seconds(Game.GRID_AUTO_SECONDS) + " s, une case près d'un point ; sur "
                        + "une grande grille ils ne trouvent presque jamais, réduite souvent. Vos essais comptent en plus." + last
                : how + " (la molette ou les flèches haut et bas changent de couche) : plus elle est près d'un point caché, "
                        + "plus elle donne de repères ; celle qui le contient le trouve, " + Format.multiplier(Game.GRID_FOUND) + "." + last);
        StringBuilder levels = new StringBuilder().append(idle.ui.common.Detail.shown());
        for (Game.GridUpgrade upgrade : Game.GridUpgrade.values()) levels.append('/').append(game.gridLevel(upgrade));
        if (changed(gridDetail, levels.toString())) {
            gridDetail.setText(idle.ui.common.Detail.only("La grille compte " + size + " cases ; " + game.gridPointCount() + " point"
                + (game.gridPointCount() > 1 ? "s s'y cachent" : " s'y cache") + ", et chacun n'a que " + game.gridAttempts()
                + (game.gridAttempts() > 1 ? " essais" : " essai") + " : un essai vise le point le plus proche, et une fois ses "
                + "essais épuisés, ou trouvé, le point se cache ailleurs. Un essai donne " + shardText(game.gridValue())
                + " repère" + (game.gridValue() >= 2 ? "s" : "") + " multiplié par la proximité, comptée en part de la grille : "
                + Format.multiplier(game.gridProximityFactor(n * Math.sqrt(3))) + " au plus loin, "
                + Format.multiplier(game.gridProximityFactor(0)) + " sur le point ; la case du point le trouve ("
                + Format.multiplier(Game.GRID_FOUND) + "). Après chaque essai, " + seconds(Game.GRID_COOLDOWN)
                + " s d'attente. La réduction divise la grille par " + idle.ui.common.ElementText.number(1 / Game.GRID_SHRINK)
                + " par niveau, jusqu'à " + Game.GRID_MIN_CELLS + " cases par côté : moins de cases, plus de chances. "
                + revealText(game.gridReveal())
                + " Les repères, le seuil et les améliorations de la grille traversent les univers ; le seuil marque la "
                + "dimension d'un rond vert, et les repères paient aussi la graine profonde."));
            gridDetail.setVisible(!gridDetail.getText().isEmpty());
            gridDetail.setManaged(gridDetail.isVisible());
        }
        paintUpgrades(gridButtons, this::describe, game::gridLevel, Game.GridUpgrade::max, game::gridCost, game::canBuyGrid,
                " repère", GRID_COLOR);
    }

    /** Le nombre d'un champ de coordonnée, ou −1 s'il n'en est pas un. */
    private static int parsed(TextField field) {
        try {
            return Integer.parseInt(field.getText().trim());
        } catch (NumberFormatException notANumber) {
            return -1;
        }
    }

    /** Vise la case des trois champs ; ce qui n'est pas un nombre garde la case d'avant sur son axe. */
    private void selectFromFields() {
        int[] at = view.gridSelected();
        int x = parsed(gridX), y = parsed(gridY), z = parsed(gridZ);
        view.selectGrid(x < 0 ? at[0] : x, y < 0 ? at[1] : y, z < 0 ? at[2] : z);
    }

    /**
     * Le dernier essai, autant que l'affichage le permet : son gain (au niveau 0, rien d'autre), puis la distance au
     * point visé, sa couche, sa colonne ; et les essais qu'il reste sur ce point. Rien sans essai.
     */
    private String lastProbeText() {
        Game.GridProbe probe = game.gridLastProbe();
        if (probe == null) return "";
        StringBuilder text = new StringBuilder(" Dernier essai : ").append(probe.found() ? "trouvé ! " : "")
                .append('+').append(shardText(probe.gain()));
        int reveal = game.gridReveal();
        if (reveal >= 1) text.append(", à ").append(idle.ui.common.ElementText.number(probe.distance())).append(" cases du point visé");
        int[] revealed = view.gridRevealed();
        if (reveal >= 2 && revealed[0] >= 0) text.append(", dans la couche z = ").append(revealed[0]);
        if (reveal >= 3 && revealed[1] >= 0) text.append(", la colonne x = ").append(revealed[1]);
        if (!probe.found()) text.append(probe.triesLeft() > 0 ? " ; encore " + probe.triesLeft() + (probe.triesLeft() > 1 ? " essais" : " essai")
                + " sur ce point" : " ; plus d'essai : le point s'est caché ailleurs");
        return text.append('.').toString();
    }

    /** Ce que montre l'affichage du point à ce niveau. */
    private static String revealText(int level) {
        return switch (level) {
            case 0 -> "La grille ne montre que le gain de chaque essai.";
            case 1 -> "La grille montre la distance de chaque essai au point visé, et colore les cases du froid au chaud.";
            case 2 -> "La grille montre la distance de chaque essai, et la couche du point visé par le dernier, tant qu'il lui reste un essai.";
            default -> "La grille montre la distance de chaque essai, et la couche et la colonne du point visé par le dernier, "
                    + "tant qu'il lui reste un essai.";
        };
    }

    /** Une amélioration de la grille : son nom, où elle en est, et ce que donne le niveau suivant. */
    private String describe(Game.GridUpgrade upgrade) {
        int level = game.gridLevel(upgrade);
        return switch (upgrade) {
            case DIVISION -> "Réduction de la grille : " + Format.whole(game.gridDivisions()) + " → "
                    + Format.whole(Game.cellsAt(level + 1)) + " cases par côté";
            case GAIN -> "Gain : chaque essai vaut " + shardText(game.gridValue()) + " → "
                    + shardText(game.gridValue() + game.hadronBoost(idle.core.collider.Hadron.OMEGA)) + " repères, avant la proximité";
            case REVEAL -> switch (level) {
                case 0 -> "Affichage du point : rien que le gain → la distance de chaque essai";
                case 1 -> "Affichage du point : la distance → aussi la couche du point visé";
                case 2 -> "Affichage du point : la couche → aussi la colonne du point visé";
                default -> "Affichage du point : distance, couche et colonne";
            };
            case POINTS -> "Nombre de points : " + game.gridPointCount() + " cachés → " + (game.gridPointCount() + 1);
            case PROXIMITY -> "Multiplicateur de proximité : sur le point " + Format.multiplier(game.gridProximityFactor(0)) + " → "
                    + Format.multiplier(game.gridProximityFactor(0) + Game.GRID_PROXIMITY_STEP);
            case ATTEMPTS -> "Essais : " + game.gridAttempts() + " par point → " + (game.gridAttempts() + 1);
        };
    }

    /**
     * Le miroir : ses reflets, son seuil, son plateau (sa taille, et les réussites qu'il manque pour l'agrandir), ses
     * compteurs (longueur, record, réussis, manqués, erreurs), ce qu'il faut faire
     * selon la phase ou ce que fait le miroir automatique, le dernier résultat, le détail, et ses améliorations.
     */
    private void refreshMirror() {
        mirrorShards.setText("Reflets du miroir : " + shardText(game.state().mirrorShards()));
        threshold(mirrorThreshold, game.isDimensionThresholdReached(9), game.state().mirrorShardsEarned(), Game.MIRROR_THRESHOLD,
                "reflets gagnés", 9);
        mirrorCounts.setText("Motif de " + game.mirrorLength() + " cases · record " + game.mirrorBest() + " · réussis "
                + Format.whole(game.mirrorSuccesses()) + " · manqués " + Format.whole(game.mirrorFails())
                + (game.mirrorAllowedMistakes() > 0 ? " · erreurs " + game.mirrorMistakes() + " / " + game.mirrorAllowedMistakes() : ""));
        int wins = game.mirrorWinsToGrow();
        mirrorBoard.setText("Plateau " + game.mirrorColumns() + " × " + game.mirrorRows() + " — " + (wins <= 0 ? "au plus grand"
                : "encore " + wins + (wins > 1 ? " réussites" : " réussite") + " avant de l'agrandir"));
        String last = switch (game.mirrorLastResult()) {
            case SUCCESS -> " Dernier motif réussi : +" + shardText(game.mirrorLastGain()) + ".";
            case FAIL -> " Dernier motif manqué : +" + shardText(game.mirrorLastGain()) + ".";
            default -> "";
        };
        mirrorHint.setText(game.isDimensionAutomationRunning(DimensionAutomation.MIRROR_PLAY)
                ? "Miroir automatique : il reproduit une case toutes les " + seconds(Game.MIRROR_AUTO_STEP) + " s, sans faute "
                        + "jusqu'à " + Game.MIRROR_AUTO_MAX + " cases, puis se trompe. Vos clics comptent en plus." + last
                : switch (game.mirrorPhase()) {
                    case SHOW -> "Regardez le motif s'allumer à gauche, case après case : vous le referez de mémoire, en miroir, "
                            + "à droite, dans le même ordre." + last;
                    case INPUT -> "De mémoire, cliquez à droite le reflet de chaque case, dans l'ordre : "
                            + game.mirrorPosition() + " / " + game.mirrorLength() + "." + last;
                    case PAUSE -> "Le motif suivant arrive." + last;
                });
        StringBuilder levels = new StringBuilder().append(idle.ui.common.Detail.shown());
        for (Game.MirrorUpgrade upgrade : Game.MirrorUpgrade.values()) levels.append('/').append(game.mirrorLevel(upgrade));
        levels.append('/').append(game.mirrorGrowth());
        if (changed(mirrorDetail, levels.toString())) {
            mirrorDetail.setText(idle.ui.common.Detail.only("Le plateau fait " + game.mirrorColumns() + " × " + game.mirrorRows()
                + " cases, coupé au milieu par le miroir. Chaque case du motif reste allumée " + seconds(game.mirrorShowSeconds())
                + " s ; ensuite, le motif s'éteint et attend. Réussi, un motif de L cases donne " + shardText(game.mirrorValue())
                + " × L × " + idle.ui.common.ElementText.number(game.mirrorLengthFactor()) + " puissance (L − " + Game.MIRROR_START
                + ") reflets (" + shardText(game.mirrorReward(game.mirrorLength())) + " pour le motif en cours), et le suivant a une "
                + "case de plus, jusqu'à " + Game.MIRROR_MAX + " ; manqué, il donne un quart de reflet par case juste, et le suivant "
                + "a une case de moins, jamais moins de " + Game.MIRROR_START + ". "
                + (game.mirrorAllowedMistakes() > 0 ? game.mirrorAllowedMistakes() + (game.mirrorAllowedMistakes() > 1
                        ? " erreurs sont permises" : " erreur est permise") + " par motif. " : "")
                + "Les reflets, le seuil et les améliorations du miroir traversent les univers ; le seuil marque la dimension "
                + "d'un rond vert, et les reflets paient aussi les saisons de la graine. Toutes les " + Game.MIRROR_GROW_EVERY
                + " réussites, le plateau s'agrandit d'une colonne de chaque côté et d'une ligne, et le gain de "
                + Format.multiplier(1 + Game.MIRROR_BOARD) + " de plus, " + game.mirrorMaxGrowth() + " fois au plus (gain "
                + Format.multiplier(1 + Game.MIRROR_BOARD * game.mirrorGrowth()) + " maintenant)."));
            mirrorDetail.setVisible(!mirrorDetail.getText().isEmpty());
            mirrorDetail.setManaged(mirrorDetail.isVisible());
        }
        paintUpgrades(mirrorButtons, this::describe, game::mirrorLevel, Game.MirrorUpgrade::max, game::mirrorCost, game::canBuyMirror,
                " reflet", MIRROR_COLOR);
    }

    /** Les dimensions mêlées, de la ligne à la dernière : « ligne + plan + volume ». */
    private static final String[] MIX_NAMES = {"ligne", "plan", "volume", "durée", "boucle", "brane", "clicker", "grille", "miroir"};

    /** « Étape 4 sur 9 : ligne + plan + volume + durée ». */
    static String mixStageText(int stage) {
        return "Étape " + stage + " sur " + Game.MIX_STAGES + " : " + String.join(" + ", java.util.Arrays.asList(MIX_NAMES).subList(0, stage));
    }

    /**
     * Le mélange : l'étape, sa barre vers l'étape suivante et son bouton ; les fragments, le seuil, les compteurs ; ce
     * qu'on fait à l'étape en cours, ou ce que fait le mélange automatique ; le détail, et les améliorations : celles des
     * étapes pas encore atteintes restent grises, avec l'étape qui les ouvre.
     */
    private void refreshMix() {
        int stage = game.mixStage();
        mixStage.setText(mixStageText(stage));
        double goal = game.mixStageGoal(), earned = game.state().mixStageEarned();
        boolean last = stage >= Game.MIX_STAGES;
        double share = last ? 1 : Math.max(0, Math.min(1, earned / goal));
        mixBarFill.setMinWidth(MIX_BAR_WIDTH * share);
        mixBarFill.setPrefWidth(MIX_BAR_WIDTH * share);
        mixBarFill.setMaxWidth(MIX_BAR_WIDTH * share);
        mixBarRest.setMinWidth(MIX_BAR_WIDTH * (1 - share));
        mixBarRest.setPrefWidth(MIX_BAR_WIDTH * (1 - share));
        mixBarRest.setMaxWidth(MIX_BAR_WIDTH * (1 - share));
        mixProgress.setText(last ? "Tout est mêlé" : shardText(Math.min(earned, goal)) + " / " + shardText(goal) + " fragments gagnés à cette étape");
        mixAdvance.setVisible(!last);
        mixAdvance.setManaged(!last);
        mixAdvance.setDisable(!game.canAdvanceMix());
        mixShards.setText("Fragments du mélange : " + shardText(game.state().mixShards()));
        threshold(mixThreshold, game.isDimensionThresholdReached(10), game.state().mixShardsEarned(), Game.MIX_THRESHOLD,
                "fragments gagnés", 10);
        StringBuilder info = new StringBuilder("Malus " + percentOf(game.mixMalus()) + " · étape "
                + Format.multiplier(game.mixStageMultiplier()) + " · une graduation vaut " + idle.ui.common.ElementText.number(game.mixValue()));
        if (game.isMixing(4)) {
            info.append(" · charge ").append(shardText(game.mixPot())).append(' ').append(Format.multiplier(game.mixChargeMultiplier()));
        }
        if (game.isMixing(7)) {
            info.append(" · cadence ").append(idle.ui.common.ElementText.number(game.mixClickRate())).append(" clics/s ")
                    .append(Format.multiplier(game.mixClickMultiplier()));
        }
        if (game.isMixing(8)) info.append(" · trésors ").append(game.mixTreasures());
        if (game.isMixing(9)) info.append(" · paires de suite ").append(game.mixPairStreak());
        if (game.mixLastGain() > 0) info.append(" · dernier gain +").append(idle.ui.common.ElementText.number(game.mixLastGain()));
        mixInfo.setText(info.toString());
        mixHint.setText((game.isDimensionAutomationRunning(DimensionAutomation.MIX_AUTO)
                ? "Mélange automatique : il mène le point vers l'éclat le plus proche, plonge à sa profondeur, tient et relâche "
                        + "la charge en rythme, clique et passe seul à l'étape suivante. Vous pouvez jouer avec lui. "
                : "") + mixHintFor(stage));
        StringBuilder levels = new StringBuilder().append(idle.ui.common.Detail.shown()).append('/').append(stage);
        for (Game.MixUpgrade upgrade : Game.MixUpgrade.values()) levels.append('/').append(game.mixLevel(upgrade));
        if (changed(mixDetail, levels.toString())) {
            mixDetail.setText(idle.ui.common.Detail.only("Chaque graduation que passe la boule vaut le gain (" + (1 + game.mixLevel(Game.MixUpgrade.GAIN))
                    + ", fois les omégas), multiplié par le malus (" + percentOf(game.mixMalus()) + ", au départ de chaque étape "
                    + percentOf(Game.MIX_MALUS) + ") et par les dimensions mêlées (+" + percent(Game.MIX_STAGE_BONUS) + " chacune après la "
                    + "ligne, ici " + Format.multiplier(game.mixStageMultiplier()) + "). "
                    + (stage >= 2 ? "Un éclat vaut " + Math.round(Game.MIX_SHARD_VALUE) + " graduations ; " + Game.MIX_MAX_SHARDS
                            + " au plus sur l'arène. " : "")
                    + (stage >= 3 ? "Un éclat profond vaut jusqu'au double ; le point le ramasse à " + idle.ui.common.ElementText.number(game.mixDepthTolerance())
                            + " de profondeur près. " : "")
                    + (stage >= 4 ? "La charge monte jusqu'à " + Format.multiplier(1 + 1 + Game.MIX_CHARGE_STEP * game.mixLevel(Game.MixUpgrade.CHARGE))
                            + " en " + seconds(Game.MIX_CHARGE_SECONDS) + " s tenues. " : "")
                    + (stage >= 5 ? "Relâcher dans la zone du cercle : excellent ×3, bien ×1,5, mauvais ×1, hors de la zone ×0,5. " : "")
                    + (stage >= 6 ? "L'onde porte à " + idle.ui.common.ElementText.number(game.mixWaveReach()) + " et donne ×"
                            + idle.ui.common.ElementText.number(Game.MIX_WAVE_BOUNCE).replace('.', ',') + " par rebond, tout de suite. " : "")
                    + (stage >= 7 ? "Chaque clic par seconde ajoute " + percent(Game.MIX_CLICK) + " (" + Math.round(Game.MIX_CLICK_MAX)
                            + " au plus) ; " + game.mixMaxZones() + (game.mixMaxZones() > 1 ? " zones ×2" : " zone ×2") + " à la fois au plus. " : "")
                    + (stage >= 8 ? "Le trésor vaut " + idle.ui.common.ElementText.number(game.mixTreasureValue()) + " graduations. " : "")
                    + (stage >= 9 ? "Un reflet ramassé juste après son éclat vaut " + Format.multiplier(game.mixPairFactor())
                            + ", +" + percent(Game.MIX_PAIR_STREAK) + " par paire de suite. " : "")
                    + "Passer à l'étape suivante remet à zéro les améliorations du mélange ; les fragments, eux, restent, et paient "
                    + "aussi la bulle des racines de la graine."));
            mixDetail.setVisible(!mixDetail.getText().isEmpty());
            mixDetail.setManaged(mixDetail.isVisible());
        }
        // Les améliorations : la rangée ne se refait que si l'étape, un niveau ou ce qui s'achète change.
        StringBuilder key = new StringBuilder().append(stage);
        for (Game.MixUpgrade upgrade : Game.MixUpgrade.values()) {
            key.append('/').append(game.mixLevel(upgrade)).append(game.canBuyMix(upgrade) ? '+' : '-');
        }
        if (!changed(mixRowKey, key.toString())) return;
        painted.remove(mixButtons);
        paintUpgrades(mixButtons, this::describe, game::mixLevel, Game.MixUpgrade::max, game::mixCost, game::canBuyMix,
                " fragment", MIX_COLOR);
        for (Game.MixUpgrade upgrade : Game.MixUpgrade.values()) {
            if (stage >= upgrade.stage()) continue;
            Button button = mixButtons.get(upgrade);
            button.setText(mixName(upgrade) + "\nÀ l'étape " + upgrade.stage());
            button.setDisable(true);
            button.setStyle(UPGRADE_STYLE + " -fx-padding: 8 16; -fx-border-width: 1; -fx-text-fill: #5c6580; -fx-background-color: #0b0e17;"
                    + " -fx-border-color: #1f2638; -fx-border-style: dashed;");
        }
    }

    /** Ce qu'on fait à cette étape du mélange : ce qui vient d'y être mêlé d'abord. */
    private static String mixHintFor(int stage) {
        return switch (stage) {
            case 1 -> "La boule va et vient sur la ligne : chaque graduation qu'elle passe donne des fragments. Achetez des "
                    + "graduations et réduisez le malus.";
            case 2 -> "Chaque graduation pose un éclat : menez le point dessus pour le ramasser (clic ou souris tenue sur "
                    + "l'arène, ou Z Q S D et les flèches).";
            case 3 -> "Les éclats sont à des profondeurs (les violets au fond) : la molette, ou A et E, font plonger le point "
                    + "ou le remontent ; il ramasse ceux qu'entoure un anneau.";
            case 4 -> "Tenez le bouton droit (ou la barre d'espace) : ce que vous ramassez va dans la charge, qui grandit "
                    + "jusqu'à ×2 en 8 s ; relâchez pour la verser.";
            case 5 -> "Relâchez la charge quand le point du cercle, à gauche, est dans sa zone : au centre, ×3.";
            case 6 -> "Chaque relâchement lance une onde depuis le point : elle ramasse les éclats qu'elle touche, davantage "
                    + "après un rebond sur les bords.";
            case 7 -> "Cliquez l'arène, et vite : la cadence multiplie tout. Les éclats ramassés dans une zone ×2 valent le "
                    + "double, par zone qui les couvre.";
            case 8 -> "Un trésor est caché dans une case de la grille : le halo du point chauffe quand il s'en approche ; "
                    + "entrez dans sa case pour le trouver.";
            default -> "Les éclats viennent par paires, de part et d'autre du miroir : ramassez un éclat puis son reflet, "
                    + "juste après, pour le multiplier.";
        };
    }

    /** Le nom d'une amélioration du mélange, sans ses chiffres. */
    private static String mixName(Game.MixUpgrade upgrade) {
        return switch (upgrade) {
            case GAIN -> "Gain";
            case MALUS -> "Réduction du malus";
            case TICKS -> "Graduations";
            case SPEED -> "Vitesse du point";
            case DEPTH -> "Profondeur";
            case CHARGE -> "Charge";
            case RHYTHM -> "Zone du rythme";
            case REACH -> "Portée de l'onde";
            case ZONES -> "Zones ×2";
            case TREASURE -> "Trésor";
            case PAIRS -> "Paires";
        };
    }

    /** Une part en pour cent : « 1 % », « 2,56 % » (deux décimales au plus). */
    private static String percentOf(double share) {
        return idle.ui.common.ElementText.number(share * 100).replace('.', ',') + " %";
    }

    /** Une amélioration du mélange : son nom, où elle en est, et ce que donne le niveau suivant. */
    private String describe(Game.MixUpgrade upgrade) {
        int level = game.mixLevel(upgrade);
        return mixName(upgrade) + " : " + switch (upgrade) {
            case GAIN -> (1 + level) + " → " + (2 + level) + " par graduation";
            case MALUS -> "il garde " + percentOf(game.mixMalus()) + " → " + percentOf(Math.min(1, game.mixMalus() * Game.MIX_MALUS_STEP));
            case TICKS -> game.mixTicks() + " → " + (game.mixTicks() + 1) + " sur la ligne";
            case SPEED -> "+" + percent(Game.MIX_CURSOR_STEP * level) + " → +" + percent(Game.MIX_CURSOR_STEP * (level + 1));
            case DEPTH -> "à " + idle.ui.common.ElementText.number(game.mixDepthTolerance()) + " près → "
                    + idle.ui.common.ElementText.number(game.mixDepthTolerance() + Game.MIX_DEPTH_STEP);
            case CHARGE -> "jusqu'à " + Format.multiplier(2 + Game.MIX_CHARGE_STEP * level) + " → " + Format.multiplier(2 + Game.MIX_CHARGE_STEP * (level + 1));
            case RHYTHM -> "zone +" + percent(Game.MIX_RING_STEP * level) + " → +" + percent(Game.MIX_RING_STEP * (level + 1));
            case REACH -> "portée " + idle.ui.common.ElementText.number(game.mixWaveReach()) + " → "
                    + idle.ui.common.ElementText.number(Game.MIX_WAVE_REACH * (1 + Game.MIX_WAVE_STEP * (level + 1)));
            case ZONES -> (1 + level) + " → " + (2 + level) + " à la fois";
            case TREASURE -> idle.ui.common.ElementText.number(game.mixTreasureValue()) + " → "
                    + idle.ui.common.ElementText.number(Game.MIX_TREASURE * (1 + Game.MIX_TREASURE_STEP * (level + 1))) + " graduations";
            case PAIRS -> Format.multiplier(game.mixPairFactor()) + " → " + Format.multiplier(game.mixPairFactor() + Game.MIX_PAIR_STEP);
        };
    }

    /** Une amélioration du miroir : son nom, où elle en est, et ce que donne le niveau suivant. */
    private String describe(Game.MirrorUpgrade upgrade) {
        int level = game.mirrorLevel(upgrade);
        return switch (upgrade) {
            case GAIN -> {
                double omega = game.hadronBoost(idle.core.collider.Hadron.OMEGA);
                yield "Gain : chaque case d'un motif réussi vaut " + shardText((1 + level) * omega) + " → "
                        + shardText((2 + level) * omega) + " reflets, avant le plateau";
            }
            case LENGTH -> "Multiplicateur de longueur : " + Format.multiplier(game.mirrorLengthFactor()) + " → "
                    + Format.multiplier(game.mirrorLengthFactor() + Game.MIRROR_LENGTH_STEP) + " par case au-delà de " + Game.MIRROR_START;
            case MEMORY -> "Temps de mémorisation : " + idle.ui.common.ElementText.number(game.mirrorShowSeconds()) + " s → "
                    + idle.ui.common.ElementText.number(game.mirrorShowSeconds() + Game.MIRROR_SHOW_STEP) + " s par case";
            case MISTAKES -> "Seconde chance : " + level + (level > 1 ? " erreurs permises" : " erreur permise") + " → " + (level + 1);
            case BOARD -> "Plateau plus vaste : " + game.mirrorMaxGrowth() + " agrandissements permis → " + (game.mirrorMaxGrowth() + 1)
                    + ", jusqu'à " + (2 * (Game.MIRROR_HALF + game.mirrorMaxGrowth() + 1)) + " × "
                    + (Game.MIRROR_ROWS + game.mirrorMaxGrowth() + 1) + " cases";
        };
    }

    /** Une amélioration du clicker : son nom, où elle en est, et ce que donne le niveau suivant ; celles des zones les attendent. */
    private String describe(Game.ClickerUpgrade upgrade) {
        int level = game.clickerLevel(upgrade);
        String text = switch (upgrade) {
            case GAIN -> "Gain : chaque clic vaut " + shardText(game.clickerValue()) + " → "
                    + shardText(game.clickerValue() + game.hadronBoost(idle.core.collider.Hadron.OMEGA)) + " étincelles";
            case SPEED -> "Multiplicateur de cadence : +" + idle.ui.common.ElementText.number(game.clickerSpeedStep() * 100) + " % → +"
                    + idle.ui.common.ElementText.number((game.clickerSpeedStep() + Game.CLICKER_SPEED_STEP) * 100) + " % par clic par seconde";
            case ZONES -> level > 0 ? "Zones ×2 : débloquées" : "Zones ×2 : des zones apparaissent, un clic dedans rapporte double";
            case ZONE_MULT -> "Multiplicateur des zones : " + Format.multiplier(game.clickerZoneFactor()) + " → "
                    + Format.multiplier(game.clickerZoneFactor() + Game.CLICKER_ZONE_STEP);
            case ZONE_TIME -> "Durée des zones : " + seconds(game.clickerZoneSeconds()) + " s → "
                    + seconds(game.clickerZoneSeconds() + Game.CLICKER_ZONE_SECONDS_STEP) + " s";
            case ZONE_COUNT -> "Nombre de zones : " + (1 + level) + " à la fois → " + (2 + level);
            case ZONE_SIZE -> "Taille des zones (×" + idle.ui.common.ElementText.number(1 + Game.CLICKER_ZONE_SIZE_STEP * level) + ") : "
                    + percent(Game.CLICKER_ZONE_SIZE_STEP) + " plus grandes";
            case STACK -> "Zones superposées : chaque zone de plus " + Format.multiplier(game.clickerStackFactor()) + " → "
                    + Format.multiplier(game.clickerStackFactor() + Game.CLICKER_STACK_STEP);
        };
        return upgrade.needsZones() && !game.areClickerZonesUnlocked() ? text + " (après « Zones ×2 »)" : text;
    }

    /** Une longueur sur la membrane (de côté 2) : deux décimales. */
    private static String reach(double value) {
        return String.format(java.util.Locale.ROOT, "%.2f", value);
    }

    /** Une amélioration de la brane : son nom, où elle en est, et ce que donne le niveau suivant. */
    private String describe(Game.BraneUpgrade upgrade) {
        int level = game.braneLevel(upgrade);
        return switch (upgrade) {
            case GAIN -> "Gain : chaque passage vaut " + shardText(game.braneValue()) + " → "
                    + shardText(game.braneValue() + game.hadronBoost(idle.core.collider.Hadron.OMEGA)) + " ondes";
            case ELASTICITY -> "Élasticité : l'onde porte à fond dès " + Math.round(100 / (1 + Game.BRANE_ELASTIC_STEP * level))
                    + " % de tirée → " + Math.round(100 / (1 + Game.BRANE_ELASTIC_STEP * (level + 1))) + " %";
            case SIZE -> "Grandeur des ondes : portée à fond " + reach(game.braneMaxReach()) + " → "
                    + reach(Game.BRANE_REACH * (1 + Game.BRANE_SIZE_STEP * (level + 1))) + " (côté 2)";
            case BOUNCE -> "Rebond : un passage après un bord vaut " + Format.multiplier(game.braneBounceFactor()) + " → "
                    + Format.multiplier(game.braneBounceFactor() + Game.BRANE_BOUNCE_STEP);
            case COMBO -> "Points en une onde : chaque passage de plus de la même onde +" + percent(game.braneComboStep())
                    + " → +" + percent(game.braneComboStep() + Game.BRANE_COMBO_STEP);
        };
    }

    /** Les touches des cercles en jeu, dans l'ordre : « S, D, F ». */
    private String loopKeysText() {
        StringBuilder keys = new StringBuilder();
        for (int ring = 0; ring < game.loopRings(); ring++) {
            javafx.scene.input.KeyCode key = loopSettings.loopKey(ring);
            keys.append(ring == 0 ? "" : ", ").append(key == null ? "aucune" : idle.ui.common.Detail.keyName(key));
        }
        return keys.toString();
    }

    /** Une amélioration de la boucle : son nom, où elle en est, et ce que donne le niveau suivant. */
    private String describe(Game.LoopUpgrade upgrade) {
        double value = game.loopValue(), next = value + game.hadronBoost(idle.core.collider.Hadron.OMEGA);
        int precision = game.loopLevel(Game.LoopUpgrade.PRECISION);
        return switch (upgrade) {
            case SPEED -> "Rapidité : un tour en " + seconds(1 / game.loopTurnsPerSecond()) + " s → "
                    + seconds(1 / (game.loopTurnsPerSecond() * Game.LOOP_SPEED_STEP)) + " s";
            case ZONES -> "Zones : " + game.loopZoneCount() + " par cercle, une de plus";
            case GAIN -> "Gain par zone : chaque zone vaut " + shardText(value) + " → " + shardText(next) + " nœuds";
            case PRECISION -> "Précision : le centre donne " + shardText(game.loopReward(Game.LoopHit.EXCELLENT)) + " → "
                    + shardText(value * Game.LOOP_EXCELLENT_SHARE * (1 + Game.LOOP_PRECISION_EXCELLENT * (precision + 1)))
                    + ", « bien » " + shardText(game.loopReward(Game.LoopHit.GOOD)) + " → "
                    + shardText(value * (1 + Game.LOOP_PRECISION_GOOD * (precision + 1)));
            case SIZE -> "Taille des zones (×" + shardText(game.loopZoneHalfWidth() / Game.LOOP_ZONE_HALF) + ") : "
                    + percent(Game.LOOP_SIZE_STEP) + " plus larges";
            case RINGS -> {
                javafx.scene.input.KeyCode key = loopSettings.loopKey(Math.min(Game.MAX_RINGS - 1, game.loopRings()));
                yield "Cercles : " + game.loopRings() + ", un de plus"
                        + (game.loopRings() < Game.MAX_RINGS && key != null ? ", sur la touche " + idle.ui.common.Detail.keyName(key) : "");
            }
        };
    }

    /** Une amélioration de la durée : son nom, où elle en est, et ce que donne le niveau suivant. */
    private String describe(Game.DurationUpgrade upgrade) {
        return switch (upgrade) {
            case SPEED -> "Vitesse des spirales : " + shardText(game.durationTurnsPerSecond()) + " tour par seconde, " + percent(Game.DURATION_SPEED_STEP) + " plus vite";
            case COUNT -> "Spirales : " + game.durationSpirals() + ", une de plus qui avance en même temps";
            case VALUE -> "Valeur : le premier tour donne " + shardText(game.durationValue()) + " → " + shardText(game.durationValue() + game.hadronBoost(idle.core.collider.Hadron.OMEGA));
            case TIME -> "Temps au plus : " + seconds(game.durationMaxSeconds()) + " s → "
                    + seconds(game.durationMaxSeconds() + Game.DURATION_TIME_STEP) + " s, des tours de plus";
        };
    }

    /** Une amélioration du volume : son nom, où elle en est, et ce que donne le niveau suivant. */
    private String describe(Game.VolumeUpgrade upgrade) {
        return switch (upgrade) {
            case TIME -> "Durée : " + seconds(game.volumeDiveSeconds()) + " s par plongée → "
                    + seconds(game.volumeDiveSeconds() + Game.VOLUME_DIVE_STEP) + " s";
            case VALUE -> "Valeur : chaque boule cueillie donne " + shardText(game.volumeValue()) + " → " + shardText(game.volumeValue() + game.hadronBoost(idle.core.collider.Hadron.OMEGA));
            case SPAWN -> "Réapparition : une boule toutes les " + seconds(game.volumeSpawnSeconds()) + " s, 15 % plus vite";
            case COUNT -> "Nombre : " + game.volumeMaxBalls() + " boules à la fois au plus, une de plus";
            case SIZE -> "Taille des boules (×" + shardText(game.volumeBallRadius() / Game.VOLUME_BALL_RADIUS)
                    + ") : " + percent(Game.VOLUME_SIZE_STEP) + " plus grosses, elles se visent mieux";
        };
    }

    /** Une amélioration du plan : son nom, où elle en est, et ce que donne le niveau suivant. */
    private String describe(Game.PlaneUpgrade upgrade) {
        return switch (upgrade) {
            case VALUE -> "Valeur : chaque éclat ramassé donne " + shardText(game.planeValue()) + " → " + shardText(game.planeValue() + game.hadronBoost(idle.core.collider.Hadron.OMEGA)) + " facettes";
            case SPAWN -> "Réapparition : un éclat toutes les " + seconds(game.planeSpawnSeconds()) + " s, 15 % plus vite";
            case COUNT -> "Nombre : " + game.planeMaxShards() + " éclats à la fois au plus, un de plus";
            case SPEED -> "Vitesse du point : 20 % plus vite (×" + shardText(game.planeSpeed() / Game.PLANE_SPEED) + ")";
            case SIZE -> "Taille du point (×" + shardText(game.planePlayerRadius() / Game.PLANE_PLAYER_RADIUS) + ") : " + percent(Game.PLANE_SIZE_STEP) + " plus gros, il ramasse de plus loin";
        };
    }

    private static String seconds(double value) {
        return String.format(java.util.Locale.ROOT, "%.1f", value);
    }

    /** Un pas d'amélioration en pourcentage : 0,25 donne « 25 % ». */
    private static String percent(double step) {
        return Math.round(step * 100) + " %";
    }

    /**
     * Une touche, quand la fenêtre d'une dimension est ouverte : dans le plan, Z Q S D et les flèches déplacent le point ;
     * dans la durée, la barre d'espace tient le bouton ; dans la boucle, la touche de chaque cercle le joue ; dans la
     * grille, les flèches haut et bas changent de couche ; dans le mélange, Z Q S D et les flèches mènent le point, A et E
     * le font remonter ou plonger, la barre d'espace tient la charge. Vrai si la touche a servi (le reste du jeu ne la
     * voit pas).
     */
    public boolean key(javafx.scene.input.KeyCode code, boolean down) {
        if (!isVisible()) return false;
        // La boucle (version 0.153) : la touche d'un cercle le joue à l'appui ; tenue, elle ne le rejoue pas. Les touches
        // des cercles pas encore achetés ne servent à rien, mais ne vont pas aux raccourcis : la fenêtre les garde.
        DimensionView loop = shown(Dimension.LOOP);
        if (loop != null && game.isLoopOpen()) {
            int ring = loopRingOf(code);
            if (ring >= 0) {
                if (!down) loopKeysHeld.remove(code);
                else if (loopKeysHeld.add(code) && ring < game.loopRings()) loop.clickRing(ring);
                return true;
            }
        }
        // La grille (version 0.156) : les flèches haut et bas changent de couche.
        DimensionView grid = shown(Dimension.GRID);
        if (grid != null && game.isGridOpen() && (code == javafx.scene.input.KeyCode.UP || code == javafx.scene.input.KeyCode.DOWN)) {
            if (down) {
                grid.shiftGridLayer(code == javafx.scene.input.KeyCode.UP ? 1 : -1);
                refresh();
            }
            return true;
        }
        // Le volume (version 0.128) : en caméra libre, Échap rend la souris retenue ; la plongée continue.
        DimensionView volume = shown(Dimension.VOLUME);
        if (volume != null && code == javafx.scene.input.KeyCode.ESCAPE && volume.mouseHeld()) {
            if (down) volume.releaseMouse();
            return true;
        }
        // La durée (version 0.134) : la barre d'espace tient le bouton du milieu, comme la souris.
        DimensionView duration = shown(Dimension.DURATION);
        if (duration != null && code == javafx.scene.input.KeyCode.SPACE && game.isDurationOpen()) {
            if (down && !spaceHeld) {
                spaceHeld = true;
                game.holdDuration();
            } else if (!down) {
                spaceHeld = false;
                duration.releaseHold();
            }
            return true;
        }
        if (view.dimension() == Dimension.MIX) return mixKey(code, down);
        if (view.dimension() != Dimension.PLANE || !game.isPlaneOpen()) return false;
        switch (code) {
            case Z, Q, S, D, UP, DOWN, LEFT, RIGHT -> { }
            default -> {
                return false;
            }
        }
        if (down) held.add(code);
        else held.remove(code);
        steer();
        return true;
    }

    /** La vue de la fenêtre si elle montre la dimension {@code dimension}, {@code null} sinon. */
    private DimensionView shown(Dimension dimension) {
        return view.dimension() == dimension ? view : null;
    }

    /**
     * Une touche dans le mélange (version 0.159) : Z Q S D et les flèches mènent le point (dès le plan), A le fait
     * remonter et E plonger (dès le volume), la barre d'espace tient la charge (dès la durée). Vrai si elle a servi.
     */
    private boolean mixKey(javafx.scene.input.KeyCode code, boolean down) {
        if (!game.isMixOpen()) return false;
        switch (code) {
            case Z, Q, S, D, UP, DOWN, LEFT, RIGHT -> {
                if (!game.isMixing(2)) return false;
                if (down) held.add(code);
                else held.remove(code);
                double[] direction = direction();
                game.setMixDirection(direction[0], direction[1]);
                return true;
            }
            case A, E -> {
                if (!game.isMixing(3)) return false;
                if (down) view.shiftMixDepth(code == javafx.scene.input.KeyCode.E ? 1 : -1);
                return true;
            }
            case SPACE -> {
                if (!game.isMixing(4)) return false;
                if (down && !spaceHeld) {
                    spaceHeld = true;
                    game.holdMix(true);
                } else if (!down && spaceHeld) {
                    spaceHeld = false;
                    game.holdMix(false);
                }
                return true;
            }
            default -> {
                return false;
            }
        }
    }

    /** Le cercle qui porte cette touche, ou −1. */
    private int loopRingOf(javafx.scene.input.KeyCode code) {
        for (int ring = 0; ring < Game.MAX_RINGS; ring++) if (code != null && code == loopSettings.loopKey(ring)) return ring;
        return -1;
    }

    private void steer() {
        double[] direction = direction();
        game.setPlaneInput(direction[0], direction[1]);
    }

    /** La direction des touches tenues : x vers la droite, y vers le bas ; (0, 0) sans touche. */
    private double[] direction() {
        double dx = 0, dy = 0;
        if (held.contains(javafx.scene.input.KeyCode.Q) || held.contains(javafx.scene.input.KeyCode.LEFT)) dx -= 1;
        if (held.contains(javafx.scene.input.KeyCode.D) || held.contains(javafx.scene.input.KeyCode.RIGHT)) dx += 1;
        if (held.contains(javafx.scene.input.KeyCode.Z) || held.contains(javafx.scene.input.KeyCode.UP)) dy -= 1;
        if (held.contains(javafx.scene.input.KeyCode.S) || held.contains(javafx.scene.input.KeyCode.DOWN)) dy += 1;
        return new double[] {dx, dy};
    }

    /** Une amélioration de la ligne : son nom, où elle en est, et ce que donne le niveau suivant. */
    private String describe(Game.LineUpgrade upgrade) {
        return switch (upgrade) {
            case YIELD -> "Densité (niveau " + game.lineLevel(upgrade) + ") : " + shardText(game.lineShardsPerTouch())
                    + " → " + shardText(game.lineShardsPerTouch() + Game.LINE_SHARD * game.hadronBoost(idle.core.collider.Hadron.OMEGA)) + " segment par trait touché";
            case TICKS -> "Graduation (" + game.lineTicks() + " traits) : un trait de plus, tous à égale distance";
            case SPEED -> "Élan (vitesse ×" + shardText(game.lineSpeed()) + ") : les boules vont " + percent(Game.LINE_SPEED_STEP) + " plus vite";
            case BALLS -> "Boules (" + game.lineBalls() + " par ligne) : une boule de plus sur chaque ligne";
            case LINES -> "Lignes (" + game.lineCount() + ") : une ligne de plus, avec ses traits et ses boules";
        };
    }

    private static String shardText(double value) {
        return Format.darkMatter(value);
    }

    /** Un débit d'éclats : deux décimales sous 1, une au-delà. */
    private static String rate(double perSecond) {
        if (perSecond < 1) return String.format(java.util.Locale.ROOT, "%.2f", Math.floor(perSecond * 100 + 1e-9) / 100);
        return Format.darkMatter(BigNum.of(perSecond));
    }

    /** Ouvre la fenêtre de cette dimension. */
    public void open(Dimension dimension) {
        leaveMix();
        view.show(dimension);
        view.setFreeCamera(freeCamera.getAsBoolean());
        title.setText("Dimension " + dimension.number() + " : " + dimension.label());
        held.clear();
        loopKeysHeld.clear();
        game.setPlaneInput(0, 0);
        line.setText(switch (dimension) {
            case LINE -> dimension.line() + " Chaque trait que touche la boule donne des segments.";
            case PLANE -> dimension.line() + " Chaque éclat ramassé donne des facettes, propres à cette dimension.";
            case VOLUME -> dimension.line() + " Plongez dans le cube : chaque boule cueillie de son centre donne des sphères.";
            case LOOP -> dimension.line() + (game.isLoopOpen()
                    ? " Cliquez chaque cercle quand son point passe dans une zone : plus le clic est juste, plus il donne de nœuds."
                    : " Il n'y a rien à y faire pour l'instant.");
            case MIX -> dimension.line() + (game.isMixOpen()
                    ? " Un seul mini-jeu, qui mêle étape par étape les mécaniques des autres dimensions : chaque étape gagnée y mêle la suivante."
                    : " Il n'y a rien à y faire pour l'instant.");
            case MIRROR -> dimension.line() + (game.isMirrorOpen()
                    ? " Retenez le motif qui s'allume à gauche, puis refaites-le en miroir, à droite : chaque motif réussi donne des reflets."
                    : " Il n'y a rien à y faire pour l'instant.");
            case GRID -> dimension.line() + (game.isGridOpen()
                    ? " Sondez ses cases, couche par couche : plus une case est près d'un point caché, plus elle donne de repères."
                    : " Il n'y a rien à y faire pour l'instant.");
            case CLICKER -> dimension.line() + (game.isClickerOpen()
                    ? " Cliquez la surface, et vite : plus la cadence est haute, plus chaque clic donne d'étincelles."
                    : " Il n'y a rien à y faire pour l'instant.");
            case BRANE -> dimension.line() + (game.isBraneOpen()
                    ? " Tirez la membrane et relâchez-la : chaque point que touche l'onde, ou l'un de ses rebonds, donne des ondes."
                    : " Il n'y a rien à y faire pour l'instant.");
            default -> dimension.line() + (dimension == Dimension.DURATION && game.isDurationOpen()
                    ? " Tenez le bouton du milieu : plus les spirales vont loin vers le centre, plus elles donnent d'instants."
                    : " Il n'y a rien à y faire pour l'instant.");
        });
        setVisible(true);
        refresh();
    }

    /**
     * Referme la fenêtre : retour au jeu. Une plongée en cours s'arrête là, le joueur ressort du cube, sauf si la
     * plongée automatique la mène (version 0.150) : elle continue sans la fenêtre.
     */
    public void close() {
        // La durée : fermer la fenêtre relâche le bouton, qui donne ce qu'il avait ; l'appui automatique, lui, continue.
        view.releaseHold();
        // La brane : la membrane tenue se lâche sans onde.
        view.cancelBrane();
        leaveMix();
        held.clear();
        loopKeysHeld.clear();
        game.setPlaneInput(0, 0);
        if (game.isInVolume() && !game.isDimensionAutomationRunning(DimensionAutomation.VOLUME_DIVE)) game.leaveVolume();
        view.resetDive();
        setVisible(false);
    }

    /**
     * Le mélange lâche ce que la fenêtre tenait : la charge (versée, comme au relâchement) et la direction du point. Rien
     * si le mélange n'est pas montré.
     */
    private void leaveMix() {
        if (view.dimension() == Dimension.MIX && game.isMixOpen()) {
            view.releaseMix(true);
            if (spaceHeld) game.holdMix(false);
            game.setMixDirection(0, 0);
        }
        spaceHeld = false;
    }

    public boolean isOpen() {
        return isVisible();
    }

    /** La dimension montrée. */
    public Dimension dimension() {
        return view.dimension();
    }

    public String titleText() {
        return title.getText();
    }

    /** Une image : la vue montrée, puis ce qui est écrit sous elle. */
    public void frame(double elapsed, boolean moving) {
        if (!isVisible()) return;
        view.frame(elapsed, moving);
        refresh();
    }

    /** Le bouton d'une amélioration du mélange : pour les vérifications. */
    public Button mixButton(Game.MixUpgrade upgrade) {
        return mixButtons.get(upgrade);
    }

    /** L'étape, ce qu'il en reste à gagner, et le bouton qui mêle la dimension suivante : pour les vérifications. */
    public String mixStageText() {
        return mixStage.getText();
    }

    public String mixProgressText() {
        return mixProgress.getText();
    }

    /** La part remplie de la barre de progression, de 0 à 1. */
    public double mixProgressShare() {
        return mixBarFill.getPrefWidth() / MIX_BAR_WIDTH;
    }

    public Button mixAdvanceButton() {
        return mixAdvance;
    }

    /** Vrai si l'étape et sa barre se montrent, au-dessus de l'arène. */
    public boolean mixStageShown() {
        return mixStageBox.isVisible();
    }

    public String mixShardsText() {
        return mixShards.getText();
    }

    public String mixThresholdText() {
        return mixThreshold.getText();
    }

    public String mixHintText() {
        return mixHint.getText();
    }

    /** Le malus, les multiplicateurs, la charge, la cadence, les trésors, les paires et le dernier gain : pour les vérifications. */
    public String mixInfoText() {
        return mixInfo.getText();
    }

    /** Le détail du mélange, vide tant que la touche de détail n'est pas tenue : pour les vérifications. */
    public String mixDetailText() {
        return mixDetail.getText();
    }

    /** Le visuel : pour les vérifications. */
    public DimensionView view() {
        return view;
    }

    /** Le bouton d'une amélioration de la ligne : pour les vérifications. */
    public Button lineButton(Game.LineUpgrade upgrade) {
        return buttons.get(upgrade);
    }

    public Button yieldButton() {
        return buttons.get(Game.LineUpgrade.YIELD);
    }

    public Button ticksButton() {
        return buttons.get(Game.LineUpgrade.TICKS);
    }

    /** Le bouton d'une amélioration du plan : pour les vérifications. */
    public Button planeButton(Game.PlaneUpgrade upgrade) {
        return planeButtons.get(upgrade);
    }

    /** Le bouton d'une amélioration du volume : pour les vérifications. */
    public Button volumeButton(Game.VolumeUpgrade upgrade) {
        return volumeButtons.get(upgrade);
    }

    public String volumeShardsText() {
        return volumeShards.getText();
    }

    /** Le bouton d'une amélioration de la durée : pour les vérifications. */
    public Button durationButton(Game.DurationUpgrade upgrade) {
        return durationButtons.get(upgrade);
    }

    public String durationShardsText() {
        return durationShards.getText();
    }

    public String durationHintText() {
        return durationHint.getText();
    }

    /** Le bouton d'une amélioration de la boucle : pour les vérifications. */
    public Button loopButton(Game.LoopUpgrade upgrade) {
        return loopButtons.get(upgrade);
    }

    public String loopShardsText() {
        return loopShards.getText();
    }

    public String loopThresholdText() {
        return loopThreshold.getText();
    }

    public String loopHintText() {
        return loopHint.getText();
    }

    /** Le bouton d'une amélioration du miroir : pour les vérifications. */
    public Button mirrorButton(Game.MirrorUpgrade upgrade) {
        return mirrorButtons.get(upgrade);
    }

    public String mirrorShardsText() {
        return mirrorShards.getText();
    }

    public String mirrorThresholdText() {
        return mirrorThreshold.getText();
    }

    public String mirrorHintText() {
        return mirrorHint.getText();
    }

    public String mirrorCountsText() {
        return mirrorCounts.getText();
    }

    /** La taille du plateau, et les réussites qu'il manque pour l'agrandir : pour les vérifications. */
    public String mirrorBoardText() {
        return mirrorBoard.getText();
    }

    /** Le détail du miroir, vide tant que la touche de détail n'est pas tenue : pour les vérifications. */
    public String mirrorDetailText() {
        return mirrorDetail.getText();
    }

    /** Le bouton d'une amélioration de la grille : pour les vérifications. */
    public Button gridButton(Game.GridUpgrade upgrade) {
        return gridButtons.get(upgrade);
    }

    public String gridShardsText() {
        return gridShards.getText();
    }

    public String gridThresholdText() {
        return gridThreshold.getText();
    }

    public String gridHintText() {
        return gridHint.getText();
    }

    public String gridLayerText() {
        return gridLayerLabel.getText();
    }

    /** La taille de la grille et les essais par point : pour les vérifications. */
    public String gridSizeText() {
        return gridSize.getText();
    }

    /** Les champs de la case visée (x, y, z), le bouton qui l'essaie, et ceux du zoom : pour les vérifications. */
    public TextField[] gridFields() {
        return new TextField[] {gridX, gridY, gridZ};
    }

    public Button gridTryButton() {
        return gridTry;
    }

    public Button gridZoomInButton() {
        return gridZoomIn;
    }

    public Button gridZoomOutButton() {
        return gridZoomOut;
    }

    /** Les boutons de couche, du dessous et du dessus : pour les vérifications. */
    public Button gridDownButton() {
        return gridDown;
    }

    public Button gridUpButton() {
        return gridUp;
    }

    /** Le détail de la grille, vide tant que la touche de détail n'est pas tenue : pour les vérifications. */
    public String gridDetailText() {
        return gridDetail.getText();
    }

    /** Le bouton d'une amélioration du clicker : pour les vérifications. */
    public Button clickerButton(Game.ClickerUpgrade upgrade) {
        return clickerButtons.get(upgrade);
    }

    public String clickerShardsText() {
        return clickerShards.getText();
    }

    public String clickerThresholdText() {
        return clickerThreshold.getText();
    }

    public String clickerHintText() {
        return clickerHint.getText();
    }

    /** Le détail du clicker, vide tant que la touche de détail n'est pas tenue : pour les vérifications. */
    public String clickerDetailText() {
        return clickerDetail.getText();
    }

    /** Le bouton d'une amélioration de la brane : pour les vérifications. */
    public Button braneButton(Game.BraneUpgrade upgrade) {
        return braneButtons.get(upgrade);
    }

    public String braneShardsText() {
        return braneShards.getText();
    }

    public String braneThresholdText() {
        return braneThreshold.getText();
    }

    public String braneHintText() {
        return braneHint.getText();
    }

    /** Le détail de la brane, vide tant que la touche de détail n'est pas tenue : pour les vérifications. */
    public String braneDetailText() {
        return braneDetail.getText();
    }

    /** Le bouton du métronome : pour les vérifications. */
    public Button metronomeButton() {
        return metronomeButton;
    }

    /** Le bouton de la caméra libre : pour les vérifications. */
    public Button freeCameraButton() {
        return freeCameraButton;
    }

    public String volumeHintText() {
        return volumeHint.getText();
    }

    /** Vrai si les améliorations du volume se montrent : hors du cube seulement. */
    public boolean volumeUpgradesShown() {
        return volumeRow.isVisible();
    }

    public String planeShardsText() {
        return planeShards.getText();
    }

    public String thresholdText() {
        return threshold.getText();
    }

    public String shardsText() {
        return shards.getText();
    }

    /** La mention « automatique », vide quand elle est cachée : pour les vérifications. */
    public String autoBadgeText() {
        return autoBadge.isVisible() ? autoBadge.getText() : "";
    }

    public String planeHintText() {
        return planeHint.getText();
    }

    /** Le bouton de retour : pour les vérifications. */
    public Button backButton() {
        return back;
    }
}
