package idle.ui.common;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.StrokeLineCap;

/**
 * La petite icône animée d'un onglet (version 0.059), dans la couleur de l'onglet : des particules
 * qui tournent, un engrenage, une spirale de matière noire, deux faisceaux qui se croisent, un
 * éclair de Big Bang, trois quarks liés qui tournent, un buste et l'étoile de son titre, une étoile qui scintille, des barres qui
 * montent, des curseurs qui glissent.
 * Elle ne bouge que si les effets sont permis ; immobile, elle reste lisible.
 */
public final class TabIcon extends Canvas {

    /** Ce que montre l'icône : un dessin par onglet. */
    public enum Kind { PARTICLES, AUTOMATION, DARK_MATTER, COLLIDER, BIG_BANG, UNIVERSE, VOID, HADRONS, PROFILE, ACHIEVEMENTS, STATS, SETTINGS, SKINS }

    private final Kind kind;
    private final Color color;
    private double time;
    private boolean bright;
    /** La vitesse de l'animation : 1 d'habitude, plus quand ce que montre l'onglet s'accélère (version 0.061). */
    private double speed = 1;

    public void setSpeed(double speed) {
        this.speed = Double.isFinite(speed) ? Math.max(0.2, Math.min(speed, 8)) : 1;
    }

    public TabIcon(Kind kind, String color, double size) {
        super(size, size);
        this.kind = kind;
        this.color = Color.web(color);
        setMouseTransparent(true);
        draw();
    }

    public Kind kind() {
        return kind;
    }

    /** Le temps de l'animation : pour les vérifications. */
    public double time() {
        return time;
    }

    /** L'onglet affiché a son icône pleinement éclairée ; les autres la gardent plus sourde. */
    public void setBright(boolean bright) {
        if (this.bright == bright) return;
        this.bright = bright;
        draw();
    }

    /** Fait avancer l'animation ; {@code moving} faux (effets coupés) la laisse immobile. */
    public void frame(double elapsed, boolean moving) {
        if (moving) time += elapsed * speed;
        draw();
    }

    private void draw() {
        double s = getWidth();
        GraphicsContext g = getGraphicsContext2D();
        g.clearRect(0, 0, s, s);
        g.setGlobalAlpha(bright ? 1 : 0.7);
        g.setStroke(color);
        g.setFill(color);
        g.setLineCap(StrokeLineCap.ROUND);
        double c = s / 2;
        switch (kind) {
            case PARTICLES -> {
                g.fillOval(c - 2.5, c - 2.5, 5, 5);
                for (int k = 0; k < 3; k++) {
                    double a = time * (1.6 + 0.5 * k) + k * 2.1;
                    double r = s * (0.22 + 0.08 * k);
                    g.fillOval(c + r * Math.cos(a) - 1.6, c + r * Math.sin(a) - 1.6, 3.2, 3.2);
                }
            }
            case AUTOMATION -> {
                double a0 = time * 0.9;
                g.setLineWidth(s * 0.13);
                for (int k = 0; k < 8; k++) {
                    double a = a0 + k * Math.PI / 4;
                    g.strokeLine(c + s * 0.26 * Math.cos(a), c + s * 0.26 * Math.sin(a), c + s * 0.42 * Math.cos(a), c + s * 0.42 * Math.sin(a));
                }
                g.setLineWidth(s * 0.12);
                g.strokeOval(c - s * 0.24, c - s * 0.24, s * 0.48, s * 0.48);
            }
            case DARK_MATTER -> {
                g.setLineWidth(1.6);
                for (int arm = 0; arm < 2; arm++) {
                    double previousX = c, previousY = c;
                    for (int k = 1; k <= 14; k++) {
                        double t = k / 14.0;
                        double a = -time * 1.4 + arm * Math.PI + t * 3.2;
                        double r = t * s * 0.44;
                        double x = c + r * Math.cos(a), y = c + r * Math.sin(a);
                        g.setGlobalAlpha((bright ? 1 : 0.7) * (1 - 0.6 * t));
                        g.strokeLine(previousX, previousY, x, y);
                        previousX = x;
                        previousY = y;
                    }
                }
                g.setGlobalAlpha(bright ? 1 : 0.7);
                double pulse = 3 + 1.2 * Math.sin(time * 3);
                g.fillOval(c - pulse / 2, c - pulse / 2, pulse, pulse);
            }
            case COLLIDER -> {
                double rx = s * 0.42, ry = s * 0.26;
                g.setLineWidth(1.4);
                g.strokeOval(c - rx, c - ry, 2 * rx, 2 * ry);
                double a = time * 2.4;
                double meet = Math.abs(Math.cos(a));
                g.fillOval(c + rx * Math.sin(a) - 2, c - ry * Math.cos(a) - 2, 4, 4);
                g.fillOval(c - rx * Math.sin(a) - 2, c - ry * Math.cos(a) - 2, 4, 4);
                // Ils se croisent en bas : un éclat.
                if (Math.cos(a) < -0.9) {
                    g.setGlobalAlpha((meet - 0.9) * 10);
                    g.fillOval(c - 4, c + ry - 4, 8, 8);
                }
            }
            case BIG_BANG -> {
                double pulse = 0.5 + 0.5 * Math.sin(time * 2.2);
                g.setLineWidth(1.5);
                for (int k = 0; k < 8; k++) {
                    double a = k * Math.PI / 4 + time * 0.3;
                    double inner = s * 0.12, outer = s * (0.3 + 0.14 * (k % 2 == 0 ? pulse : 1 - pulse));
                    g.strokeLine(c + inner * Math.cos(a), c + inner * Math.sin(a), c + outer * Math.cos(a), c + outer * Math.sin(a));
                }
                g.fillOval(c - 2.5, c - 2.5, 5, 5);
            }
            case UNIVERSE -> {
                // Une galaxie spirale : deux bras de points qui tournent autour d'un cœur.
                for (int arm = 0; arm < 2; arm++) {
                    for (int p = 1; p <= 6; p++) {
                        double t = p / 6.0;
                        double a = time * 0.8 + arm * Math.PI + t * 3.4;
                        double r = s * 0.44 * t;
                        double dot = 2.4 - 1.2 * t;
                        g.fillOval(c + r * Math.cos(a) - dot / 2, c + r * Math.sin(a) * 0.75 - dot / 2, dot, dot);
                    }
                }
                g.fillOval(c - 2.5, c - 2.5, 5, 5);
            }
            case VOID -> {
                // Le vide (version 0.099) : une paire qui s'écarte, se rejoint et s'annule dans un éclair.
                double cycle = (time * 0.7) % 1;
                double open = Math.sin(Math.PI * Math.min(1, cycle / 0.85));
                double a = 0.6 + Math.floor(time * 0.7) * 1.9;
                double dx = Math.cos(a) * s * 0.3 * open, dy = Math.sin(a) * s * 0.3 * open;
                g.setLineWidth(1);
                g.setGlobalAlpha((bright ? 1 : 0.7) * 0.4);
                g.strokeLine(c - dx, c - dy, c + dx, c + dy);
                g.setGlobalAlpha(bright ? 1 : 0.7);
                g.fillOval(c + dx - 2.2, c + dy - 2.2, 4.4, 4.4);
                g.setFill(Color.web("#d9a6ff"));
                g.fillOval(c - dx - 2.2, c - dy - 2.2, 4.4, 4.4);
                if (cycle > 0.85) {
                    g.setFill(Color.WHITE);
                    g.setGlobalAlpha((1 - (cycle - 0.85) / 0.15) * 0.9);
                    double r = 2 + 6 * (cycle - 0.85) / 0.15;
                    g.fillOval(c - r, c - r, r * 2, r * 2);
                }
            }
            case HADRONS -> {
                // Les hadrons (version 0.149) : trois quarks reliés par leurs gluons, qui tournent ensemble ; leurs
                // couleurs, rouge, vert et bleu, passent de l'un à l'autre.
                double[] xs = new double[3], ys = new double[3];
                for (int k = 0; k < 3; k++) {
                    double a = time * 1.1 + k * 2 * Math.PI / 3 - Math.PI / 2;
                    xs[k] = c + s * 0.3 * Math.cos(a);
                    ys[k] = c + s * 0.3 * Math.sin(a);
                }
                g.setLineWidth(1.2);
                g.setGlobalAlpha((bright ? 1 : 0.7) * 0.6);
                for (int k = 0; k < 3; k++) g.strokeLine(xs[k], ys[k], xs[(k + 1) % 3], ys[(k + 1) % 3]);
                g.setGlobalAlpha(bright ? 1 : 0.7);
                Color[] charges = {Color.web("#ff8a7a"), Color.web("#9be7a8"), Color.web("#9fb8ff")};
                int shift = (int) Math.floor(time * 0.8) % 3;
                for (int k = 0; k < 3; k++) {
                    g.setFill(charges[(k + shift) % 3]);
                    g.fillOval(xs[k] - 2.6, ys[k] - 2.6, 5.2, 5.2);
                }
            }
            case PROFILE -> {
                // Le profil (version 0.147) : un buste, la tête et les épaules, et l'étoile du titre qui en fait le tour.
                g.fillOval(c - s * 0.16, s * 0.14, s * 0.32, s * 0.32);
                g.fillArc(c - s * 0.32, s * 0.54, s * 0.64, s * 0.62, 0, 180, javafx.scene.shape.ArcType.ROUND);
                double a = time * 1.3;
                g.setFill(Color.WHITE);
                g.setGlobalAlpha((bright ? 1 : 0.7) * 0.9);
                g.fillOval(c + s * 0.36 * Math.cos(a) - 1.4, s * 0.32 + s * 0.16 * Math.sin(a) - 1.4, 2.8, 2.8);
            }
            case ACHIEVEMENTS -> {
                double twinkle = 0.85 + 0.15 * Math.sin(time * 3);
                double[] xs = new double[10], ys = new double[10];
                for (int k = 0; k < 10; k++) {
                    double a = -Math.PI / 2 + k * Math.PI / 5;
                    double r = (k % 2 == 0 ? s * 0.44 : s * 0.19) * twinkle;
                    xs[k] = c + r * Math.cos(a);
                    ys[k] = c + r * Math.sin(a);
                }
                g.fillPolygon(xs, ys, 10);
                // Un éclat qui fait le tour.
                double a = time * 1.7;
                g.setFill(Color.WHITE);
                g.setGlobalAlpha(0.8);
                g.fillOval(c + s * 0.4 * Math.cos(a) - 1.2, c + s * 0.4 * Math.sin(a) - 1.2, 2.4, 2.4);
            }
            case STATS -> {
                double w = s * 0.18;
                for (int k = 0; k < 3; k++) {
                    double h = s * (0.3 + 0.2 * k + 0.12 * Math.sin(time * 2 + k * 1.3));
                    g.fillRoundRect(s * 0.12 + k * (w + s * 0.1), s * 0.88 - h, w, h, 2, 2);
                }
            }
            case SETTINGS -> {
                g.setLineWidth(1.4);
                for (int k = 0; k < 3; k++) {
                    double y = s * (0.25 + 0.25 * k);
                    g.strokeLine(s * 0.12, y, s * 0.88, y);
                    double x = s * (0.5 + 0.3 * Math.sin(time * 0.9 + k * 2));
                    g.fillOval(x - 2.6, y - 2.6, 5.2, 5.2);
                }
            }
            case SKINS -> {
                // Une palette (version 0.087) : trois pastilles qui changent de teinte tour à tour.
                g.fillOval(s * 0.1, s * 0.18, s * 0.8, s * 0.64);
                g.setFill(Color.web("#0e131b"));
                g.fillOval(s * 0.58, s * 0.52, s * 0.16, s * 0.16);
                Color[] dots = {Color.web("#ff9fd6"), Color.web("#9fe6ff"), Color.web("#ffe08a")};
                for (int k = 0; k < 3; k++) {
                    double glow = 0.55 + 0.45 * Math.sin(time * 1.6 + k * 2.1);
                    g.setFill(dots[k]);
                    g.setGlobalAlpha((bright ? 1 : 0.7) * glow);
                    g.fillOval(s * (0.22 + 0.17 * k), s * (0.3 + (k == 1 ? -0.04 : 0.02)), s * 0.15, s * 0.15);
                }
            }
        }
        g.setGlobalAlpha(1);
    }
}
