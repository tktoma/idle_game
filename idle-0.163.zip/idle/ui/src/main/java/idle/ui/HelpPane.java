package idle.ui;

import idle.core.Absence;
import idle.core.Game;
import idle.core.collider.Hadron;
import idle.core.elements.PeriodicTable;
import idle.core.math.BigNum;
import idle.core.probes.ProbeTrip;
import idle.core.profile.Title;
import idle.core.universe.DimensionAutomation;
import idle.ui.common.Detail;
import idle.ui.common.ElementText;
import idle.ui.common.Format;
import idle.ui.common.Labels;
import java.util.ArrayList;
import java.util.List;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.VBox;

/**
 * L'aide « Comment jouer », par-dessus la fenêtre : un paragraphe par étape du jeu, puis la liste
 * des raccourcis avec leurs touches du moment.
 *
 * <p>Seules les étapes que le joueur a atteintes sont expliquées : la suite se découvre en
 * jouant, et l'aide grandit avec la partie. Les nombres cités viennent des règles ({@link Game}) quand elles
 * les exposent ; les autres (en lettres : « dix minutes », « trois secondes », « cinquième Big Bang »…) sont
 * recopiés et à relire si la règle change.
 *
 * <p>Elle s'ouvre et se ferme par son raccourci ({@link Shortcuts.Action#HELP}), par le bouton
 * « Aide » sous les onglets, et se ferme aussi par Échap ou son bouton.
 */
final class HelpPane extends Overlay {

    private static final String TITLE_STYLE = "-fx-font-size: 15px; -fx-font-weight: bold; -fx-padding: 10 0 0 0; -fx-text-fill: #d6dde6;";
    private static final String TEXT_STYLE = "-fx-font-size: 13px; -fx-text-fill: #b7c4d2;";
    private static final String BUTTON_STYLE = buttonStyle("8 18", "#d6dde6");

    /**
     * Un paragraphe de l'aide.
     *
     * @param title son titre
     * @param text  ce qu'il explique
     */
    record Section(String title, String text) {
    }

    private final Game game;
    private final Settings settings;
    private final VBox content = new VBox(6);
    private final Button close = new Button("Fermer");
    private boolean open = false;

    HelpPane(Game game, Settings settings) {
        super(VEIL);
        this.game = game;
        this.settings = settings;
        Label title = new Label("Comment jouer");
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #e8f4ff;");
        close.setStyle(BUTTON_STYLE);
        close.setFocusTraversable(false);
        close.setOnAction(event -> close());
        content.setAlignment(Pos.TOP_LEFT);
        ScrollPane scroll = new ScrollPane(content);
        Labels.transparent(scroll);
        VBox card = new VBox(10, title, scroll, close);
        card.setAlignment(Pos.TOP_CENTER);
        card.setStyle(cardStyle("#3a4a5e", false, "20 26"));
        card.setMaxWidth(640);
        mount(card);
    }

    /** Vrai tant que l'aide est affichée. */
    boolean isOpen() {
        return open;
    }

    /** Ouvre l'aide si elle est fermée, la ferme sinon. */
    void toggle() {
        if (open) close();
        else open();
    }

    /** Ouvre l'aide, écrite pour la partie telle qu'elle est en ce moment. */
    void open() {
        open = true;
        content.getChildren().clear();
        for (Section section : sections(game, settings)) {
            Label title = new Label(section.title());
            title.setStyle(TITLE_STYLE);
            Label text = new Label(section.text());
            text.setStyle(TEXT_STYLE);
            text.setWrapText(true);
            content.getChildren().add(title);
            content.getChildren().add(text);
        }
        setVisible(true);
    }

    void close() {
        open = false;
        setVisible(false);
    }

    /** Les paragraphes de l'aide pour cette partie : ceux des étapes atteintes, puis ce qui vaut toujours. */
    static List<Section> sections(Game game, Settings settings) {
        List<Section> sections = new ArrayList<>();
        int generators = game.generatorsPerAtom();
        sections.add(new Section("Particules", "Un générateur crée des particules. Elles paient trois améliorations : la "
                + "vitesse de création, le couplage (chaque générateur renforce les autres) et un générateur de plus. "
                + "Réunis, les " + generators + " générateurs fusionnent en atomes : il n'en reste qu'un, et les "
                + "particules repartent de zéro."));
        boolean atoms = game.state().totalAtoms().sign() > 0 || game.isDarkMatterUnlocked() || game.isBigBangUnlocked();
        if (atoms) {
            sections.add(new Section("Atomes", "Les atomes paient des améliorations que la fusion ne reprend pas (onglet "
                    + "Atomes)." + (game.isAtomCapLifted() ? "" : " On ne peut en garder que " + Format.count(game.atomCap())
                    + " à la fois : il faut les dépenser pour fusionner de nouveau.") + " À " + Format.count(Game.UNLOCK_TOTAL_ATOMS) + " atomes créés s'ouvrent "
                    + "l'automatisation et le tableau périodique."));
        }
        if (game.isPeriodicTableUnlocked() || game.isDarkMatterUnlocked() || game.isBigBangUnlocked()) {
            sections.add(new Section("Automatisation", "Un automatisme s'achète une fois, en atomes, puis achète ou "
                    + "fusionne à votre place. Il se coupe et se relance d'un clic, et sa cadence s'accélère en atomes."
                    + (game.isDarkMatterUnlocked() || game.isBigBangUnlocked()
                            ? " Ceux de matière noire ne coûtent rien ; les deux qui achètent suivent le moins cher "
                                    + "d'abord, ou l'ordre que vous leur donnez sous leurs cartes." : "")
                    + (game.isBigBangUnlocked()
                            ? " L'espace et les Big Bangs en apportent d'autres : l'appui, la création, le rassemblement "
                                    + "et la formation automatiques." : "")
                    // Version 0.126 : où les réglages tiennent, sans rien dire de ce qui vient après le Big Bang.
                    + " Vos réglages (la coupure générale, les ordres d'achat, le seuil de fusion, le verrou de l'appui, la "
                    + "part d'espace laissée libre, les molécules favorites, les automatismes de matière noire allumés, les "
                    + "pauses du collisionneur) tiennent d'une remise à zéro à l'autre (explosion, "
                    + "Big Bang et au-delà) : seul « Recommencer de zéro », dans les réglages, les remet comme au début."
                    // Version 0.147 : ce que la coupure générale laisse tourner.
                    + (game.isColliderUpgradesUnlocked() ? " L'onglet montre aussi les automates du collisionneur, qui se "
                            + "mettent en pause un par un, et son déclencheur automatique" + (game.hasHose() ? ", et le tuyau "
                            + "d'arrosage de la graine" : "") + " : la coupure générale ne les arrête pas." : "")));
            sections.add(new Section("Tableau périodique", "Une synthèse coûte des atomes et donne un élément. Chaque "
                    + "élément apporte un bonus, ses exemplaires le renforcent, et une famille réunie forme un ensemble. "
                    + "Quand les " + PeriodicTable.ELEMENTS.size() + " éléments sont découverts, le tableau peut exploser."));
        }
        if (game.isDarkMatterUnlocked() || game.isBigBangUnlocked()) {
            sections.add(new Section("Matière noire", "L'explosion remet toute la matière à zéro et laisse de la matière "
                    + "noire. Tenez le clic sur son point pour la faire grossir. Son arbre a trois branches : l'une se "
                    + "paie en particules, l'autre en atomes, la troisième s'ouvre avec la taille. Sept bifurcations proposent deux voies côte à côte : en "
                    + "prendre une ferme l'autre jusqu'au prochain Big Bang, où le choix se refait ; la Superposition du "
                    + "collisionneur, à partir du cinquième Big Bang, ouvre les deux. À gauche, la voie de présence, la plus "
                    + "forte : elle renforce les paliers de vitesse ou rapporte de la matière noire. À droite, la voie d'absence, "
                    + "plus lente mais moins fatigante : elle rend plus du temps passé jeu fermé, et c'est elle que l'arbre prend "
                    + "seul pendant votre absence si vous n'avez pas choisi. Entre "
                    + "les branches, six liaisons, payées en matière noire, s'ouvrent par l'une ou l'autre des voies voisines ; "
                    + "quatre accords demandent trois voies du même style à la fois. Aucune case n'attend un nombre de "
                    + "matières noires : seuls les prix rythment l'arbre. Les défis sont des "
                    + "parties sous contrainte, avec une récompense qui reste. Au bout de l'arbre, les "
                    + game.bigBangConditions().size() + " conditions du prochain Big Bang, une fois réunies, le "
                    + "déclenchent. Exploser nettement plus vite que la fois d'avant (en moins de "
                    + ElementText.percent(Game.SPEED_PRIME_MARGIN) + " du temps) rapporte une prime de vitesse : une matière noire de plus."));
        }
        if (game.isBigBangUnlocked()) {
            // Version 0.126 : ce que le Big Bang garde, comme le dit l'arbre, et les paliers payants de la 0.124.
            sections.add(new Section("Big Bang", "Le Big Bang remet la partie à zéro comme une explosion, et efface en plus "
                    + "la matière noire en réserve et sa taille ; l'arbre de matière noire et les défis réussis ne restent "
                    + "qu'avec les paliers qui les gardent (les bifurcations se rouvrent quand même). Restent les succès, les "
                    + "records, le collisionneur et ce que l'onglet Big Bang a construit : molécules, astres, espace. Il ouvre l'expansion : l'espace grandit seul. Une molécule se crée avec des "
                    + "exemplaires du tableau périodique et de l'espace libre, et reste d'un Big Bang à l'autre. À partir de "
                    + Game.SUBSTANCE_MOLECULES + " molécules, une sorte se rassemble ; les sortes rassemblées forment des "
                    + "assemblages, puis des astres, jusqu'à la galaxie, l'amas de galaxies et l'univers. Les Big Bangs ouvrent des "
                    + "paliers, " + game.bigBangMilestones().size() + " en tout : une fois ouvert, un palier se paie en "
                    + "particules ou en atomes, d'un clic sur sa carte, et agit dès lors."));
        } else {
            sections.add(new Section("La suite", "Elle se découvre en jouant : cette aide grandit avec la partie."));
        }
        if (game.isBigBangUnlocked()) {
            sections.add(new Section("S'y retrouver au troisième acte", "Au-dessus des assemblages, des astres et de "
                    + "l'univers, la liste de courses dit ce qu'il manque pour le prochain pas, avec un bouton sur chaque "
                    + "ligne. Sur la page des molécules, la ligne « Meilleur achat » nomme la création qui rapporte le plus "
                    + "pour l'espace qu'elle prend, et un bouton range les cartes par rendement."));
            sections.add(new Section("Collections, comètes et défis", "Créer au moins une molécule de la moitié des sortes "
                    + "d'un rayon, puis de toutes, multiplie une grandeur pour de bon. De temps en temps une comète traverse "
                    + "l'expansion de la matière : la saisir double l'espace créé pendant "
                    + (int) (Game.COMET_BOOST_SECONDS / 60) + " minutes ; la manquer ne coûte rien. D'autres petites "
                    + "anomalies passent aussi, facultatives : un vent de particules (particules ×" + (int) Game.WIND_FACTOR
                    + " pendant " + (int) (Game.WIND_SECONDS / 60) + " minutes) ou une fenêtre d'exploration (les sondes en vol "
                    + "avancent de " + (int) (Game.EXPLORATION_SECONDS / 60) + " minutes) ; elles se masquent dans les réglages. L'amas de galaxies et "
                    + "l'univers demandent de la quantité et de la variété : un nombre de sortes rassemblées dans chaque état. "
                    + "La galaxie multiplie tout par " + (int) Game.GALAXY_FACTOR + ", l'amas puis l'univers par 2 chacun ; chaque état "
                    + "réuni pour l'amas ou l'univers est un jalon, +" + Math.round(Game.COSMOS_MILESTONE_GAIN * 100) + " % à tout. "
                    + "L'univers formé, un écran fait le bilan de la partie ; le jeu continue derrière."
                    + (game.isBangChallengesUnlocked() ? " Au cinquième Big Bang, les défis de Big Bang s'ouvrent sous "
                            + "les paliers : un Big Bang sous contrainte, pour une récompense qui reste." : "")));
        }
        sections.add(new Section("Lire une carte", "Une carte dit l'essentiel : son niveau en haut, ce qu'elle fait, son "
                + "prix en bas. Tenez la touche " + Detail.keyName(settings.detailKey()) + " pour lire les explications "
                + "complètes, partout dans le jeu."
                + (settings.stateSigns() ? " Devant son nom, un signe dit son état sans la couleur : ● à portée, ○ en "
                        + "attente, ◐ entamée, ▶ en marche, □ coupée, ✓ acquise, × fermée." : "")));
        sections.add(new Section("Lire un nombre", "Laissez la souris sur la production, les atomes par fusion, la matière "
                + "noire ou l'espace par seconde : une bulle dit de quoi le nombre est fait, un facteur par ligne. Sous "
                + "les onglets, l'objectif rappelle le prochain pas"
                + (game.isDarkMatterUnlocked() ? ", puis ce qu'il manque au prochain Big Bang" : "")
                + ". Les annonces qui passent en haut de l'écran restent dans le journal, deuxième sous-onglet de l'onglet Profil. Les réglages, "
                + "sous-onglet « Notifications et signes », coupent les annonces par catégorie, cachent les morceaux de "
                + "l'objectif un par un et les pastilles ● des onglets par sorte."));
        // Le profil (version 0.147) : là dès le premier générateur.
        if (game.isStarted()) sections.add(new Section("Profil", "L'onglet Profil dit qui joue : un nom, à écrire dans le "
                + "champ du haut (Entrée le valide), un avatar à choisir dans la galerie, ou une image à vous (PNG, JPG, GIF, BMP), "
                + "copiée dans le dossier du jeu et recadrée en rond. Chaque étape de la partie donne un titre, "
                + Title.values().length + " en tout : un clic sur un titre obtenu le porte, et certains avatars s'ouvrent avec "
                + "eux ; ils ne donnent aucun bonus. Le journal des annonces est le deuxième sous-onglet."
                + (game.isBigBangUnlocked() ? " Depuis le premier Big Bang, quatre albums gardent tout ce que vous avez obtenu au "
                        + "moins une fois, molécules, sortes rassemblées, assemblages et astres, avec le temps de jeu de la "
                        + "première fois ; ce qui manque reste un « ??? »." : "")
                + " Nom, avatar, titres et albums restent pour de bon, même après « Recommencer de zéro »."));
        if (game.isColliderUnlocked()) sections.add(new Section("Collisionneur", "Un onglet à part, depuis la première "
                + "explosion, que ni l'explosion ni le Big Bang ne remettent à zéro. Les faisceaux croisés donnent de l'énergie, et "
                + "huit générateurs se produisent l'un l'autre, de l'aimant supraconducteur au collisionneur de Planck : comptez "
                + "trois heures environ pour les avoir tous. Un clic quand les faisceaux se croisent capte trois secondes de production. "
                + "Avec le huitième s'ouvrent les améliorations, payées en énergie : d'abord « Collisions », qui donne à chaque "
                + "croisement " + Math.round(Game.COLLISION_CHANCE * 100) + " % de chances de sortir un quark, puis les saveurs une à une (étrange, charmée, belle, top), les "
                + "automates des générateurs, la vitesse des faisceaux, la production d'énergie et des générateurs, et la chaîne qui "
                + "renforce le reste du jeu, dans son sous-onglet « Chaîne », payée en énergie et en quarks : particules, atomes, "
                + "matière noire, vitesse de l'espace, dédoublement des molécules. L'énergie produite depuis le début ouvre les deux "
                + "trous noirs : " + Format.count(BigNum.of(Game.BLACK_HOLE_ENERGY)) + " pour le trou noir, "
                + Format.count(BigNum.of(Game.SUPERMASSIVE_ENERGY)) + " pour le trou noir supermassif, donc pour la galaxie. Les "
                + "succès du collisionneur, dans l'onglet « Succès », se gagnent en achetant des générateurs : chacun double une "
                + "production ou divise des prix par deux."));
        // Les dimensions (version 0.128) : une par univers, et ce que font les sept qui se jouent (la boucle, version 0.153 ;
        // la brane, version 0.154 ; le clicker, version 0.155 ; la grille, version 0.156 ; le miroir, version 0.157 ; le
        // mélange, version 0.158, refait à la 0.159).
        if (game.isDimensionsUnlocked()) sections.add(new Section("Dimensions", "Dans l'onglet Univers, une dimension "
                + "s'ouvre à chaque univers. Chacune a ses éclats, propres à elle, et un seuil d'éclats gagnés, un quart d'heure "
                + "de jeu environ, qui marque la dimension d'un rond vert. Ces éclats ont leur nom : les segments de la ligne, les facettes du plan, "
                + "les sphères du volume, les instants de la durée, les nœuds de la boucle, les ondes de la brane, les étincelles "
                + "du clicker, les repères de la grille, les reflets du miroir, les fragments du mélange ; ils paient aussi les améliorations de la graine (débit de l'arrosoir, tuyau d'arrosage, terre "
                + "fertile, étage du chrono et ses réglages, durée et force du rond de croissance, lumière astrale, météo, graine profonde, saisons, bulle des racines). La graine s'arrose à l'arrosoir : "
                + "débloqué sur son étagère, on le glisse sur elle, il se penche et verse. Chaque palier de la graine ouvre un "
                + "univers. Le chrono, sur l'étage du haut, se remplit de temps et fait passer tout le jeu plus vite, avec des "
                + "pertes d'autant plus fortes qu'il va vite. Au palier qui ouvre l'univers 4, des bulles naissent dans l'arbre : "
                + "une à la base, sur la graine, puis d'autres à chaque palier, reliées entre elles, jusqu'à l'arbre-monde et ses "
                + "racines. Un clic achète une bulle avec l'énergie du vide accumulée, une fois achetée une bulle reliée à elle "
                + "(la base d'abord) ; au survol, chacune dit ce qu'elle fait, et son effet vaut pour tous les univers suivants. Deux "
                + "se rachètent cinq fois, deux fois plus cher à chaque niveau ; celle des racines s'achète déjà, son effet "
                + "viendra plus tard. La ligne avance seule : chaque trait "
                + "que touche une boule donne des éclats. Le plan se joue au clavier, Z Q S D ou les flèches : on y ramasse les "
                + "éclats en passant dessus."
                + (game.isVolumeOpen() ? " Dans le volume, on clique le cube pour y plonger, puis on regarde autour de soi, "
                        + "clic gauche tenu, et l'on cueille les boules au clic droit ; avec la caméra libre, le regard suit la "
                        + "souris sans clic, qui reste retenue dans la vue (Échap la rend, un clic la reprend), et un clic "
                        + "cueille la boule sous la croix. Une plongée dure "
                        + idle.ui.common.ElementText.number(game.volumeDiveSeconds()) + " secondes ; à la fin, le cube rejette "
                        + "le joueur, et ses améliorations s'achètent dehors." : "")
                // La durée (version 0.134).
                + (game.isDurationOpen() ? " Dans la durée, on tient le bouton au milieu du rond (clic tenu, ou la barre "
                        + "d'espace) : les spirales avancent du bord vers le centre, qu'elles atteignent en "
                        + idle.ui.common.ElementText.number(game.durationMaxSeconds()) + " secondes. Au relâchement, chaque "
                        + "tour vaut un de plus que le précédent : tenir longtemps rapporte bien plus que plusieurs appuis "
                        + "courts, et tenir au-delà du centre ne rapporte plus rien, sans rien faire perdre. Ses améliorations "
                        + "(vitesse, nombre de spirales, valeur, temps au plus) s'achètent bouton relâché." : "")
                // La boucle (version 0.153), et le rond de croissance qui vient avec elle.
                + (game.isLoopOpen() ? " Dans la boucle, un point tourne sur chaque cercle, lentement au début, et des zones "
                        + "y attendent, chacune en trois parts : le bord « mauvais », puis « bien », le centre « excellent ». "
                        + "Un clic sur le cercle, ou sa touche (" + loopKeys(settings) + ", à changer dans les réglages, "
                        + "sous-onglet Clavier), quand le point est dans une zone donne des nœuds, d'autant plus que "
                        + "le clic est juste ; la zone touchée se pose ailleurs. Après chaque clic, juste ou non, le cercle "
                        + "attend " + ElementText.number(Game.LOOP_COOLDOWN) + " seconde : cliquer sans arrêt ne rapporte "
                        + "rien. Ses améliorations : rapidité du point, nombre de zones (jusqu'à " + Game.MAX_ZONES + "), "
                        + "gain par zone, précision, taille des zones, et des cercles de plus, jusqu'à " + Game.MAX_RINGS
                        + ", chacun sur sa touche. Un métronome, à brancher dans la fenêtre, fait un tic à chaque passage du "
                        + "point du premier cercle sur le centre d'une zone. Avec la boucle, un rond de croissance pousse de "
                        + "temps en temps près de la graine : cueilli d'un clic avant qu'il s'en aille, il accélère "
                        + "l'arrosage de " + Math.round(game.bloomGain() * 100) + " % pendant "
                        + ElementText.number(game.bloomSeconds()) + " secondes." : "")
                // La brane (version 0.154), et la lumière astrale qui vient avec elle.
                + (game.isBraneOpen() ? " Dans la brane, on appuie la membrane en un point, on glisse pour la tendre (plus "
                        + "le glissé est long, plus l'onde portera loin ; un cercle en pointillé montre sa portée) et l'on "
                        + "relâche : une onde part du point appuyé, grandit et rebondit sur les bords. Des points apparaissent "
                        + "sur la membrane, un toutes les " + ElementText.number(Game.BRANE_SPAWN_SECONDS) + " secondes, "
                        + Game.BRANE_MAX_POINTS + " au plus ; chaque passage du front sur un point, en direct puis après chaque "
                        + "rebond, donne des ondes, davantage après un rebond et pour chaque passage de plus de la même onde. "
                        + "Une onde qui porte loin rebondit plusieurs fois, et chaque rebond la colore autrement. Les points "
                        + "touchés restent et comptent tant que l'onde court, puis partent avec elle ; une seule onde court à "
                        + "la fois. Ses améliorations : gain, élasticité (une tirée plus courte porte "
                        + "déjà à fond), grandeur des ondes, rebond, et points en une onde. Avec la brane, la lumière astrale "
                        + "de la graine, payée en ondes, multiplie l'arrosage par seconde de l'arrosoir et du tuyau." : "")
                // Le clicker (version 0.155), et la météo qui vient avec lui.
                + (game.isClickerOpen() ? " Dans le clicker, chaque clic sur la surface donne des étincelles, d'autant plus "
                        + "que vous cliquez vite : la cadence se compte sur les " + ElementText.number(Game.CLICKER_WINDOW)
                        + " dernières secondes, jusqu'à " + Math.round(Game.CLICKER_MAX_RATE) + " clics par seconde. "
                        + "L'amélioration « Zones ×2 » fait apparaître des zones, une toutes les "
                        + ElementText.number(Game.CLICKER_ZONE_EVERY) + " secondes, qui s'éteignent au bout d'un temps (leur "
                        + "anneau se vide) ; elles peuvent se superposer, et chaque endroit prend la couleur du nombre de zones "
                        + "qui le couvrent : un clic là où plusieurs se chevauchent rapporte d'autant plus, le multiplicateur "
                        + "s'écrit sous la souris. Ses autres améliorations : gain, multiplicateur de cadence, multiplicateur, "
                        + "durée, nombre et taille des zones, et zones superposées. Avec le clicker, la météo tombe sur la "
                        + "graine : un ciel variable, parfois du beau temps (arrosage +" + Math.round(game.weatherSunGain() * 100)
                        + " % pendant " + ElementText.number(game.weatherSunSeconds()) + " secondes), parfois un orage "
                        + "(arrosage −" + Math.round(Game.WEATHER_STORM_LOSS * 100) + " % pendant "
                        + ElementText.number(game.weatherStormSeconds()) + " secondes) ; la branche « Clicker » de la graine "
                        + "allonge le beau temps, raccourcit les orages et renforce le soleil." : "")
                // La grille (version 0.156), et la graine profonde qui vient avec elle.
                + (game.isGridOpen() ? " Dans la grille, des points se cachent dans un cube énorme, mille cases par côté "
                        + "au départ ; on choisit une couche (les boutons, la molette ou les flèches haut et bas), on vise une "
                        + "case (un clic sur la carte, que le zoom précise, ou ses coordonnées x, y, z) et on l'essaie. Chaque "
                        + "point n'a qu'un essai : il vise le point le plus proche, donne d'autant plus de repères qu'il en est "
                        + "près, le trouve s'il tombe sur sa case (×" + ElementText.number(Game.GRID_FOUND) + "), puis le point se "
                        + "cache ailleurs. Après chaque essai, la grille attend " + ElementText.number(Game.GRID_COOLDOWN)
                        + " seconde. La réduction de la grille la rend plus petite, jusqu'à deux cases par côté : plus de "
                        + "chances de toucher ; petite, elle se montre case par case et un clic l'essaie. L'affichage du point "
                        + "montre d'abord la distance de chaque essai (les cases essayées vont alors du froid au chaud), puis "
                        + "la couche et enfin la colonne du point visé par le dernier essai, tant qu'il lui reste un essai ; "
                        + "avant, seul le gain se voit. Ses autres améliorations : gain, nombre de points, multiplicateur de "
                        + "proximité, et des essais de plus par point. Avec la grille, la graine profonde, payée en repères, multiplie tout l'arrosage, jusqu'à "
                        + "la racine carrée de la puissance de dix de l'énergie du vide récupérée." : "")
                // Le miroir (version 0.157), et les saisons qui viennent avec lui.
                + (game.isMirrorOpen() ? " Dans le miroir, un motif s'allume case après case sur la moitié gauche du "
                        + "plateau, puis s'éteint : il faut le refaire de mémoire, en miroir, sur la moitié droite, dans le même "
                        + "ordre. Réussi, il donne des reflets, d'autant plus qu'il est long, et le suivant a une case de plus ; "
                        + "manqué, il donne un peu, et le suivant a une case de moins. Ses améliorations : gain, multiplicateur "
                        + "de longueur, temps de mémorisation, seconde chance (des erreurs permises) et plateau plus grand. "
                        + "Avec le miroir, les saisons passent sur la graine, deux minutes chacune : une fois l'amélioration "
                        + "« Saisons » achetée (elle attend l'étage du chrono), chaque arrosage remplit le chrono, davantage au "
                        + "printemps, moins en hiver. Toutes les " + Game.MIRROR_GROW_EVERY + " réussites, le plateau "
                        + "s'agrandit seul d'une colonne de chaque côté et d'une ligne, et le gain avec lui, "
                        + Game.MIRROR_GROWTHS + " fois au plus ; le « Plateau plus vaste » en permet davantage." : "")
                // Le mélange (version 0.158, refait à la 0.159), et la bulle des racines qui vient avec lui.
                + (game.isMixOpen() ? " Le mélange est un seul mini-jeu qui mêle, étape par étape, les mécaniques des "
                        + "autres dimensions, sur une arène carrée. À l'étape 1, une boule va et vient sur une ligne graduée ; "
                        + "chaque étape y mêle la dimension suivante : les éclats que pose la ligne et le point qui les ramasse "
                        + "(souris ou Z Q S D), leur profondeur (molette, ou A et E), la charge que tient le bouton droit ou "
                        + "la barre d'espace, le rythme du cercle au relâchement, l'onde qui part du point et rebondit, la "
                        + "cadence des clics et les zones ×2, le trésor caché que le halo du point dit chaud ou froid, et les "
                        + "paires d'éclats de part et d'autre du miroir. Les fragments gagnés à une étape ouvrent la suivante "
                        + "(« Mêler la dimension suivante ») : chaque dimension mêlée ajoute "
                        + ElementText.number(Game.MIX_STAGE_BONUS * 100) + " % au gain, mais les améliorations du mélange, "
                        + "propres à chaque étape, repartent de zéro, et le malus de départ ("
                        + ElementText.number(Game.MIX_MALUS * 100) + " %) revient. Avec le mélange, la dernière amélioration "
                        + "de la graine, payée en fragments, ouvre la bulle des racines." : "")
                // Le défi final (version 0.160), que la bulle des racines ouvre.
                + (game.isFinalChallengeOpen() ? " La bulle des racines ouvre le défi final : un palier à atteindre dans "
                        + "chaque dimension, en ressource gagnée en tout (cent fois son seuil, dix millions de fragments pour "
                        + "le mélange). Sur la carte des dimensions, chaque point se remplit de vert vers son palier, en "
                        + "puissances de dix, et devient tout vert une fois le palier atteint ; le seuil y devient un anneau "
                        + "vert autour du point. Les dix paliers atteints, la partie est finie : les traits de la carte "
                        + "deviennent verts dans une aura dorée, le point du milieu grandit, et l'écran de fin s'ouvre. Le jeu "
                        + "continue derrière, et « Revoir la fin » la rejoue." : "")));
        // L'automatisation des dimensions (version 0.150) : avec la bulle du sommet de l'arbre-monde.
        if (game.isDimensionAutomationUnlocked()) sections.add(new Section("Automatisation des dimensions", "La bulle du "
                + "sommet de l'arbre-monde ouvre le sous-onglet « Dimensions » de l'onglet Automatisation : "
                + DimensionAutomation.values().length + " automatismes qui jouent les dimensions à votre place et achètent "
                + "leurs améliorations. Dans chaque dimension, ils s'achètent l'un après l'autre : ceux de la ligne en graines "
                + "d'univers, ceux du plan en " + Game.dimensionResourceName(1) + ", ceux du volume en "
                + Game.dimensionResourceName(2) + ", ceux de la durée en " + Game.dimensionResourceName(3) + ", ceux de la "
                + "boucle en " + Game.dimensionResourceName(4) + ", ceux de la brane en " + Game.dimensionResourceName(5)
                + ", ceux du clicker en " + Game.dimensionResourceName(6) + ", ceux de la grille en "
                + Game.dimensionResourceName(7) + ", ceux du miroir en " + Game.dimensionResourceName(8) + ", ceux du "
                + "mélange en " + Game.dimensionResourceName(9) + ". La visée "
                + "automatique fait filer le point du plan vers l'éclat le plus proche tant que vous ne tenez aucune touche ; "
                + "la plongée automatique plonge seule dans le volume et y cueille une boule toutes les "
                + ElementText.number(Game.VOLUME_AUTO_SHOT_SECONDS) + " seconde ; l'appui automatique tient le "
                + "bouton de la durée jusqu'au centre, relâche et recommence ; le rythme automatique clique « bien » à chaque "
                + "passage d'un point de la boucle dans une zone, clic par clic ; la tirée automatique tire la membrane de "
                + "la brane à fond, sur le point qui en touche le plus, toutes les " + ElementText.number(Game.BRANE_AUTO_SECONDS)
                + " secondes ; les clics automatiques cliquent " + ElementText.number(Game.CLICKER_AUTO_RATE) + " fois par "
                + "seconde là où se superposent le plus de zones du clicker ; les essais automatiques essaient toutes "
                + "les " + ElementText.number(Game.GRID_AUTO_SECONDS) + " secondes une case près d'un point de la grille ; "
                + "le miroir automatique refait le motif, une case toutes les " + ElementText.number(Game.MIRROR_AUTO_STEP)
                + " seconde ; le mélange automatique mène le point, plonge, tient et relâche la charge en rythme, clique et "
                + "passe seul aux étapes suivantes. Les autres achètent chacun une amélioration dès "
                + "qu'elle est payable. Ils jouent même fenêtre fermée, et une mention « automatique » le dit dans la fenêtre "
                + "de la dimension. Un clic sur une carte en met un en pause ; « Couper tous les automatismes » les arrête "
                + "tous. Achetés, ils traversent les univers."));
        // Le vide (version 0.129) : dès qu'il se propose, et tant qu'il est ouvert ou qu'un cumul est gardé.
        if (game.isVoidOffered() || game.isVoidUnlocked() || !game.state().voidHistory().isEmpty()) sections.add(new Section("Le vide",
                "Au premier Big Bang du troisième univers, puis de chaque univers suivant, le vide se propose dans l'onglet "
                + "Collisionneur : il s'ouvre contre dix minutes de production du collisionneur, comptées à son arrivée, et au moins "
                + Format.count(BigNum.of(Game.VOID_UNLOCK_COST)) + " énergie. Ouvert, le collisionneur y fait naître des paires de "
                + "particules, une par seconde au départ. Chacune coûte une demi-seconde de production du collisionneur, tient un "
                + "cinquième de seconde d'expansion d'espace libre pendant ses " + (int) Game.VOID_PAIR_LIFE + " secondes de vie, et donne 1 énergie du vide à sa "
                + "naissance. Un réglage dit quelle part du collisionneur et de l'espace libre le vide peut prendre (un quart au "
                + "départ). L'énergie du vide fond de " + String.format(java.util.Locale.FRANCE, "%.1f", Game.VOID_DECAY * 100) + " % par seconde : elle monte vers l'équilibre affiché, le gain par seconde "
                + "divisé par la fonte. Elle paie huit améliorations, dans le sous-onglet « Améliorations » : gain par paire, rythme, "
                + "coût en énergie, espace par paire, fonte plus lente, et trois qui raccourcissent le troisième acte : allègement "
                + "du ciel (−" + Math.round(Game.VOID_LIGHTEN_STEP * 100) + " % par niveau des molécules et de la matière que "
                + "demandent les astres, l'amas et l'univers), maturation plus courte (−" + Math.round(Game.VOID_MATURE_STEP * 100)
                + " % par niveau du temps de maturation des astres, aussi pour ceux qui mûrissent déjà) et rassemblement plus court "
                + "(−" + Math.round(Game.VOID_SETTLE_STEP * 100) + " % par niveau du délai de l'amas et de l'univers). Le premier trou noir formé ouvre le trou noir du vide : les particules qu'on lui sacrifie lui donnent "
                + "une masse qui raccourcit la vie des paires et ralentit la fonte. À la formation de l'univers, l'énergie du vide qui "
                + "reste rejoint le cumul, affiché dans le sous-onglet Graine de l'onglet Univers, où il paie les bulles de l'arbre ; "
                + "le vide, son trou noir et ses améliorations repartent de zéro dans l'univers suivant."));
        // Les hadrons (version 0.149) : dès qu'ils se proposent, et tant que leur onglet est ouvert.
        if (game.isHadronsOffered() || game.isHadronsUnlocked()) sections.add(new Section("Hadrons",
                "Avec la bulle de l'arbuste, au milieu, les hadrons se proposent dans l'onglet Collisionneur : leur onglet "
                + "s'ouvre contre dix minutes de production du collisionneur, comptées à leur arrivée, et au moins "
                + Format.count(BigNum.of(Game.HADRONS_UNLOCK_COST)) + " énergie, une fois par univers ; la bulle du jeune arbre, "
                + "à gauche, l'ouvre dès le début de chaque univers. Dans le sous-onglet « Gluons », les quarks des collisions "
                + "se lient en hadrons : le proton (deux quarks haut, un bas) et le neutron (un haut, deux bas), puis, avec la "
                + "bulle du cœur de l'arbre-monde, " + (Hadron.values().length - 2) + " particules exotiques, mésons et baryons "
                + "étranges, charmés ou beaux. Un antiquark coûte un quark de sa saveur. « Lier 1 » en assemble un, « Lier "
                + "tout » autant que les quarks en main le permettent. Chaque sorte renforce une grandeur, ou divise un prix, "
                + "de ×(1 + " + hundredths(Game.HADRON_BOOST_STEP) + " × log₁₀(1 + n)) pour n hadrons de cette sorte : ×"
                + hundredths(1 + Game.HADRON_BOOST_STEP) + " à 9, ×" + hundredths(1 + 2 * Game.HADRON_BOOST_STEP) + " à 99, ×"
                + hundredths(1 + 3 * Game.HADRON_BOOST_STEP) + " à 999. " + hadronBonuses() + ". Chaque quark "
                + "lié compte un gluon ; les paliers de gluons, dans le sous-onglet « Paliers », agissent dès qu'ils sont "
                + "atteints : " + gluonMilestones() + ". Le sous-onglet « Liaison » montre les quarks se lier. Un nouvel "
                + "univers reprend les hadrons, et leurs gluons avec, sauf avec la bulle de l'arbre ancien, à gauche, qui les garde."));
        if (game.bodiesFormed() > 0) sections.add(new Section("Maturation des astres", "Un astre formé mûrit avant de compter "
                + "en entier : de 12 minutes pour un amas de roches à 6 heures pour le trou noir supermassif"
                + (game.maturationShare() < 1 ? ", " + Math.round((1 - game.maturationShare()) * 100) + " % de moins avec le vide" : "")
                + ". En attendant, il donne "
                + "le quart de son bonus, et ne compte ni pour les astres qui partent de lui ni pour la galaxie. "
                + game.maturationPlaces() + " astres mûrissent à la fois. Le bouton « Accélérer » dépense une charge d'impulsion pour gagner " + idle.ui.common.ElementText.number(idle.core.Game.MATURATION_HASTE_SECONDS) + " secondes."));
        if (game.isSolarSystemsUnlocked()) sections.add(new Section("Systèmes solaires", "Dans le Big Bang, depuis le sixième. "
                + "Autour d'une étoile mûre, on range des planètes, de la plus proche à la plus lointaine, et des lunes, une par "
                + "planète au plus. Un système est complet à " + Game.SYSTEM_MIN_PLANETS + " planètes ; la galaxie en demande "
                + Game.SYSTEMS_FOR_GALAXY + ". L'harmonie : un point par planète bien placée (telluriques près, glacées et gazeuses "
                + "au loin), par lune, pour une étoile géante, et deux pour une planète océan en deuxième ou troisième orbite d'un "
                + "Soleil ou d'une naine rouge. Chaque point d'un système complet ajoute " + ElementText.percent(Game.SYSTEM_GAIN)
                + " à toutes les grandeurs. Au septième Big Bang, deux places de maturation et une sonde de plus ; au huitième, "
                + "les matières exotiques : cinq astres sans assemblage, que la galaxie demande aussi."));
        if (game.isProbesUnlocked()) sections.add(new Section("Sondes", "Dans le Big Bang, depuis le troisième. On choisit une "
                + "destination, puis un voyage de " + (int) (ProbeTrip.SHORT.seconds() / 60) + " minutes à " + (int) (ProbeTrip.NIGHT.seconds() / 3600) + " heures ; plus il est long, plus le butin est riche par heure. À l'"
                + "arrivée, la sonde attend à destination : un clic sur elle" + claimKey(settings) + " ouvre son butin, une carte par clic, ou tout d'un coup : des éléments "
                + "du rayon visé, de l'espace d'un coup, un sursaut qui double l'espace par seconde un moment, des échantillons. "
                + "Les échantillons paient les améliorations : instruments, moteurs, réserves d'énergie, soute et hangar. "
                + "Rien ne se perd si l'on revient tard, ni au Big Bang."));
        sections.add(new Section("Sauvegarde et absence", "La partie s'écrit toute seule toutes les "
                + settings.saveDelay().label() + " (le rythme se choisit dans les réglages) et à la fermeture. Au retour, "
                + (settings.offline() ? "" : "si le temps hors ligne est rejoué (il est coupé en ce moment), ")
                + "une part du temps d'absence est rejouée : " + ElementText.percent(Game.OFFLINE_RATE_PARTICLES) + " au début, "
                + ElementText.percent(Game.OFFLINE_RATE_UNIVERSE) + " une fois l'univers formé, sur "
                + (int) (Absence.MAX_SECONDS / 3600) + " heures d'absence au plus. Les réglages permettent d'exporter la partie, de régler le volume des sons ou de les "
                + "couper, de limiter les images par seconde ou de couper les effets visuels un par un ; la fenêtre ralentit d'elle-même quand "
                + "elle n'est pas au premier plan. Des thèmes et des notations s'y ouvrent en faisant des choses très précises."));
        sections.add(new Section("Raccourcis clavier", shortcuts(settings)));
        return sections;
    }

    /** « (ou la touche R) » : la touche réglée pour réclamer un butin de sonde, rien si elle n'en a pas (version 0.126). */
    private static String claimKey(Settings settings) {
        KeyCode key = settings.shortcuts() ? settings.key(Shortcuts.Action.CLAIM) : null;
        return key == null ? "" : " (ou la touche " + Shortcuts.name(key) + ")";
    }

    /** La liste des raccourcis avec leurs touches du moment, un par ligne. */
    static String shortcuts(Settings settings) {
        if (!settings.shortcuts()) return "Les raccourcis sont coupés dans les réglages.";
        StringBuilder text = new StringBuilder();
        for (Shortcuts.Action action : Shortcuts.Action.values()) {
            KeyCode key = settings.key(action);
            if (text.length() > 0) text.append('\n');
            text.append(key == null ? "(aucune touche)" : Shortcuts.name(key)).append("  —  ").append(action.label());
        }
        text.append('\n').append(Detail.keyName(settings.detailKey())).append("  —  Afficher les détails")
                .append("\nLes touches se changent dans les réglages.");
        return text.toString();
    }

    /** « Proton : atomes par fusion ; … ; méson B : prix des générateurs divisé » : ce que renforce chaque hadron (version 0.151). */
    private static String hadronBonuses() {
        java.util.List<String> parts = new java.util.ArrayList<>();
        for (Hadron hadron : Hadron.values()) {
            parts.add(hadron.label() + " : " + hadron.bonus() + (hadron.lowersCost() ? ", divisé" : ""));
        }
        return String.join(" ; ", parts);
    }

    /** « 1,25 » : un nombre à deux décimales, à la française. */
    private static String hundredths(double value) {
        return String.format(java.util.Locale.FRANCE, "%.2f", value);
    }

    /** « Mémoire des liaisons (1 000 gluons) : l'explosion garde … » : les paliers de gluons (version 0.151). */
    private static String gluonMilestones() {
        java.util.List<String> parts = new java.util.ArrayList<>();
        for (idle.core.collider.GluonMilestone milestone : idle.core.collider.GluonMilestone.values()) {
            String effect = milestone.effect();
            parts.add(milestone.label() + " (" + Format.whole(milestone.gluons()) + " gluons), "
                    + Character.toLowerCase(effect.charAt(0)) + effect.substring(1, effect.length() - 1));
        }
        return String.join(" ; ", parts);
    }

    /** Les touches des sept cercles de la boucle, dans l'ordre : « S, D, F, Espace, J, K, L ». */
    private static String loopKeys(Settings settings) {
        StringBuilder keys = new StringBuilder();
        for (int ring = 0; ring < Game.MAX_RINGS; ring++) {
            KeyCode key = settings.loopKey(ring);
            keys.append(ring == 0 ? "" : ", ").append(key == null ? "aucune" : Shortcuts.name(key));
        }
        return keys.toString();
    }
}
