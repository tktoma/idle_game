package idle.core.universe;

/**
 * L'automatisation des dimensions (version 0.150), que la bulle du sommet de l'arbre-monde ouvre. Chaque dimension a
 * ses automatismes, qui s'achètent l'un après l'autre, dans l'ordre de cette liste : d'abord celui qui joue à la place
 * du joueur quand la dimension se joue à la main (la visée du plan, la plongée du volume, l'appui de la durée), puis un
 * par amélioration, qui l'achète dès qu'elle est payable. La ligne avance seule : elle n'a que ses améliorations.
 *
 * <p>Ceux de la dimension 1 se paient en graines d'univers ; ceux de la dimension n, avec la ressource de la dimension
 * n − 1 : les segments de la ligne pour le plan, les facettes du plan pour le volume, les sphères du volume pour la durée,
 * les instants de la durée pour la boucle (version 0.153), les nœuds de la boucle pour la brane (version 0.154), les ondes de la brane pour le clicker (version 0.155), les étincelles du clicker pour la grille (version 0.156), les repères de la grille pour le miroir (version 0.157), les reflets du miroir pour le mélange (version 0.158).
 */
public enum DimensionAutomation {
    LINE_YIELD(1, Kind.UPGRADE, 0, "Densité"),
    LINE_TICKS(1, Kind.UPGRADE, 1, "Graduation"),
    LINE_SPEED(1, Kind.UPGRADE, 2, "Élan"),
    LINE_BALLS(1, Kind.UPGRADE, 3, "Boules"),
    LINE_LINES(1, Kind.UPGRADE, 4, "Lignes"),
    PLANE_AIM(2, Kind.PLAY, -1, "Visée automatique"),
    PLANE_VALUE(2, Kind.UPGRADE, 0, "Valeur"),
    PLANE_SPAWN(2, Kind.UPGRADE, 1, "Réapparition"),
    PLANE_COUNT(2, Kind.UPGRADE, 2, "Nombre"),
    PLANE_SPEED(2, Kind.UPGRADE, 3, "Vitesse du point"),
    PLANE_SIZE(2, Kind.UPGRADE, 4, "Taille du point"),
    VOLUME_DIVE(3, Kind.PLAY, -1, "Plongée automatique"),
    VOLUME_TIME(3, Kind.UPGRADE, 0, "Durée"),
    VOLUME_VALUE(3, Kind.UPGRADE, 1, "Valeur"),
    VOLUME_SPAWN(3, Kind.UPGRADE, 2, "Réapparition"),
    VOLUME_COUNT(3, Kind.UPGRADE, 3, "Nombre"),
    VOLUME_SIZE(3, Kind.UPGRADE, 4, "Taille des boules"),
    DURATION_HOLD(4, Kind.PLAY, -1, "Appui automatique"),
    DURATION_SPEED(4, Kind.UPGRADE, 0, "Vitesse des spirales"),
    DURATION_COUNT(4, Kind.UPGRADE, 1, "Spirales"),
    DURATION_VALUE(4, Kind.UPGRADE, 2, "Valeur"),
    DURATION_TIME(4, Kind.UPGRADE, 3, "Temps au plus"),
    // Version 0.153 : la boucle, payée en instants de la durée.
    LOOP_PLAY(5, Kind.PLAY, -1, "Rythme automatique"),
    LOOP_SPEED(5, Kind.UPGRADE, 0, "Rapidité"),
    LOOP_ZONES(5, Kind.UPGRADE, 1, "Zones"),
    LOOP_GAIN(5, Kind.UPGRADE, 2, "Gain par zone"),
    LOOP_PRECISION(5, Kind.UPGRADE, 3, "Précision"),
    LOOP_SIZE(5, Kind.UPGRADE, 4, "Taille des zones"),
    LOOP_RINGS(5, Kind.UPGRADE, 5, "Cercles"),
    // Version 0.154 : la brane, payée en nœuds de la boucle.
    BRANE_PULL(6, Kind.PLAY, -1, "Tirée automatique"),
    BRANE_GAIN(6, Kind.UPGRADE, 0, "Gain"),
    BRANE_ELASTICITY(6, Kind.UPGRADE, 1, "Élasticité"),
    BRANE_SIZE(6, Kind.UPGRADE, 2, "Grandeur des ondes"),
    BRANE_BOUNCE(6, Kind.UPGRADE, 3, "Rebond"),
    BRANE_COMBO(6, Kind.UPGRADE, 4, "Points en une onde"),
    // Version 0.155 : le clicker, payé en ondes de la brane.
    CLICKER_PLAY(7, Kind.PLAY, -1, "Clics automatiques"),
    CLICKER_GAIN(7, Kind.UPGRADE, 0, "Gain"),
    CLICKER_SPEED(7, Kind.UPGRADE, 1, "Multiplicateur de cadence"),
    CLICKER_ZONES(7, Kind.UPGRADE, 2, "Zones ×2"),
    CLICKER_ZONE_MULT(7, Kind.UPGRADE, 3, "Multiplicateur des zones"),
    CLICKER_ZONE_TIME(7, Kind.UPGRADE, 4, "Durée des zones"),
    CLICKER_ZONE_COUNT(7, Kind.UPGRADE, 5, "Nombre de zones"),
    CLICKER_ZONE_SIZE(7, Kind.UPGRADE, 6, "Taille des zones"),
    CLICKER_STACK(7, Kind.UPGRADE, 7, "Zones superposées"),
    // Version 0.156 : la grille, payée en étincelles du clicker.
    GRID_PROBE(8, Kind.PLAY, -1, "Essais automatiques"),
    GRID_DIVISION(8, Kind.UPGRADE, 0, "Réduction de la grille"),
    GRID_GAIN(8, Kind.UPGRADE, 1, "Gain"),
    GRID_REVEAL(8, Kind.UPGRADE, 2, "Affichage du point"),
    GRID_POINTS(8, Kind.UPGRADE, 3, "Nombre de points"),
    GRID_PROXIMITY(8, Kind.UPGRADE, 4, "Multiplicateur de proximité"),
    GRID_ATTEMPTS(8, Kind.UPGRADE, 5, "Essais"),
    // Version 0.157 : le miroir, payé en repères de la grille.
    MIRROR_PLAY(9, Kind.PLAY, -1, "Miroir automatique"),
    MIRROR_GAIN(9, Kind.UPGRADE, 0, "Gain"),
    MIRROR_LENGTH(9, Kind.UPGRADE, 1, "Multiplicateur de longueur"),
    MIRROR_MEMORY(9, Kind.UPGRADE, 2, "Temps de mémorisation"),
    MIRROR_MISTAKES(9, Kind.UPGRADE, 3, "Seconde chance"),
    MIRROR_BOARD(9, Kind.UPGRADE, 4, "Plateau plus vaste"),
    // Version 0.158 : le mélange, payé en reflets du miroir.
    MIX_AUTO(10, Kind.PLAY, -1, "Mélange automatique"),
    // Version 0.159 : le mélange refait, une amélioration par mécanique mêlée.
    MIX_GAIN(10, Kind.UPGRADE, 0, "Gain"),
    MIX_MALUS(10, Kind.UPGRADE, 1, "Réduction du malus"),
    MIX_TICKS(10, Kind.UPGRADE, 2, "Graduations"),
    MIX_SPEED(10, Kind.UPGRADE, 3, "Vitesse du point"),
    MIX_DEPTH(10, Kind.UPGRADE, 4, "Profondeur"),
    MIX_CHARGE(10, Kind.UPGRADE, 5, "Charge"),
    MIX_RHYTHM(10, Kind.UPGRADE, 6, "Zone du rythme"),
    MIX_REACH(10, Kind.UPGRADE, 7, "Portée de l'onde"),
    MIX_ZONES(10, Kind.UPGRADE, 8, "Zones ×2"),
    MIX_TREASURE(10, Kind.UPGRADE, 9, "Trésor"),
    MIX_PAIRS(10, Kind.UPGRADE, 10, "Paires");

    /** Ce que fait l'automatisme : jouer la dimension, ou acheter une de ses améliorations. */
    public enum Kind { PLAY, UPGRADE }

    /** Le prix du premier automatisme de chaque dimension, dans la ressource qui le paie (graines, segments, facettes, sphères). */
    private static final double[] FIRST_COST = {1, 100_000, 500, 1_000, 50_000, 2_000, 2_000, 2_000, 2_000, 2_000};
    /** Ce que chaque automatisme suivant de la même dimension coûte de plus : ×2 (les graines : +1 tous les deux). */
    public static final double COST_GROWTH = 2;

    private final int dimension;
    private final Kind kind;
    private final int upgrade;
    private final String label;

    DimensionAutomation(int dimension, Kind kind, int upgrade, String label) {
        this.dimension = dimension;
        this.kind = kind;
        this.upgrade = upgrade;
        this.label = label;
    }

    /** La dimension qu'il automatise : 1 la ligne, 2 le plan, 3 le volume, 4 la durée, 5 la boucle, 6 la brane, 7 le clicker, 8 la grille, 9 le miroir, 10 le mélange. */
    public int dimension() {
        return dimension;
    }

    public Kind kind() {
        return kind;
    }

    /** Le rang de l'amélioration qu'il achète, dans l'ordre de son enum ({@code Game.LineUpgrade}…) ; −1 pour jouer. */
    public int upgrade() {
        return upgrade;
    }

    /** « Visée automatique », ou le nom de l'amélioration qu'il achète. */
    public String label() {
        return label;
    }

    /** Son rang parmi ceux de sa dimension : 0 pour le premier. */
    public int step() {
        int step = 0;
        for (DimensionAutomation other : values()) {
            if (other == this) return step;
            if (other.dimension == dimension) step++;
        }
        return step;
    }

    /** Celui d'avant dans sa dimension, qu'il faut avoir acheté ; {@code null} pour le premier. */
    public DimensionAutomation previous() {
        DimensionAutomation before = null;
        for (DimensionAutomation other : values()) {
            if (other == this) return before;
            if (other.dimension == dimension) before = other;
        }
        return before;
    }

    /**
     * Son prix : en graines d'univers pour la ligne (1, 1, 2, 2, 3), sinon le premier prix de sa dimension ×2 par
     * automatisme d'avant.
     */
    public double cost() {
        if (dimension == 1) return 1 + step() / 2;
        return FIRST_COST[dimension - 1] * Math.pow(COST_GROWTH, step());
    }

    /** La dimension dont la ressource le paie : 0 pour les graines d'univers. */
    public int paidWith() {
        return dimension - 1;
    }
}
