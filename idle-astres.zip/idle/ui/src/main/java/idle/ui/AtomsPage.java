package idle.ui;

import idle.core.BigNum;
import idle.core.Effect;
import idle.core.Game;
import idle.core.Resource;
import idle.core.Upgrade;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import javafx.animation.ScaleTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import javafx.util.Duration;

/**
 * Contenu de l'onglet « Atomes ». En haut, les atomes disponibles et le bonus en cours ;
 * en dessous, deux sous-pages :
 * <ul>
 *   <li>« Atome » : le grand atome animé, qui porte une orbe par atome disponible.
 *       Dépenser un atome lui retire donc une orbe ;</li>
 *   <li>« Améliorations » : ce qu'on peut acheter en dépensant des atomes, une {@link Card}
 *       chacune, rangées en colonnes selon la largeur de la fenêtre. Chaque carte dit le
 *       niveau, ce que l'amélioration vaut déjà, ce qu'elle fait en quelques mots, son prix
 *       et le nombre de fusions qu'il reste à faire ; l'explication complète vient en mode
 *       détails ({@link Detail}) ;</li>
 *   <li>« Tableau périodique » : la synthèse d'éléments et leurs effets ({@link PeriodicTablePage}).
 *       Cette sous-page n'apparaît qu'une fois assez d'atomes créés, comme l'automatisation.</li>
 * </ul>
 */
final class AtomsPage extends VBox {

    private static final String SUB_TAB_STYLE = "-fx-font-size: 13px; -fx-padding: 6 20; -fx-cursor: hand;"
            + " -fx-background-radius: 0; -fx-border-width: 0 0 2 0; -fx-background-color: transparent;";

    private final Game game;
    private final Label balanceLabel = new Label();
    private final Label bonusLabel = new Label();

    private final Button atomTab = new Button("Atome");
    private final Button upgradesTab = new Button("Améliorations");
    private final Button tableTab = new Button("Tableau périodique");
    /** Sous-page affichée : 0 = atome, 1 = améliorations, 2 = tableau périodique. */
    private int selected = 0;

    // Sous-page « Atome »
    private final AtomModelView atomView = new AtomModelView(240);
    /** L'atome prend la place disponible, en restant carré, jusqu'à 440 pixels de côté. */
    private final CanvasPane atomHolder = CanvasPane.square(atomView, 440);
    private final Label orbsLabel = new Label();
    private final Label hintLabel = new Label();
    private final VBox atomPane = new VBox(10, atomHolder, orbsLabel, hintLabel);

    // Sous-page « Améliorations »
    private final Map<Upgrade, Card> upgradeCards = new LinkedHashMap<>();
    private final TileGrid upgradeGrid = new TileGrid(200, 4, 10);
    private final ScrollPane upgradesPane = new ScrollPane(upgradeGrid);

    // Sous-page « Tableau périodique »
    private final PeriodicTablePage tablePage;
    private final ScrollPane tablePane;

    AtomsPage(Game game) {
        super(10);
        this.game = game;
        this.tablePage = new PeriodicTablePage(game);
        this.tablePane = new ScrollPane(tablePage);
        setAlignment(Pos.TOP_CENTER);
        setPadding(new Insets(16, 24, 24, 24));

        balanceLabel.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #ffd27f;");
        bonusLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #ffe9c2;");
        orbsLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #8fa3b8;");
        hintLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #8fa3b8;");

        atomTab.setOnAction(event -> select(0));
        upgradesTab.setOnAction(event -> select(1));
        tableTab.setOnAction(event -> select(2));
        HBox subTabs = new HBox(atomTab, upgradesTab, tableTab);
        subTabs.setAlignment(Pos.CENTER);

        atomPane.setAlignment(Pos.TOP_CENTER);
        VBox.setVgrow(atomHolder, Priority.ALWAYS);
        hintLabel.setWrapText(true);
        hintLabel.setTextAlignment(TextAlignment.CENTER);
        bonusLabel.setWrapText(true);
        bonusLabel.setTextAlignment(TextAlignment.CENTER);

        // Les cartes passent à la ligne selon la largeur ; si elles dépassent en hauteur, on fait défiler.
        upgradeGrid.setPadding(new Insets(12, 0, 12, 0));
        upgradesPane.setFitToWidth(true);
        upgradesPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        upgradesPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        tablePane.setFitToWidth(true);
        tablePane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        tablePane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");

        // Une carte par amélioration payée en atomes : en ajouter une dans core suffit à la faire apparaître.
        for (Upgrade upgrade : game.upgrades(Resource.ATOMS)) {
            Card card = new Card(GameApp.ATOMS_COLOR);
            card.setOnAction(() -> {
                game.buy(upgrade.id());
                refresh();
            });
            upgradeCards.put(upgrade, card);
            upgradeGrid.add(card);
        }

        // Les sous-pages sont empilées au même endroit ; une seule est visible à la fois.
        StackPane pages = new StackPane(atomPane, upgradesPane, tablePane);
        VBox.setVgrow(pages, Priority.ALWAYS);

        getChildren().add(balanceLabel);
        getChildren().add(bonusLabel);
        getChildren().add(subTabs);
        getChildren().add(pages);
        select(0);
    }

    /** Affiche une sous-page : 0 = atome, 1 = améliorations, 2 = tableau périodique. */
    private void select(int index) {
        selected = index;
        atomPane.setVisible(index == 0);
        upgradesPane.setVisible(index == 1);
        tablePane.setVisible(index == 2);
        atomTab.setStyle(subTabStyle(index == 0));
        upgradesTab.setStyle(subTabStyle(index == 1));
        tableTab.setStyle(subTabStyle(index == 2));
    }

    private static String subTabStyle(boolean selected) {
        return SUB_TAB_STYLE + (selected
                ? " -fx-text-fill: #ffd27f; -fx-border-color: transparent transparent #ffd27f transparent;"
                : " -fx-text-fill: #8fa3b8; -fx-border-color: transparent;");
    }

    /** Fait avancer l'animation de l'atome, quand il est visible. */
    void frame(double dt) {
        if (selected == 0) atomView.frame(dt);
    }

    /** Recopie l'état du jeu dans les textes et les boutons. */
    void refresh() {
        BigNum atoms = game.state().atoms();
        BigNum created = game.state().totalAtoms();
        // Le plafond n'est rappelé que lorsqu'il a bougé : après une explosion, le tableau est plus lourd.
        boolean heavier = game.tableWeight().gt(BigNum.ONE) && !game.isAtomCapLifted();
        balanceLabel.setText(Format.count(atoms) + (heavier ? " / " + Format.count(game.atomCap()) : "")
                + (atoms.gt(BigNum.ONE) ? " atomes disponibles" : " atome disponible"));
        BigNum perFusion = game.atomsPerFusion();
        bonusLabel.setText("Chaque création donne " + Format.amount(game.particlesPerCreation())
                + " particules   |   chaque fusion donne " + Format.amount(perFusion)
                + (perFusion.gt(BigNum.ONE) ? " atomes" : " atome"));

        // Une orbe par atome disponible, jusqu'au nombre d'éléments du tableau périodique :
        // un atome dépensé quitte le visuel.
        int orbs = (int) Math.min(AtomModelView.MAX_ORBS, atoms.toDouble());
        atomView.setOrbs(orbs);
        orbsLabel.setText(orbs + " / " + AtomModelView.MAX_ORBS + (orbs > 1 ? " orbes" : " orbe")
                + (atoms.gt(Game.MAX_ATOMS) ? " (l'atome n'en montre pas plus)" : "")
                + "   |   " + Format.count(created) + (created.gt(BigNum.ONE) ? " atomes créés" : " atome créé")
                + " depuis le début");
        // Le tableau périodique n'apparaît qu'une fois assez d'atomes créés, comme l'onglet Automatisation.
        boolean tableUnlocked = game.isPeriodicTableUnlocked();
        tableTab.setVisible(tableUnlocked);
        tableTab.setManaged(tableUnlocked);
        if (!tableUnlocked && selected == 2) select(0);
        tablePage.refresh();
        hintLabel.setText(game.isAtomCapReached()
                ? (tableUnlocked && !game.isPeriodicTableComplete()
                        ? "Maximum atteint : dépensez des atomes ou synthétisez un élément."
                        : "Maximum atteint : dépensez des atomes pour fusionner de nouveau.")
                : tableUnlocked ? Detail.only("Fusionnez les générateurs pour créer un atome de plus.")
                : "Automatisation et tableau périodique à " + Format.count(Game.UNLOCK_TOTAL_ATOMS)
                        + " atomes créés (vous : " + Format.count(created) + ")");

        upgradeCards.forEach(this::show);
    }

    /** Remplit la carte d'une amélioration : niveau, valeur actuelle, effet, prix, fusions restantes. */
    private void show(Upgrade upgrade, Card card) {
        String id = upgrade.id();
        int level = game.levelOf(id);
        boolean oneTime = upgrade.maxLevel() == 1;
        boolean maxed = game.isMaxed(id);
        String corner = oneTime ? "" : level + (upgrade.hasLimit() ? "/" + upgrade.maxLevel() : "");
        String mark = oneTime ? (maxed ? "acquis" : "") : level > 0 ? current(upgrade) : "";
        if (maxed) {
            card.show(Card.State.DONE, corner, mark, upgrade.name(), brief(upgrade), describe(upgrade), "", "");
            return;
        }
        BigNum cost = game.costOf(id);
        card.show(game.canBuy(id) ? Card.State.READY : level > 0 ? Card.State.STARTED : Card.State.WAITING,
                corner, mark, upgrade.name(), brief(upgrade), describe(upgrade),
                Format.count(cost) + (cost.gt(BigNum.ONE) ? " atomes" : " atome"), remaining(cost));
    }

    /** Ce que l'amélioration vaut déjà, en un nombre : « ×8 », « +3 points », « −27 % ». */
    private String current(Upgrade upgrade) {
        int level = game.levelOf(upgrade.id());
        return switch (upgrade.effect()) {
            case Effect.StrengthenSpeed strengthen -> "+" + trim(game.speedExtraPerLevel() * 100) + " pts";
            case Effect.DiscountGenerators discount -> "−" + trim((1 - game.generatorCostFactor()) * 100) + " %";
            case Effect.MultiplyAtomsByProduction byProduction -> Format.multiplier(BigNum.of(game.fusionYield()));
            case Effect.KeepUpgradesOnFusion keep -> "";
            default -> Format.multiplier(game.particlesMultiplier(upgrade.id(), level));
        };
    }

    /** Ce que fait l'amélioration, en quelques mots : la ligne de sa carte. */
    private String brief(Upgrade upgrade) {
        return switch (upgrade.effect()) {
            case Effect.MultiplyParticles multiply -> "Particules ×" + trim(multiply.perLevel()) + " par niveau";
            case Effect.MultiplyByAtoms byAtoms -> "+" + trim(byAtoms.perAtom() * 100) + " % de particules par atome créé";
            case Effect.MultiplyByRunTime byTime -> "Plus de particules avec le temps";
            case Effect.StrengthenSpeed strengthen ->
                    "Vitesse : +" + trim(strengthen.extraPerLevel() * 100) + " point par niveau";
            case Effect.DiscountGenerators discount ->
                    "Générateurs −" + trim((1 - discount.factorPerLevel()) * 100) + " % par niveau";
            case Effect.KeepUpgradesOnFusion keep -> "La fusion garde vitesse et couplage";
            case Effect.Overload overload -> "Particules ×" + trim(overload.perLevel()) + " par niveau, sans limite";
            case Effect.MultiplyByGenerators coupling -> "Chaque générateur renforce les autres";
            case Effect.MultiplyAtomsByProduction byProduction ->
                    "+" + trim(game.fusionYieldPerDecade(byProduction) * 100) + " % d'atomes par ×10 de production";
            case Effect.MultiplySpeed speed -> "Accélère la création";
            case Effect.AddGenerator generator -> "Ajoute un générateur";
        };
    }

    /** L'explication complète d'une amélioration, avec sa valeur actuelle : pour le mode détails. */
    private String describe(Upgrade upgrade) {
        int level = game.levelOf(upgrade.id());

        // Pour un bonus pas encore acheté, on montre ce qu'il donnerait tout de suite.
        String value = Format.multiplier(game.particlesMultiplier(upgrade.id(), Math.max(level, 1)));
        String now = level > 0 ? "Actuellement " + value : "Donnerait " + value;
        String effect = switch (upgrade.effect()) {
            case Effect.MultiplyParticles multiply ->
                    "Multiplie par " + trim(multiply.perLevel()) + " les particules créées, à chaque niveau. "
                            + (level > 0 ? now : "");
            case Effect.MultiplyByAtoms byAtoms ->
                    "+" + trim(byAtoms.perAtom() * 100) + " % de particules par atome créé depuis le début, jusqu'à "
                            + Format.count(Game.MAX_ATOMS) + ". " + now;
            case Effect.MultiplyByRunTime byTime ->
                    "Plus de particules à mesure que le temps passe depuis la dernière fusion. " + now;
            case Effect.StrengthenSpeed strengthen ->
                    "Renforce « Vitesse de création » : +" + trim(strengthen.extraPerLevel() * 100)
                            + " point de vitesse en plus à chacun de ses niveaux. "
                            + (level > 0 ? "Actuellement +" + trim(game.speedExtraPerLevel() * 100) + " points" : "");
            case Effect.DiscountGenerators discount ->
                    "Générateurs " + trim((1 - discount.factorPerLevel()) * 100) + " % moins chers, à chaque niveau. "
                            + (level > 0 ? "Actuellement −" + trim((1 - game.generatorCostFactor()) * 100) + " %" : "");
            case Effect.KeepUpgradesOnFusion keep ->
                    "La fusion ne remet plus à zéro les améliorations payées en particules (vitesse, couplage). "
                            + "Les générateurs, eux, fusionnent toujours.";
            case Effect.Overload overload ->
                    "Multiplie par " + trim(overload.perLevel()) + " les particules créées, à chaque niveau, sans "
                            + "limite de niveau. " + (level > 0 ? now : "");
            case Effect.MultiplyByGenerators coupling -> "Chaque générateur renforce les autres.";
            case Effect.MultiplyAtomsByProduction byProduction -> {
                // Pas encore acheté : ce qu'il donnerait avec la production actuelle.
                double perDecade = game.fusionYieldPerDecade(byProduction);
                double decades = Math.max(0, game.productionAtFusion().divide(byProduction.threshold()).log10());
                double multiplier = level > 0 ? game.fusionYield() : 1 + perDecade * decades;
                yield "+" + trim(perDecade * 100) + " % d'atomes par fusion chaque fois que la production est "
                        + "multipliée par 10, à partir de " + Format.whole(Math.round(byProduction.threshold()))
                        + " particules par seconde. " + (level > 0 ? "Actuellement " : "Donnerait ")
                        + Format.multiplier(BigNum.of(multiplier));
            }
            case Effect.MultiplySpeed speed -> "Accélère la création.";
            case Effect.AddGenerator generator -> "Ajoute un générateur.";
        };

        return effect.trim();
    }

    /** Ce qu'il reste à attendre avant de pouvoir payer {@code cost} atomes : un nombre de fusions, ou rien. */
    private String remaining(BigNum cost) {
        long fusions = game.fusionsUntilAtoms(cost);
        if (fusions == 0) return "";
        if (fusions < 0) return "au-dessus du plafond";
        return Format.whole(fusions) + (fusions > 1 ? " fusions" : " fusion");
    }

    /** Écrit 2.0 comme « 2 » et 2.5 comme « 2.5 ». */
    private static String trim(double value) {
        String text = String.format(Locale.ROOT, "%.2f", value);
        return text.contains(".") ? text.replaceAll("0+$", "").replaceAll("\\.$", "") : text;
    }

    /** Un atome vient d'être créé : l'atome grossit d'un coup puis reprend sa taille. */
    void celebrate() {
        ScaleTransition arrive = new ScaleTransition(Duration.seconds(0.6), atomView);
        arrive.setFromX(1.6);
        arrive.setFromY(1.6);
        arrive.setToX(1);
        arrive.setToY(1);
        arrive.play();
    }
}
